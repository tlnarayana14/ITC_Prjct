function [res, frameKey] = transmit_image(enc, imageId, cfg, fec, frameKey)
%TRANSMIT_IMAGE Packetize, transmit (with optional selective-repeat ARQ),
%   receive, verify, reassemble and decode one compressed image.
%
%   [res, frameKey] = TRANSMIT_IMAGE(enc, imageId, cfg, fec, frameKey)
%     enc : SOURCE_ENCODE output (enc.bytes = exact compressed file)
%   Recovery policy (cfg.arq):
%     round 0 sends every packet; after each round the receiver reports the
%     sequence numbers still missing (CRC/length failures) and, if enabled,
%     only those are retransmitted, for at most cfg.arq.maxRetries extra
%     rounds. Packets still missing are UNRECOVERABLE: the image is marked
%     incomplete and is NOT decoded (no bytes are invented).
%
%   res (selected fields)
%     nPkts, nTransmissions, delivered (logical per packet),
%     firstAttemptFail (logical), attempts (per packet)
%     PER_initial  = packets failing on their first transmission / nPkts
%     PER_attempt  = failed transmissions / all transmissions
%     PER_final    = packets unrecovered after the retry policy / nPkts
%     undetected   = packets that passed CRC but differ from what was sent
%     preErr/preN, postErr/postN       (see transmit_frame.m)
%     e2e.errBits  = bit errors in DELIVERED compressed payload bits
%     e2e.erased   = compressed payload bits in UNDELIVERED packets
%     e2e.N        = total compressed payload bits of the image
%     complete, decodeOk, success (= complete && decodeOk && size matches)
%     streamIdentical (recovered stream == transmitted stream)
%     Ir           receiver-decoded image ([] if not decodable)
%     segments     timeline: [type durations], type 1 = data frame airtime,
%                  type 2 = turnaround (2*propagation + feedback airtime);
%                  deliveredSeg = index of the frame completing the image
%     bits.*       accounting: payload, header+CRC, info, coded, retransmitted
%                  info bits, feedback bits

pk = packetize(enc.bytes, imageId, enc.codecId, cfg);
nP = numel(pk);
delivered = false(1, nP);
firstFail = false(1, nP);
attempts = zeros(1, nP);
acceptedPayload = cell(1, nP);
rxLog = struct('crcOk', {}, 'lenOk', {}, 'valid', {}, 'imageId', {}, 'seq', {}, 'total', {}, ...
    'len', {}, 'codecId', {}, 'flags', {}, 'payload', {});
preErr = 0; preN = 0; postErr = 0; postN = 0; codedBits = 0; infoBits = 0; padBits = 0;
nTx = 0; nFailTx = 0; undetected = 0; retxInfoBits = 0; fbBits = 0;
segments = zeros(0, 2);
deliveredSeg = NaN;
phyDiag = {};
Tprop = cfg.chan.range_m / cfg.chan.c;
pending = 1:nP;
maxRounds = 1 + cfg.arq.enabled * cfg.arq.maxRetries;
for rnd = 1:maxRounds
    groups = chunk(pending, cfg.phy.packetsPerFrame);
    for gi = 1:numel(groups)
        g = groups{gi};
        frameKey = frameKey + 1;
        flips = zeros(1, numel(g));
        for ii = 1:numel(cfg.debug.inject)        % test hook (known errors)
            inj = cfg.debug.inject(ii);
            hit = find(g - 1 == inj.seq);
            if inj.round == rnd && ~isempty(hit)
                flips(hit) = inj.nFlips;
            end
        end
        fr = transmit_frame({pk(g).bytes}, cfg, fec, frameKey, flips);
        segments(end + 1, :) = [1, fr.airtime_s]; %#ok<AGROW>
        phyDiag{end + 1} = fr.phy; %#ok<AGROW>
        preErr = preErr + fr.preErr; preN = preN + fr.preN;
        postErr = postErr + fr.postErr; postN = postN + fr.postN;
        codedBits = codedBits + fr.codedBits; infoBits = infoBits + fr.infoBits; padBits = padBits + fr.padBits;
        for j = 1:numel(g)
            q = g(j);
            nTx = nTx + 1;
            attempts(q) = attempts(q) + 1;
            if rnd > 1
                retxInfoBits = retxInfoBits + numel(pk(q).bytes) * 8;
            end
            p = parse_packet(fr.rxBytes{j}, cfg);
            rxLog(end + 1) = p; %#ok<AGROW>
            if p.valid && ~isequal(fr.rxBytes{j}(:), pk(q).bytes(:))
                undetected = undetected + 1;           % CRC passed on wrong data
            end
            if ~p.valid
                nFailTx = nFailTx + 1;
                if rnd == 1, firstFail(q) = true; end
            elseif ~delivered(q)
                % The receiver identifies the packet from its (CRC-checked)
                % header, not from the slot it was sent in.
                if p.imageId == imageId && p.seq + 1 >= 1 && p.seq + 1 <= nP && ~delivered(p.seq + 1)
                    delivered(p.seq + 1) = true;
                    acceptedPayload{p.seq + 1} = p.payload;
                end
            end
        end
        if all(delivered) && isnan(deliveredSeg)
            deliveredSeg = size(segments, 1);
        end
    end
    pending = find(~delivered);
    if cfg.arq.enabled
        nb = cfg.arq.feedbackOverheadBits + nP;            % header+CRC + bitmap
        fbBits = fbBits + nb;
        segments(end + 1, :) = [2, 2 * Tprop + feedback_duration(nb, cfg, fec)]; %#ok<AGROW>
    end
    if isempty(pending)
        break;
    end
end

% ---- reassembly + source decoding (only complete streams are decoded)
[stream, rep] = reassemble_packets(rxLog, imageId, cfg);
res.complete = rep.complete;
res.reassembly = rep;
res.decodeOk = false; res.Ir = []; res.decTime_s = NaN; res.decodeMsg = '';
res.streamIdentical = false;
res.streamCrcOk = false;
if rep.complete
    res.streamIdentical = isequal(stream(:), enc.bytes(:));
    res.streamCrcOk = isfield(enc, 'streamCrc32') && crc_compute(stream, crc_spec('CRC-32')) == enc.streamCrc32;
    res.stream = stream;
    if ~res.streamCrcOk
        res.complete = false;                    % never decode a stream failing the integrity check
        res.decodeMsg = 'not decoded: whole-stream CRC mismatch';
    else
        [Ir, ok, msg, tdec] = source_decode(stream, enc.codec, cfg);
        res.decodeOk = ok; res.decTime_s = tdec; res.decodeMsg = msg;
        if ok && isequal(size(Ir), size(enc.Ic))
            res.Ir = Ir;
        elseif ok
            res.decodeOk = false;
            res.decodeMsg = 'decoded image size mismatch';
        end
    end
else
    res.stream = uint8([]);
    res.decodeMsg = ['not decoded: ' rep.reason];
end
res.success = res.complete && res.decodeOk;

% ---- end-to-end source-bit comparison
e2eErr = 0; erased = 0;
for q = 1:nP
    nbq = 8 * pk(q).len;
    if delivered(q)
        e2eErr = e2eErr + sum(bytes_to_bits(acceptedPayload{q}) ~= bytes_to_bits(pk(q).payload));
    else
        erased = erased + nbq;
    end
end
res.e2e = struct('errBits', e2eErr, 'erased', erased, 'N', 8 * numel(enc.bytes));

res.nPkts = nP;
res.delivered = delivered;
res.firstAttemptFail = firstFail;
res.attempts = attempts;
res.nTransmissions = nTx;
res.PER_initial = mean(firstFail);
res.PER_attempt = nFailTx / max(nTx, 1);
res.PER_final = mean(~delivered);
res.undetected = undetected;
res.preErr = preErr; res.preN = preN; res.postErr = postErr; res.postN = postN;
res.segments = segments;
res.deliveredSeg = deliveredSeg;
res.Tprop = Tprop;
res.phyDiag = phyDiag;
res.bits = struct('payload', 8 * numel(enc.bytes), ...
    'headerCrc', 8 * nP * (cfg.pkt.headerBytes + crc_spec(cfg.crc.name).width / 8), ...
    'info', infoBits, 'coded', codedBits, 'pad', padBits, 'retxInfo', retxInfoBits, 'feedback', fbBits);
end

function c = chunk(v, n)
c = {};
for k = 1:n:numel(v)
    c{end + 1} = v(k:min(numel(v), k + n - 1)); %#ok<AGROW>
end
end
