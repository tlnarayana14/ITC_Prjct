function rec = load_image_record(fname, imageId)
%LOAD_IMAGE_RECORD Load one still image and its metadata (Phase 1).
%
%   rec = LOAD_IMAGE_RECORD(fname, imageId)
%
%   Inputs : fname   - path to a JPEG/PNG/BMP/TIFF file
%            imageId - integer identifier (0..65535, stored in packet headers)
%   Output : rec struct
%       .id, .path, .format (from imfinfo), .fileBytes
%       .width, .height, .channels
%       .bitDepthIn   bits per sample of the stored file (8 or 16 typically)
%       .colorType    'grayscale' | 'truecolor' | 'indexed' (imfinfo)
%       .pixels       uint8 H x W x C working image (C = 1 or 3)
%       .conversion   text describing any conversion applied
%       .info         raw imfinfo struct (original metadata preserved)
%
%   Assumptions: images are converted to 8-bit per sample for transmission.
%   16-bit samples are mapped with round(x/257) (exact inverse of x*257);
%   indexed images are expanded with their colormap; alpha channels are
%   dropped (documented in rec.conversion). Dependencies: imfinfo, imread.

if exist(fname, 'file') ~= 2
    error('load_image_record:nofile', 'Image file not found: %s', fname);
end
info = imfinfo(fname);
info = info(1);                                 % first frame/page only
[~, ~, ext] = fileparts(fname);
okFormats = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'};
if ~any(strcmpi(ext, okFormats))
    error('load_image_record:format', 'Unsupported extension %s (supported: %s)', ext, strjoin(okFormats, ' '));
end

[X, map] = imread(fname);
conv = {};
if ~isempty(map)
    X = ind2rgb(X, map);                        % double in [0,1]
    X = uint8(round(255 * X));
    conv{end+1} = 'indexed->RGB';
end
if size(X, 3) == 4
    error('load_image_record:cmyk', '4-channel (CMYK/RGBA-in-data) image not supported: %s', fname);
end
switch class(X)
    case 'uint8'
    case 'uint16'
        X = uint8(round(double(X) / 257));
        conv{end+1} = '16-bit->8-bit (round(x/257))';
    case 'logical'
        X = uint8(X) * 255;
        conv{end+1} = '1-bit->8-bit';
    case {'double', 'single'}
        X = uint8(round(255 * min(max(double(X), 0), 1)));
        conv{end+1} = 'float->8-bit';
    otherwise
        error('load_image_record:class', 'Unsupported pixel class %s', class(X));
end

rec.id         = imageId;
rec.path       = fname;
rec.format     = lower(strrep(ext, '.', ''));
rec.fileBytes  = file_size_bytes(fname);
rec.width      = size(X, 2);
rec.height     = size(X, 1);
rec.channels   = size(X, 3);
rec.bitDepthIn = bit_depth_per_sample(info, size(X, 3));
rec.colorType  = '';
if isfield(info, 'ColorType'), rec.colorType = info.ColorType; end
rec.pixels     = X;
if isempty(conv), rec.conversion = 'none'; else, rec.conversion = strjoin(conv, '; '); end
rec.info       = info;
end

function n = file_size_bytes(fname)
d = dir(fname);
n = d.bytes;
end

function b = bit_depth_per_sample(info, C)
% imfinfo reports BitDepth per pixel for some formats and per sample for others.
b = NaN;
if isfield(info, 'BitDepth') && ~isempty(info.BitDepth)
    b = double(info.BitDepth(1));
    if b > 16 && C == 3
        b = b / 3;      % e.g. 24 bits/pixel -> 8 bits/sample
    end
    if b == 48
        b = 16;
    end
end
end
