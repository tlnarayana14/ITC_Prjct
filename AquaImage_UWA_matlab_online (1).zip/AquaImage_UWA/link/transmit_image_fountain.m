function [res, frameKey] = transmit_image_fountain(enc, imageId, cfg, fec, frameKey)
%TRANSMIT_IMAGE_FOUNTAIN Image delivery with a packet-level fountain code
%   instead of selective-repeat ARQ (Phase 18: fountain / erasure recovery).
%
%   Round 1 sends n1 = ceil((K + cfg.fountain.extra) / (1 - cfg.fountain.perEst))
%   encoding symbols (systematic ones first) -- the redundancy is sized from
%   an a-priori packet-error estimate so that, usually, NO feedback round is
%   needed. After each round the receiver feeds back only its rank deficit
%   d = K - rank; the transmitter then sends ceil((d + extra)/(1 - perEst))
%   NEW repair symbols (no per-packet bookkeeping). At most
%   1 + cfg.arq.maxRetries rounds. Timeline segments/fields match
%   TRANSMIT_IMAGE so SIMULATE_QUEUE and SUMMARIZE_RUN can be reused.
K = ceil(numel(enc.bytes) / cfg.pkt.payloadBytes);
ex = cfg.fountain.extra; pe = min(max(cfg.fountain.perEst, 0), 0.9);
Tprop = cfg.chan.range_m / cfg.chan.c;
rxLog = struct('crcOk', {}, 'lenOk', {}, 'valid', {}, 'imageId', {}, 'seq', {}, 'total', {}, ...
    'len', {}, 'codecId', {}, 'flags', {}, 'payload', {});
segments = zeros(0, 2); deliveredSeg = NaN; nextEsi = 0; nTx = 0; nFail = 0;
preErr = 0; preN = 0; postErr = 0; postN = 0; coded = 0; fb = 0; firstFail = 0; nFirst = 0;
stream = uint8([]); phyDiag = {};
nSend = ceil((K + ex) / (1 - pe));
for rnd = 1:(1 + cfg.arq.maxRetries)
    esis = nextEsi:(nextEsi + nSend - 1);
    nextEsi = nextEsi + nSend;
    pk = fountain_encode(enc.bytes, imageId, enc.codecId, esis, cfg);
    for g = 1:cfg.phy.packetsPerFrame:numel(pk)
        idx = g:min(numel(pk), g + cfg.phy.packetsPerFrame - 1);
        frameKey = frameKey + 1;
        fr = transmit_frame(pk(idx), cfg, fec, frameKey);
        segments(end + 1, :) = [1, fr.airtime_s]; %#ok<AGROW>
        phyDiag{end + 1} = fr.phy; %#ok<AGROW>
        preErr = preErr + fr.preErr; preN = preN + fr.preN; postErr = postErr + fr.postErr; postN = postN + fr.postN;
        coded = coded + fr.codedBits;
        for j = 1:numel(idx)
            p = parse_packet(fr.rxBytes{j}, cfg);
            rxLog(end + 1) = p; %#ok<AGROW>
            nTx = nTx + 1; nFail = nFail + ~p.valid;
            if rnd == 1, nFirst = nFirst + 1; firstFail = firstFail + ~p.valid; end
        end
        if isempty(stream)
            [stream, rk] = fountain_decode(rxLog, imageId, cfg);
            if ~isempty(stream), deliveredSeg = size(segments, 1); end
        end
    end
    [stream, rk] = fountain_decode(rxLog, imageId, cfg);
    fb = fb + cfg.arq.feedbackOverheadBits;
    segments(end + 1, :) = [2, 2 * Tprop + feedback_duration(cfg.arq.feedbackOverheadBits, cfg, fec)]; %#ok<AGROW>
    if ~isempty(stream), break; end
    nSend = ceil((K - rk + ex) / (1 - pe));
end
res.complete = ~isempty(stream);
res.streamIdentical = res.complete && isequal(stream(:), enc.bytes(:));
res.streamCrcOk = res.complete && crc_compute(stream, crc_spec('CRC-32')) == enc.streamCrc32;
res.decodeOk = false; res.Ir = []; res.decTime_s = NaN; res.decodeMsg = 'not decoded: rank deficient';
if res.complete && res.streamCrcOk
    [Ir, ok, msg, t] = source_decode(stream, enc.codec, cfg);
    res.decodeOk = ok && isequal(size(Ir), size(enc.Ic)); res.decodeMsg = msg; res.decTime_s = t;
    if res.decodeOk, res.Ir = Ir; end
end
res.success = res.complete && res.decodeOk;
res.stream = stream;
res.nPkts = K; res.nTransmissions = nTx;
res.delivered = repmat(res.complete, 1, K);
% PER bookkeeping: symbols are not tied to source packets, so the number of
% first-burst symbol failures is mapped onto the first entries (count only)
res.firstAttemptFail = false(1, K); res.firstAttemptFail(1:min(K, firstFail)) = true;
res.attempts = ones(1, K);
res.PER_initial = firstFail / max(nFirst, 1); res.PER_attempt = nFail / max(nTx, 1);
res.PER_final = double(~res.complete);
res.undetected = 0;
res.preErr = preErr; res.preN = preN; res.postErr = postErr; res.postN = postN;
res.e2e = struct('errBits', 0, 'erased', ~res.complete * 8 * numel(enc.bytes), 'N', 8 * numel(enc.bytes));
res.segments = segments; res.deliveredSeg = deliveredSeg; res.Tprop = Tprop; res.phyDiag = phyDiag;
res.reassembly = struct('complete', res.complete, 'missing', [], 'reason', res.decodeMsg, 'received', []);
res.bits = struct('payload', 8 * numel(enc.bytes), 'headerCrc', 8 * nTx * (cfg.pkt.headerBytes + 4), ...
    'info', postN, 'coded', coded, 'pad', 0, 'retxInfo', max(0, nTx - K) * 8 * (cfg.pkt.headerBytes + cfg.pkt.payloadBytes + 4), 'feedback', fb);
res.symbolsSent = nTx; res.K = K;
end
