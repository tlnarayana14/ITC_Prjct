function p = parse_packet(bytes, cfg)
%PARSE_PACKET Verify the CRC of a received packet and decode its header.
%
%   p = PARSE_PACKET(bytes, cfg)   bytes = uint8 packet after channel decoding
%   Fields:
%     .crcOk     CRC recomputed over header+payload equals the received CRC
%     .lenOk     payload-length field is consistent with the packet size and
%                with cfg.pkt.payloadBytes
%     .valid     crcOk && lenOk  (only valid packets may be used downstream)
%     .imageId,.seq,.total,.len,.codecId,.flags,.payload
%   Header fields of an invalid packet are reported for diagnostics only and
%   must not be trusted.
bytes = uint8(bytes(:));
s = crc_spec(cfg.crc.name);
nc = s.width / 8;
H = cfg.pkt.headerBytes;
p = struct('crcOk', false, 'lenOk', false, 'valid', false, 'imageId', NaN, 'seq', NaN, ...
    'total', NaN, 'len', NaN, 'codecId', NaN, 'flags', NaN, 'payload', uint8([]));
if numel(bytes) < H + nc
    return;
end
body = bytes(1:end - nc);
rc = uint32(0);
for k = 1:nc
    rc = bitor(bitshift(rc, 8), uint32(bytes(end - nc + k)));
end
p.crcOk = (crc_compute(body, s) == rc);
d = double(bytes);
p.imageId = d(1) * 256 + d(2);
p.seq     = d(3) * 256 + d(4);
p.total   = d(5) * 256 + d(6);
p.len     = d(7) * 256 + d(8);
p.codecId = d(9);
p.flags   = d(10);
if bitand(p.flags, 2)
    % fountain symbol: full-size payload, seq = encoding-symbol ID (any value),
    % len = length of the last SOURCE block (to strip padding after decoding)
    p.lenOk = (p.len >= 1) && (p.len <= cfg.pkt.payloadBytes) && ...
        (H + cfg.pkt.payloadBytes + nc == numel(bytes)) && p.total >= 1;
else
    p.lenOk = (p.len >= 1) && (p.len <= cfg.pkt.payloadBytes) && (H + p.len + nc == numel(bytes)) ...
        && (p.seq < p.total);
end
p.valid = p.crcOk && p.lenOk;
if p.valid
    p.payload = body(H + 1:end);
end
end
