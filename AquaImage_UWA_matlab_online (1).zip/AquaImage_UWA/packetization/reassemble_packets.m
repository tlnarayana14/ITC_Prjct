function [stream, rep] = reassemble_packets(rx, imageId, cfg)
%REASSEMBLE_PACKETS Rebuild a compressed stream from received packets (Phase 12).
%
%   [stream, rep] = REASSEMBLE_PACKETS(rx, imageId, cfg)
%     rx      : struct array of PARSE_PACKET outputs in ARRIVAL order
%               (all received copies, including CRC failures/retransmissions)
%     imageId : the image being reassembled
%   Returns stream (uint8 column) ONLY when the image is complete and
%   consistent; otherwise stream = [] and rep explains why.
%
%   rep fields
%     complete        all packets 0..total-1 present, lengths consistent
%     total           number of packets announced by valid headers (NaN if none)
%     received        logical(1,total) per sequence number
%     missing         sequence numbers never received correctly
%     crcFailures     copies rejected by CRC or length check (corrupted)
%     duplicates      valid copies of an already-accepted sequence number
%     duplicateConflicts  duplicates whose payload differs (should be 0)
%     outOfOrder      valid packets that arrived after a higher seq number
%     invalidLength   copies with CRC OK but inconsistent length field
%     otherImage      valid packets that belong to another image ID
%     totalConflict   valid packets announcing a different total
%     streamBytes     numel(stream)
%     reason          '' when complete, otherwise a short diagnosis

P = cfg.pkt.payloadBytes;
rep = struct('complete', false, 'total', NaN, 'received', false(1, 0), 'missing', [], ...
    'crcFailures', 0, 'duplicates', 0, 'duplicateConflicts', 0, 'outOfOrder', 0, ...
    'invalidLength', 0, 'otherImage', 0, 'totalConflict', 0, 'streamBytes', 0, 'reason', '');
stream = uint8([]);
payloads = {};
maxSeqSeen = -1;
for k = 1:numel(rx)
    p = rx(k);
    if ~p.crcOk
        rep.crcFailures = rep.crcFailures + 1;
        continue;
    end
    if ~p.lenOk
        rep.invalidLength = rep.invalidLength + 1;
        rep.crcFailures = rep.crcFailures + 1;
        continue;
    end
    if p.imageId ~= imageId
        rep.otherImage = rep.otherImage + 1;
        continue;
    end
    if isnan(rep.total)
        rep.total = p.total;
        rep.received = false(1, p.total);
        payloads = cell(1, p.total);
    elseif p.total ~= rep.total
        rep.totalConflict = rep.totalConflict + 1;
        continue;
    end
    q = p.seq + 1;
    if p.seq < maxSeqSeen
        rep.outOfOrder = rep.outOfOrder + 1;
    end
    maxSeqSeen = max(maxSeqSeen, p.seq);
    if rep.received(q)
        rep.duplicates = rep.duplicates + 1;
        if ~isequal(payloads{q}, p.payload)
            rep.duplicateConflicts = rep.duplicateConflicts + 1;
        end
        continue;
    end
    % non-final packets must carry exactly P bytes; final must be 1..P
    if (q < p.total && p.len ~= P) || (q == p.total && (p.len < 1 || p.len > P))
        rep.invalidLength = rep.invalidLength + 1;
        continue;
    end
    rep.received(q) = true;
    payloads{q} = p.payload;
end

if isnan(rep.total)
    rep.reason = 'no valid packet received (total unknown)';
    return;
end
rep.missing = find(~rep.received) - 1;
if ~isempty(rep.missing)
    rep.reason = sprintf('%d of %d packets missing', numel(rep.missing), rep.total);
    return;
end
if rep.duplicateConflicts > 0 || rep.totalConflict > 0
    rep.reason = 'inconsistent duplicate/total fields';
    return;
end
stream = vertcat(payloads{:});
expected = (rep.total - 1) * P + numel(payloads{end});
if numel(stream) ~= expected
    rep.reason = 'stream length mismatch';
    stream = uint8([]);
    return;
end
rep.complete = true;
rep.streamBytes = numel(stream);
end
