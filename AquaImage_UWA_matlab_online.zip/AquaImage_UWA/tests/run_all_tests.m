function results = run_all_tests(which)
%RUN_ALL_TESTS Execute the test suite and write results/logs/test_report.txt.
%   results = RUN_ALL_TESTS()          run every test
%   results = RUN_ALL_TESTS({'D','E'}) run a subset (letters / 'P1' / 'X')
root = setup_paths();
tests = {'P1', 'test_P1_image_source'; 'A', 'test_A_source_codec'; 'B', 'test_B_bitstream'; ...
    'C', 'test_C_packetization'; 'D', 'test_D_crc'; 'E', 'test_E_channel_coding'; ...
    'F', 'test_F_modulation'; 'G', 'test_G_awgn'; 'H', 'test_H_channel_decoding'; ...
    'I', 'test_I_retransmission'; 'J', 'test_J_end_to_end'; 'K', 'test_K_error_free'; ...
    'L', 'test_L_error_injection'; 'M', 'test_M_continuous_source'; 'N', 'test_N_replay_channel'; 'O', 'test_O_fountain'; 'P', 'test_P_roi_uep'; 'Q', 'test_Q_amc_controller'; 'X', 'test_X_crossval'};
if nargin >= 1
    tests = tests(ismember(tests(:, 1), which), :);
end
results = struct('id', {}, 'name', {}, 'pass', {}, 'msg', {}, 'time', {});
logDir = fullfile(root, 'results', 'logs');
if exist(logDir, 'dir') ~= 7, mkdir(logDir); end
diaryFile = fullfile(logDir, 'test_output.txt');
if exist(diaryFile, 'file') == 2 && nargin < 1, delete(diaryFile); end
diary(diaryFile);
for k = 1:size(tests, 1)
    fprintf('\n=== Test %s: %s ===\n', tests{k, 1}, tests{k, 2});
    t0 = tic;
    try
        feval(tests{k, 2});
        ok = true; msg = 'passed';
    catch err
        ok = false; msg = err.message;
        fprintf('    %s\n', msg);
    end
    results(end + 1) = struct('id', tests{k, 1}, 'name', tests{k, 2}, 'pass', ok, 'msg', msg, 'time', toc(t0)); %#ok<AGROW>
    fprintf('--> %s (%.1f s)\n', ternary(ok, 'PASS', 'FAIL'), results(end).time);
end
diary off;
fid = fopen(fullfile(logDir, 'test_report.txt'), 'w');
fprintf(fid, 'AquaImage_UWA test report  %s  (%s)\n', datestr(now), ternary(is_octave(), ['GNU Octave ' OCTAVE_VERSION], ['MATLAB ' version]));
for k = 1:numel(results)
    fprintf(fid, '%-3s %-28s %s  %6.1f s  %s\n', results(k).id, results(k).name, ternary(results(k).pass, 'PASS', 'FAIL'), results(k).time, results(k).msg);
end
fprintf(fid, 'passed %d / %d\n', nnz([results.pass]), numel(results));
fclose(fid);
fprintf('\npassed %d / %d tests\n', nnz([results.pass]), numel(results));
end
