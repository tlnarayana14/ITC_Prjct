function [msgs, st] = fec_decode(fec, llr, layout)
%FEC_DECODE Decode a coded LLR stream back into the list of messages.
%
%   [msgs, st] = FEC_DECODE(fec, llr, layout)
%     llr    : column of LLRs for the transmitted coded bits (L = log P0/P1)
%     layout : from FEC_ENCODE (receiver knows the frame structure)
%     msgs   : cell array of decoded 0/1 message columns (padding removed)
%     st     : .blocks, .blocksConverged (LDPC syndrome == 0), .meanIter
%
%   LDPC: shortened (padding) positions are re-inserted with LLR = +50,
%   i.e. as known zeros, before decoding. Polar: last block uses the same
%   extra-frozen mask as the encoder. 'none': hard decisions on the LLRs.
llr = llr(:);
nm = numel(layout);
msgs = cell(1, nm);
st = struct('blocks', 0, 'blocksConverged', NaN, 'meanIter', NaN);
K = fec.K; N = fec.N;
switch fec.type
    case 'none'
        for i = 1:nm
            r = layout(i).start + (0:layout(i).L - 1);
            msgs{i} = double(llr(r) < 0);
        end
        st.blocks = sum([layout.L]);
    case 'ldpc'
        nbT = sum([layout.nBlocks]);
        Lmat = zeros(N, nbT);
        col = 0;
        for i = 1:nm
            nb = layout(i).nBlocks;
            keep = true(N, nb);
            keep(K - layout(i).pad + 1:K, end) = false;
            Li = 50 * ones(N, nb);                       % known (shortened) zeros
            Li(keep) = llr(layout(i).start + (0:layout(i).nTx - 1));
            Lmat(:, col + (1:nb)) = Li;
            col = col + nb;
        end
        [U, inf] = ldpc_decode(fec.code, Lmat, fec.maxIter, fec.alpha);
        col = 0;
        for i = 1:nm
            nb = layout(i).nBlocks;
            u = U(:, col + (1:nb));
            col = col + nb;
            msgs{i} = u(1:layout(i).L);
            msgs{i} = msgs{i}(:);
        end
        st.blocks = nbT;
        st.blocksConverged = sum(inf.converged);
        st.meanIter = mean(inf.iterations);
    case 'polar'
        % group full blocks of all messages for one vectorised SC pass
        full = {}; lastL = cell(1, nm);
        for i = 1:nm
            nb = layout(i).nBlocks;
            Li = reshape(llr(layout(i).start + (0:layout(i).nTx - 1)), N, nb);
            full{end + 1} = Li(:, 1:nb - 1); %#ok<AGROW>
            lastL{i} = Li(:, nb);
        end
        Uf = polar_sc_decode(fec.code, [full{:}]);
        col = 0;
        for i = 1:nm
            nb = layout(i).nBlocks;
            fz = polar_last_frozen(fec.code, layout(i).pad);
            ul = polar_sc_decode(fec.code, lastL{i}, fz);
            u = [reshape(Uf(:, col + (1:nb - 1)), [], 1); ul(:)];
            col = col + nb - 1;
            msgs{i} = u(1:layout(i).L);
        end
        st.blocks = sum([layout.nBlocks]);
    case 'polar_scl'
        nOk = 0; nB = 0;
        for i = 1:nm
            nb = layout(i).nBlocks;
            Li = reshape(llr(layout(i).start + (0:layout(i).nTx - 1)), fec.N, nb);
            u = zeros(fec.K, nb);
            for b = 1:nb
                [uh, ok] = polar_scl_decode(fec.code, Li(:, b), fec.L, 16);
                u(:, b) = uh(1:fec.K); nOk = nOk + ok; nB = nB + 1;
            end
            msgs{i} = u(1:layout(i).L).';
            msgs{i} = msgs{i}(:);
        end
        st.blocks = nB; st.blocksConverged = nOk;
    case 'rs'
        km = fec.code.kmax; t = fec.code.t; nOk = 0; nB = 0;
        for i = 1:nm
            hb = double(llr(layout(i).start + (0:layout(i).nTx - 1)) < 0);
            by = bits_to_bytes(hb);
            nbytes = layout(i).L / 8; out = {}; p0 = 1;
            for b = 1:layout(i).nBlocks
                k = min(km, nbytes - (b - 1) * km);
                [m, ~, ok] = rs_decode(by(p0:p0 + k + 2 * t - 1), t);
                out{end + 1} = m; p0 = p0 + k + 2 * t; %#ok<AGROW>
                nOk = nOk + ok; nB = nB + 1;
            end
            msgs{i} = bytes_to_bits(vertcat(out{:}));
        end
        st.blocks = nB; st.blocksConverged = nOk;
    otherwise
        error('fec_decode:type', 'Unknown code %s', fec.type);
end
end
