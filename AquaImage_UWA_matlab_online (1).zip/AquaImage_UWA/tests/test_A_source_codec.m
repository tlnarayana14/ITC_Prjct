function test_A_source_codec()
%TEST_A_SOURCE_CODEC Encoder/decoder round trips with the real codecs.
cfg = test_config();
files = {fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_03.jpg'), ...
         fullfile(cfg.root, 'data', 'format_test', 'fmt_png_gray.png'), ...
         fullfile(cfg.root, 'data', 'format_test', 'fmt_jpg_crop.jpg')};
for k = 1:numel(files)
    r = load_image_record(files{k}, 0);
    I = r.pixels;
    % lossless PNG
    c = cfg; c.codec.name = 'png';
    e = source_encode(I, c);
    check(isequal(e.Ic, I), 'PNG lossless round trip identical (%s, %d B, CR %.2f)', r.format, numel(e.bytes), e.CR);
    % lossy JPEG
    c = cfg; c.codec.name = 'jpeg'; c.codec.jpegQuality = 50;
    e = source_encode(I, c);
    check(isequal(size(e.Ic), size(I)), 'JPEG q50 decodes to a valid image of the same size');
    p = psnr_u8(I, e.Ic);
    check(p > 25 && p < Inf, 'JPEG q50 PSNR %.2f dB is finite and > 25 dB (lossy)', p);
    check(abs(e.CR - e.rawBits / (8 * numel(e.bytes))) < 1e-12, 'CR = raw bits / compressed bits (%.2f)', e.CR);
    if codec_available('jpegxl', cfg)
        c = cfg; c.codec.name = 'jpegxl'; c.codec.jxlDistance = 0;
        e = source_encode(I, c);
        check(isequal(e.Ic, I), 'JPEG XL distance 0 is lossless (%d B)', numel(e.bytes));
        c.codec.jxlDistance = 2;
        e = source_encode(I, c);
        check(isequal(size(e.Ic), size(I)) && psnr_u8(I, e.Ic) > 25, 'JPEG XL d=2 valid, PSNR %.2f dB, %d B', psnr_u8(I, e.Ic), numel(e.bytes));
    else
        fprintf('    SKIP: cjxl/djxl not installed - JPEG XL round trip not tested\n');
    end
end
% corrupted stream must be rejected or flagged, never crash
c = cfg; c.codec.name = 'jpeg';
e = source_encode(I, c);
[~, ok, msg] = source_decode(e.bytes(1:20), 'jpeg', c);
check(true, 'truncated JPEG handled without exception (ok=%d, msg="%s")', ok, msg(1:min(end, 60)));
end
