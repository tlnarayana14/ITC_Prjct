function thr = per_thresholds(T, rates, target)
%PER_THRESHOLDS Estimated-SNR thresholds where first-attempt PER reaches 'target'.
%   thr = PER_THRESHOLDS(T, rates, target) uses an Experiment-3 sweep T
%   (fields variant, snrEstDb, PER_initial). For each rate the threshold is
%   the receiver-estimated SNR at which PER_initial first drops to <= target,
%   linearly interpolated (in log10 PER) between the bracketing SNR points.
%   NaN if the target is never reached in the sweep.
thr = NaN(size(rates));
for i = 1:numel(rates)
    m = strcmp({T.variant}, sprintf('LDPC R=%s', rate_str(rates(i))));
    x = [T(m).snrEstDb]; y = [T(m).PER_initial];
    [x, o] = sort(x); y = y(o);
    k = find(y <= target, 1, 'first');
    if isempty(k), continue; end
    if k == 1, thr(i) = x(1); continue; end
    ly = log10(max(y([k - 1, k]), 1e-6));
    thr(i) = x(k - 1) + (log10(target) - ly(1)) / (ly(2) - ly(1)) * (x(k) - x(k - 1));
end
end
