function s = ssim_luma(A, B)
%SSIM_LUMA Mean SSIM (Wang et al., IEEE TIP 2004) on the luma channel.
%   s = SSIM_LUMA(A, B) for uint8 images of identical size.
%   Luma: Y = 0.299 R + 0.587 G + 0.114 B (ITU-R BT.601, range 0..255);
%   grayscale images are used directly. Gaussian window 11x11, sigma 1.5,
%   K1 = 0.01, K2 = 0.03, L = 255, statistics on the 'valid' region only.
%   This matches skimage.metrics.structural_similarity(gaussian_weights=True,
%   sigma=1.5, use_sample_covariance=False, data_range=255) - checked in
%   tests/test_metrics_crossval.m via tools/crosscheck_metrics.py.
if ~isequal(size(A), size(B))
    error('ssim_luma:size', 'Image sizes differ.');
end
x = luma(A); y = luma(B);
g = exp(-((-5:5).^2) / (2 * 1.5^2));
g = g / sum(g);
w = g.' * g;
C1 = (0.01 * 255)^2; C2 = (0.03 * 255)^2;
mx = conv2(x, w, 'valid'); my = conv2(y, w, 'valid');
sxx = conv2(x .* x, w, 'valid') - mx.^2;
syy = conv2(y .* y, w, 'valid') - my.^2;
sxy = conv2(x .* y, w, 'valid') - mx .* my;
m = ((2 * mx .* my + C1) .* (2 * sxy + C2)) ./ ((mx.^2 + my.^2 + C1) .* (sxx + syy + C2));
s = mean(m(:));
end

function Y = luma(I)
I = double(I);
if size(I, 3) == 3
    Y = 0.299 * I(:, :, 1) + 0.587 * I(:, :, 2) + 0.114 * I(:, :, 3);
else
    Y = I;
end
end
