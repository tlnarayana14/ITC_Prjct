function s = rate_str(R)
%RATE_STR Format a code rate as a fraction string, e.g. 0.75 -> '3/4'.
[n, d] = rat(R, 1e-6);
s = sprintf('%d/%d', n, d);
end
