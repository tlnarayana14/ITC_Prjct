function [stream, rk, K] = fountain_decode(rx, imageId, cfg)
%FOUNTAIN_DECODE Recover a stream from received fountain packets (GF(2) elimination).
%   [stream, rank, K] = FOUNTAIN_DECODE(rx, imageId, cfg)
%     rx : struct array of PARSE_PACKET outputs (only valid fountain packets
%          of this image are used; CRC failures are erasures)
%   stream = [] until rank == K. Gaussian elimination over GF(2) on the
%   coefficient rows, applying the same XOR row operations to the payloads.
stream = uint8([]); rk = 0; K = NaN;
P = cfg.pkt.payloadBytes;
ok = arrayfun(@(p) p.valid && p.imageId == imageId && bitand(p.flags, 2) > 0, rx);
rx = rx(ok);
if isempty(rx), return; end
K = rx(1).total; lastLen = rx(1).len;
m = numel(rx);
A = false(m, K); D = zeros(m, P, 'uint8');
for i = 1:m
    A(i, :) = fountain_coeffs(rx(i).seq, K);
    D(i, :) = rx(i).payload(:).';
end
row = 1;
piv = zeros(1, K);
for col = 1:K
    r = find(A(row:end, col), 1) + row - 1;
    if isempty(r), continue; end
    A([row r], :) = A([r row], :); D([row r], :) = D([r row], :);
    others = find(A(:, col)); others(others == row) = [];
    for o = others.'
        A(o, :) = xor(A(o, :), A(row, :));
        D(o, :) = bitxor(D(o, :), D(row, :));
    end
    piv(col) = row;
    row = row + 1;
    if row > m, break; end
end
rk = nnz(piv);
if rk < K, return; end
src = D(piv, :).';                       % P x K, column j = source block j
stream = src(:);
stream = stream(1:(K - 1) * P + lastLen);
end
