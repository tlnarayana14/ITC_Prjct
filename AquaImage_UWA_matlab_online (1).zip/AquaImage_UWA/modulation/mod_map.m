function [sym, nPad] = mod_map(bits, scheme)
%MOD_MAP Map coded bits to Gray constellation symbols (unit Es).
%   [sym, nPad] = MOD_MAP(bits, scheme)
%   bits are zero-padded to a multiple of bits/symbol; nPad reports how many
%   padding bits were appended (the receiver discards exactly that many LLRs).
[pts, labels, m] = mod_constellation(scheme);
bits = double(bits(:));
nPad = mod(-numel(bits), m);
bits = [bits; zeros(nPad, 1)];
B = reshape(bits, m, []).';
idx = B * (2 .^ (m - 1:-1:0)).' + 1;     % labels are enumerated MSB first
lab_idx = labels * (2 .^ (m - 1:-1:0)).' + 1;
lut = zeros(numel(pts), 1);
lut(lab_idx) = 1:numel(pts);
sym = pts(lut(idx)).';
sym = sym(:);
end
