function [coded, layout] = fec_encode(fec, msgs)
%FEC_ENCODE Encode a list of messages (packets) into one coded bit stream.
%
%   [coded, layout] = FEC_ENCODE(fec, msgs)
%     msgs   : cell array of 0/1 column vectors (each = one serialized packet)
%     coded  : column of transmitted coded bits for all messages, in order
%     layout : struct array, one per message:
%        .L       message (channel-encoder input) bits
%        .nBlocks code blocks used
%        .pad     zero padding bits added to fill the last block (known to Rx)
%        .nTx     coded bits actually transmitted for this message
%        .start   1-based index of its first coded bit in 'coded'
%
%   Framing rules (no padding is ever silently discarded):
%     LDPC  : systematic; the 'pad' zeros occupy the last info positions of
%             the last block and are SHORTENED (not transmitted). The
%             receiver re-inserts them as perfectly known zeros.
%     Polar : the 'pad' least-reliable information positions of the last
%             block are frozen to 0 (the full N bits are transmitted).
%     none  : coded = message bits.

nm = numel(msgs);
layout = struct('L', cell(1, nm), 'nBlocks', [], 'pad', [], 'nTx', [], 'start', []);
K = fec.K; N = fec.N;
switch fec.type
    case 'none'
        coded = vertcat(msgs{:});
        pos = 1;
        for i = 1:nm
            L = numel(msgs{i});
            layout(i).L = L; layout(i).nBlocks = L; layout(i).pad = 0; layout(i).nTx = L; layout(i).start = pos;
            pos = pos + L;
        end
        coded = double(coded(:));
    case 'ldpc'
        U = cell(1, nm); nb = zeros(1, nm); pads = zeros(1, nm);
        for i = 1:nm
            L = numel(msgs{i});
            nb(i) = ceil(L / K); pads(i) = nb(i) * K - L;
            U{i} = reshape([double(msgs{i}(:)); zeros(pads(i), 1)], K, nb(i));
        end
        CW = ldpc_encode(fec.code, [U{:}]);
        parts = cell(1, nm); col = 0; pos = 1;
        for i = 1:nm
            c = CW(:, col + (1:nb(i)));
            col = col + nb(i);
            keep = true(N, nb(i));
            keep(K - pads(i) + 1:K, end) = false;     % shortened (known) zeros
            parts{i} = c(keep);
            layout(i).L = numel(msgs{i}); layout(i).nBlocks = nb(i); layout(i).pad = pads(i);
            layout(i).nTx = numel(parts{i}); layout(i).start = pos;
            pos = pos + layout(i).nTx;
        end
        coded = vertcat(parts{:});
    case 'polar'
        parts = cell(1, nm); pos = 1;
        for i = 1:nm
            L = numel(msgs{i});
            nb = ceil(L / K); pad = nb * K - L;
            u = [double(msgs{i}(:)); zeros(pad, 1)];
            U = reshape(u, K, nb);
            X = polar_encode(fec.code, U(:, 1:nb - 1));
            % last block: freeze the 'pad' least reliable info positions
            fz = polar_last_frozen(fec.code, pad);
            v = zeros(N, 1);
            v(~fz) = U(1:K - pad, nb);
            xl = polar_transform_full(v);
            Xall = [X, xl];
            parts{i} = Xall(:);
            layout(i).L = L; layout(i).nBlocks = nb; layout(i).pad = pad;
            layout(i).nTx = numel(parts{i}); layout(i).start = pos;
            pos = pos + layout(i).nTx;
        end
        coded = vertcat(parts{:});
    case 'polar_scl'
        parts = cell(1, nm); pos = 1; Kp = fec.K; cs = crc_spec('CRC-16/CCITT-FALSE');
        for i = 1:nm
            L = numel(msgs{i}); nb = ceil(L / Kp); pad = nb * Kp - L;
            U = reshape([double(msgs{i}(:)); zeros(pad, 1)], Kp, nb);
            Uc = zeros(Kp + 16, nb);
            for b = 1:nb
                c = crc_compute(bits_to_bytes(U(:, b)), cs);
                Uc(:, b) = [U(:, b); double(bitand(bitshift(c, -(15:-1:0)), 1)).'];
            end
            X = polar_encode(fec.code, Uc);
            parts{i} = X(:);
            layout(i).L = L; layout(i).nBlocks = nb; layout(i).pad = pad;
            layout(i).nTx = numel(parts{i}); layout(i).start = pos;
            pos = pos + layout(i).nTx;
        end
        coded = vertcat(parts{:});
    case 'rs'
        parts = cell(1, nm); pos = 1;
        km = fec.code.kmax; t = fec.code.t;
        for i = 1:nm
            L = numel(msgs{i});
            if mod(L, 8) ~= 0, error('fec_encode:rs', 'RS framing needs whole bytes.'); end
            by = bits_to_bytes(msgs{i});
            nb = ceil(numel(by) / km); cw = {};
            for b = 1:nb
                seg = by((b - 1) * km + 1:min(numel(by), b * km));
                cw{end + 1} = rs_encode(seg, t); %#ok<AGROW>
            end
            parts{i} = bytes_to_bits(vertcat(cw{:}));
            layout(i).L = L; layout(i).nBlocks = nb; layout(i).pad = 0;
            layout(i).nTx = numel(parts{i}); layout(i).start = pos;
            pos = pos + layout(i).nTx;
        end
        coded = vertcat(parts{:});
    otherwise
        error('fec_encode:type', 'Unknown code %s', fec.type);
end
end

function x = polar_transform_full(v)
N = size(v, 1);
if N == 1, x = v; return; end
h = N / 2;
a = polar_transform_full(v(1:h, :));
b = polar_transform_full(v(h + 1:end, :));
x = [mod(a + b, 2); b];
end
