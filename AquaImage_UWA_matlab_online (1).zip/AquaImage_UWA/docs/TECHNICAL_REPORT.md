# AquaImage_UWA: Design, Implementation and Simulation-Based Evaluation of an End-to-End Underwater Acoustic Still-Image Transmission System

*Technical report — October 2026. All numerical results were produced by the
code in this repository, executed with **GNU Octave 8.4.0** on a 2-core Linux
container (MATLAB was not available; the code uses only the MATLAB/Octave
common subset and no toolboxes). Every number below can be traced to a file
in `results/tables/` or `results/logs/`.*

**Status labels used in this report.** **[Executed]** measured by running the
code; **[Analysis]** derived from executed numbers or standard formulas;
**[Not executed]** implemented or proposed but not run here; **[Future]**
proposed work.

---

## Abstract

We built and evaluated a complete, reproducible simulation of an underwater
camera that sends independent still images over an acoustic link. Real
underwater images (23 EUVP samples) are compressed with real codecs (JPEG via
`imwrite`, JPEG XL via the libjxl reference tools, PNG), the exact compressed
bytes are packetised with a CRC-32, protected with a quasi-cyclic LDPC code
(N = 1296, rates 1/2–5/6) or a polar code, mapped to Gray QPSK and sent in
CP-OFDM frames (8 kHz band at 24 kHz) through image-method multipath,
wideband Doppler and Rician time-varying channels. The receiver performs
chirp synchronisation, Doppler-scale resampling, null-subcarrier CFO search,
sparse LS channel estimation, soft demapping, LDPC/polar decoding, CRC
checking, selective-repeat ARQ, reassembly and real decoding, and every
received image is compared with both the original and the locally decoded
transmitter image. A 19-group test suite passes, including an uncoded-BER
check within 2–7 % of theory and cross-checks of CRC-32, PSNR, SSIM and JPEG XL
against independent Python libraries **[Executed]**. Ten experiments show that
(i) libjxl 0.7 needs 13–15 % *more* bits than JPEG at equal PSNR but 11–15 %
*fewer* at equal SSIM on these images; (ii) on the static multipath channel
LDPC R=1/2 reaches error-free packets about 2 dB before an N=1024 SC-decoded
polar code and 6 dB before R=3/4; (iii) Doppler compensation is indispensable
(0 % packets without it); (iv) selective-repeat ARQ turns a 15 % first-attempt
PER at 5 dB into 0 % final loss for +16 % retransmitted bits; (v) at the
required camera rate of one image per second the queue is unstable for every
tested source setting (service 10–19 s per image); (vi) a learned Deep JSCC model, tested on held-out images through the real
receiver, delivers 22.8–23.4 dB at 0–4 dB SNR where every digital scheme
loses the image, but trails separated coding by 2–4 dB above 6 dB; (vii)
CA-SCL polar decoding closes the gap to LDPC, fountain coding delivers more
images at the margin at a goodput cost, and two-layer ROI coding gains
+6.7 dB on the subject; and (viii) under a 12 s per-image deadline a joint (JPEG-quality, LDPC-rate)
selection rule delivered 64 % of images on time vs 35 % for the best fixed or
rate-only policy (80 paired images), at lower image quality (SSIM 0.91 vs 0.95),
while rate-only adaptation alone did not beat a fixed R=1/2 code (Exp 5). All limitations are listed in
Section 13.

## 1. Introduction and motivation

Underwater observatories increasingly rely on cameras, but acoustic links
offer only kilobits per second, long propagation delays (0.67 s per km) and
severe multipath and Doppler distortion. Transmitting still images therefore
requires strong compression, robust physical-layer processing, error control
and an honest accounting of delay. Many published studies evaluate one block
in isolation (a codec at a given bit rate, or a modem at a given BER). This
project instead implements and measures the **whole chain on real image data**
so that the interactions — packet loss vs. decodability, ARQ vs. delay,
compression vs. queue stability — are visible.

## 2. Problem statement and objectives

A camera produces independent still images at a configurable interval (1 s by
default) in JPEG/PNG/BMP/TIFF formats. Objectives: (O1) reduce bandwidth with
real still-image codecs; (O2) protect the compressed data (CRC, FEC); (O3)
recover corrupted packets (ARQ) without inventing data; (O4) reconstruct and
evaluate images, separating source from channel distortion; (O5) measure
BER/PER/goodput/delay and queue behaviour; (O6) evaluate adaptation and one
research extension.

## 3. Related work and research gap

See `docs/LITERATURE_REVIEW.md` (verification status of each reference is
marked there). In short: UWA channel physics and the A(l,f) attenuation model
follow Stojanovic (2007) and Stojanovic & Preisig (2009); the OFDM receiver
follows the resampling + residual-Doppler approach with null and pilot
subcarriers of Li et al. (IEEE JOE 2008); adaptive UWA OFDM with delayed
feedback is studied by Radosevic et al. (IEEE JOE 2014); UEP of SPIHT
bitstreams by Esmaiel et al. (Sensors 2019); learned JSCC for UWA images by
Anjum, Qi & Pompili (WUWNet 2022). The gap addressed by Experiment 10 is an
**evaluation** — not a claimed new algorithm — of per-image joint source/channel
operating-point selection with standard decodable codecs, explicit ARQ latency
on a half-duplex link, one-image-old CSI and a per-image deadline.

## 4. System architecture **[Executed]**

```
TX  camera schedule -> load (imfinfo/imread, 8-bit normalisation) -> source_encode
    (exact file bytes) -> packetize (10 B header + payload + CRC-32) -> fec_encode
    (LDPC shortening / polar freezing) -> interleave_bits -> mod_map (Gray QPSK)
    -> phy_ofdm_tx (chirp | guard | CP-OFDM symbols | guard | chirp | guard)
CH  uwa_channel: start offset -> multipath (image method) -> Doppler time scaling
    + carrier offset -> optional per-path Rician fading -> AWGN at target SNR
RX  phy_ofdm_rx: chirp matched filter -> profile-matched postamble -> a_hat ->
    spline resampling -> Doppler CFO removal -> null-subcarrier residual CFO
    search -> FFT -> pilot LS + 3-symbol averaging + significant-tap selection
    -> one-tap equalisation -> max-log LLRs -> deinterleave -> fec_decode
    -> parse_packet (CRC, length) -> SR-ARQ bookkeeping -> reassemble_packets
    -> source_decode (only complete streams) -> image_quality_triplet
TIMELINE simulate_queue: FIFO / deadline policy, half-duplex link, ARQ turnarounds
```

Module interfaces are fixed structs (`enc`, `pk`, `layout`, `tx.meta`, `res`)
documented in each function header; e.g. any codec can be swapped without
touching the channel code because packetisation only sees `enc.bytes`.

## 5. Mathematical model

* **Compression ratio** CR = (H·W·C·8) / (8·|bytes|), bpp = 8|bytes|/(H·W).
* **Code rate** R_c = K/N; for a packet of L bits, n_B = ⌈L/K⌉ blocks,
  p = n_B K − L padding bits. LDPC: padding occupies the last systematic
  positions and is **shortened** (not transmitted; re-inserted at the
  receiver with LLR = +50); transmitted bits = n_B N − p. Polar: the p least
  reliable information positions of the last block are frozen to 0.
* **LLR convention** L = ln P(b=0|y)/P(b=1|y); QPSK (Gray, unit E_s):
  L = 2√2·Re(y)/N₀ (checked in Test F).
* **Channel** (complex baseband, sample rate f_s):
  r(t) = Σ_p g_p(t) s((1+a)t − τ_p) e^{j2π a f_c t} + n(t), with
  τ_p, |g_p| from the image method,
  |g_p| ∝ Γ_s^{n_s} Γ_b^{n_b} / √(l_p^k a(f_c)^{l_p/1000}), a = v/c,
  g_p(t) = g_p(√(K/(K+1)) + √(1/(K+1)) w_p(t)) for the time-varying model.
* **SNR definition** SNR = P_s/(N₀B), P_s = mean |x|² over the non-silent
  samples (channel normalised to unit power); AWGN of variance N₀ f_s is
  added. For OFDM the per-used-subcarrier E_s/N₀ = SNR·K/N_used = SNR·1024/928.
* **Doppler estimate** â = D_tx/D_rx − 1, D = preamble–postamble distance.
* **Metrics** (see `metrics/summarize_run.m` for exact scopes):
  BER_pre = coded-bit errors before decoding / transmitted coded bits;
  BER_post = info-bit errors after decoding / channel-encoder input bits
  (header+payload+CRC, all transmissions, padding excluded);
  BER_E2E_delivered = errors in delivered compressed bits / delivered bits;
  erasure rate = payload bits in unrecovered packets / all payload bits;
  BER_E2E_total = (errors + erased)/all payload bits (erasures counted as
  errors — conservative); PER_initial (first attempt), PER_attempt (per
  transmission), PER_final (after the retry policy); delivery rate = images
  completely recovered **and** decoded / images generated; goodput = compressed
  payload bits of successfully decoded images / time (several denominators,
  each stated where used); delay = t_delivered − t_generated.

## 6. Source coding design **[Executed]**

`source_encode`/`source_decode` give one interface for JPEG (`imwrite`
'Quality', baseline), JPEG XL (`cjxl -d <distance> -e 7`, `djxl`, libjxl 0.7.0),
PNG (lossless) and an optional learned codec (Python/CompressAI adapter,
**[Not executed]**: pretrained weights were not downloadable). The encoder's
output file is read back byte-for-byte; the locally decoded image I_c is
stored as the reference for channel distortion; lossless settings are checked
pixel-exactly. Images are normalised to 8 bits/sample (16-bit TIFF:
round(x/257), verified exact in Test P1).

## 7. Channel coding design **[Executed]**

* **QC-LDPC** (`ldpc_build.m`): 24 base columns, Z = 54 (N = 1296);
  base matrix [B_info | h_b | dual-diagonal] exactly as in the 802.11n
  encoder structure, but with our own reproducible shifts (deterministic LCG,
  greedy 4-cycle avoidance, verified girth ≥ 6 after lifting). Information
  columns have weight 3 (and weight 6 for 3 of 12 columns at R=1/2). Rates
  1/2, 2/3, 3/4, 5/6 (K = 648, 864, 972, 1080). Decoder: flooding normalised
  min-sum, α = 0.75, ≤ 50 iterations, per-codeword early stop on zero
  syndrome, vectorised over all blocks of a frame.
  *Validation:* BPSK/AWGN FER for R=1/2 ≈ 2.5 % at E_b/N₀ = 2.0 dB and 0 of
  200 words at 2.5 dB (scratch run during development, comparable to published
  N=1296 results for 802.11n-class codes). An earlier bit-level accumulator
  variant showed an error floor and was replaced (see the literature review).
* **Polar** (N = 1024, Bhattacharyya construction at 2 dB, SC decoding).
* **Framing** (`fec_encode/decode`): every padding bit is accounted for;
  Test E checks bit-exact decoding of messages of 1, 456, 1712 and 7992 bits.
* **Interleaver**: frame-level permutation from multiplicative hashing keyed by
  the frame counter (identical at TX/RX, independent of `rng`).

## 8. Underwater channel model **[Executed]**

| Item | Value |
|---|---|
| Carrier / band | f_c = 24 kHz, B = 8 kHz (complex baseband, OFDM f_s = 16 kHz) |
| Geometry | depth 30 m, Tx 10 m, Rx 18 m, range 1 km, c = 1500 m/s, isovelocity |
| Multipath | image method, up to 8 bounce orders, Γ_s = −0.9, Γ_b = 0.5, k = 1.5, Thorp absorption 5.69 dB/km at 24 kHz; 18 paths within 30 dB; delay spread 23.5 ms; direct-path TL 50.7 dB |
| Doppler | common time scaling a = v/c with v = 1 m/s (a = 6.67e-4, 16 Hz carrier offset = 2.05 subcarrier spacings) |
| Time variation | per-path Rician fading, K = 3, Jakes spectrum f_d = 0.5 Hz (16 sinusoids) |
| Noise | complex AWGN at the specified in-band SNR (Section 5) |
| Propagation delay | 0.667 s per direction, used in the timeline (not applied to samples) |
| Not modelled | ray refraction, nonuniform per-path Doppler, impulsive/colored noise, measured channels (none were available offline) |

## 9. Packetisation, CRC and receiver recovery **[Executed]**

Packet = image ID (16 b), sequence (16 b), total (16 b), payload length (16 b),
codec ID (8 b), flags (8 b), payload (≤ 200 B), CRC-32 (IEEE 802.3:
poly 0x04C11DB7, init 0xFFFFFFFF, reflected in/out, xorout 0xFFFFFFFF,
transmitted MSB-first) computed over header **and** payload. Overhead:
14 B per packet (7 % at 200 B payload). The receiver accepts a packet only if
the CRC matches **and** the length field is consistent; it identifies the
packet from its CRC-checked header. Selective-repeat ARQ: after each round
the receiver reports missing sequence numbers in a feedback frame
(64 + n_packets bits, sent with the same PHY; feedback assumed error-free);
at most 3 retry rounds; still-missing packets make the image **incomplete**,
it is not decoded and its payload bits are reported as erased.

## 10. Implementation and verification **[Executed]**

70+ MATLAB-language functions (`README.md` lists the folders). Test suite (19 groups, 19/19 pass on the final code)
(`tests/run_all_tests.m`, report in `results/logs/test_report.txt`):

| Test | What is verified (selected) |
|---|---|
| P1 | 6 formats (JPEG/PNG/BMP/TIFF 8/16-bit/gray/non-square) load with metadata; schedule IDs/times |
| A | PNG and JPEG XL d=0 pixel-exact; lossy codecs valid; truncated stream handled |
| B | real JPEG stream survives bytes→bits→bytes; MSB-first order |
| C | reassembly under shuffling, duplicates, foreign packets; missing / corrupted / bad-length packets detected |
| D | CRC check values; = Python zlib; all 1712 single-bit and 850 burst (≤ 32) patterns detected; 0 of 3000 random patterns missed |
| E | H·c = 0, systematic, no 4-cycles for 4 LDPC rates; framing exact for LDPC/polar/uncoded |
| F | Gray maps, QPSK LLR formula; SC and OFDM PHY bit-exact on the ideal channel incl. zero start offset |
| G | uncoded BER vs Q(√E_s/N₀): SC within 4–11 %, OFDM within 2–7 % at 2/5/8 dB |
| H | LDPC corrects all 1497 raw coded-bit errors (BER_pre 5.1e-2) at 4 dB; at −3 dB every residual-error packet fails CRC |
| I | injected failures → exactly those packets retransmitted; retry limit → image incomplete, bits erased |
| J | 2 real images through OFDM + multipath + Doppler at 10 dB: â = 6.66e-4 / 6.68e-4 (true 6.67e-4), BER_pre ≈ 5.5e-2 → 0, I_r == I_c |
| K | ideal channel: all BERs/PER = 0, stream identical; PNG I_r == I |
| L | 13 injected bit flips → BER_post numerator 13, CRC rejects exactly the 2 packets, erasures 3200 bits |
| M | FIFO order, half-duplex, queue growth; deadline policy drops stale images |
| N | Model E replay file loaded, validated, malformed file rejected; image delivered through it at 12 dB |
| O | fountain code: systematic decode, 4 erased source packets repaired, rank deficit reported, link delivery |
| P | ROI box inside image and 16-px aligned; two-layer composition exact on ideal channel; ROI PSNR > full PSNR |
| Q | AMC controller: robust without CSI, 16QAM at high SNR, pessimistic trend on falling SNR, rate-only mode |
| X | PSNR/SSIM = scikit-image to 1e-6; cjxl stream decoded by independent libjxl 0.12 within ±1 LSB |

Bugs found and fixed through these checks: LDPC error floor (structure),
OFDM channel-estimation loss of ~2 dB (fixed by significant-tap selection and
3-symbol pilot averaging), Doppler-scale outliers when fading changed the
strongest arrival between preamble and postamble (fixed by matching the whole
correlation profile and widening the CFO search to ±3 subcarriers), and a
synchronisation edge case for frames starting at the first sample.

## 11. Experimental methodology and results **[Executed]**

Common settings unless stated (`experiments/experiment_base.m`): images
euvp_01..04, JPEG q30 (≈ 0.68 bpp, ≈ 5.5 kB, ≈ 28 packets/image), 200 B
payloads, CRC-32, LDPC R=1/2, QPSK, OFDM, image-method multipath, ARQ off,
8 packets per frame. Seeds are `cfg.seed + offset` (logged per point in the
CSV files). Uncertainty: Wilson 95 % intervals for proportions in the CSVs.
Runtimes are in `results/logs/experiment_runtimes.txt`.

### 11.1 Experiment 1 — source codecs (23 images, no channel)

Two variants: native 256×256 frames and a 4-pixel shifted crop (252×252),
because the EUVP frames are themselves JPEG files and JPEG re-encoding on the
same 8×8 grid is artificially favoured (visible as jumps in the native JPEG
curve between q60 and q70). Results for the shifted variant (fairer):

| Codec / setting | bpp | CR | PSNR (dB) | SSIM | enc / dec (ms) |
|---|---|---|---|---|---|
| JPEG q30 | 0.666 | 40.6 | 32.19 | 0.931 | 4.2 / 2.7 |
| JPEG q50 | 0.920 | 29.2 | 34.15 | 0.955 | 4.1 / 2.7 |
| JPEG q80 | 1.537 | 17.2 | 37.44 | 0.978 | 4.3 / 2.6 |
| JPEG XL d=4 | 0.696 | 38.0 | 32.59 | 0.948 | 38 / 46 |
| JPEG XL d=3 | 0.829 | 31.9 | 33.35 | 0.960 | 41 / 44 |
| JPEG XL d=1.5 | 1.282 | 20.8 | 35.27 | 0.978 | 39 / 45 |
| PNG (lossless) | 11.98 | 2.1 | ∞ | 1 | 25 / 5 |
| JPEG XL d=0 (lossless) | 7.53 | 3.4 | ∞ | 1 | 150 / 62 |

Bjøntegaard delta rate of JPEG XL relative to JPEG (mean ± s.d. over 23
images): **+13.0 ± 18.8 % (PSNR)** and **−15.2 ± 5.0 % (SSIM)** for the shifted
variant (native: +15.2 % and −11.1 %). At 1.0 bpp (shifted) JPEG reaches
34.97 dB / 0.955 and JPEG XL 34.36 dB / 0.965. Lossless JPEG XL is 37 % smaller
than PNG. **Interpretation [Analysis]:** libjxl's encoder is perceptually
tuned, so it trades PSNR for structural fidelity; neither codec dominates on
these small (256×256), already-JPEG-compressed images. Times are host
wall-clock including file I/O and, for JPEG XL, process start-up, so they are
not codec-intrinsic speeds. The learned codec could not be evaluated
**[Not executed]**. Figures: `exp01_psnr_vs_bpp.png`, `exp01_ssim_vs_bpp.png`,
`exp01_cr_matched_quality.png`, `exp01_runtime.png`.

### 11.2 Experiment 2 — channel codes (same packets, no ARQ)

Packet error rate (first and only attempt), 4 images ≈ 110 packets per point:

| SNR (dB) | uncoded | LDPC 1/2 | polar 1/2 (SC) | LDPC 3/4 |
|---|---|---|---|---|
| AWGN 2 | 1.00 | 0.007 | 0.137 | 1.00 |
| AWGN 4 | 1.00 | 0 | 0 | 0.439 |
| AWGN 10 | 0.604 | 0 | 0 | 0 |
| AWGN 12 | 0.022 | 0 | 0 | 0 |
| Multipath 4 | 1.00 | 0.950 | 1.00 | 1.00 |
| Multipath 6 | 1.00 | **0** | 0.187 | 1.00 |
| Multipath 8 | 1.00 | 0 | 0 | 1.00 |
| Multipath 10 | 1.00 | 0 | 0 | 0.072 |
| Multipath 12–14 | 1.00 | 0 | 0 | 0 |

On the multipath channel the uncoded link never delivers a packet (pre-decoding
BER is still 2.3 % at 14 dB because some subcarriers sit in deep notches of the
static frequency response), while LDPC 1/2 is error-free from 6 dB.
The LDPC 1/2 waterfall is ≈ 2 dB earlier than polar 1/2 with SC decoding at a
similar block length (an SC list decoder would narrow this gap; **[Future]**),
and R=3/4 needs ≈ 6 dB more than R=1/2 on multipath (≈ 2 dB on AWGN): code
rate matters much more on the frequency-selective channel. No CRC-undetected
packet occurred in any experiment. Link goodput when error-free: uncoded
6553 b/s (AWGN 14 dB), LDPC 3/4 4983 b/s, LDPC 1/2 3501 b/s, polar 1/2 3113 b/s
(polar transmits full N=1024 blocks; LDPC shortening avoids sending padding).

### 11.3 Experiment 3 — SNR sweep with ARQ (multipath, 4 rates)

First-attempt PER ≤ 10 % is reached at a receiver-estimated SNR of
**3.7, 7.4, 9.0 and 11.1 dB** for R = 1/2, 2/3, 3/4, 5/6
(`exp05_thresholds.csv`, interpolated). Error-free link goodput rises from
3501 b/s (1/2) to 4675, 4983 and 5628 b/s. The receiver SNR estimate is
≈ 0.6–0.7 dB below the true in-band SNR on this channel (pilot/ICI effects).
Because the static multipath channel produces a sharp threshold, ARQ only
helps in a ≈ 1–2 dB window just above each waterfall (e.g. R=2/3 at 8 dB:
PER 0.151 → final 0).

### 11.4 Experiment 4 — channel models (LDPC 1/2, no ARQ)

| Configuration | first SNR (dB) with all 4 images delivered | BER_pre at 10 dB |
|---|---|---|
| OFDM, AWGN | 4 | 5.1e-4 |
| OFDM, multipath | 6 | 5.2e-2 |
| OFDM, multipath + Doppler (v = 1 m/s) | 8 | 5.5e-2 |
| OFDM, + Rician time variation | 8 | 5.8e-2 |
| OFDM, Doppler, **compensation off** | never (PER = 1 up to 14 dB) | 1.8e-1 |
| SC, AWGN | 4 | 8.3e-4 |
| SC, multipath (no equaliser) | never | 2.6e-1 |

Across the 23 images of Exp 9 (time-varying channel, 9 dB) the per-image mean
Doppler-scale estimate deviated from the true a = 6.67e-4 by −1.6e-6 on
average (largest deviation 1.6e-5), computed from the `aHat` fields of the
saved diagnostics. Without resampling, the residual CFO search
alone cannot track the accumulated time drift (2 ms over a 3 s frame). The
single-carrier baseline confirms the need for OFDM or an adaptive equaliser
on this channel.

### 11.5 Experiment 6 — retransmission (multipath, LDPC 1/2, interval 120 s)

| SNR | policy | PER init → final | delivered | mean latency | goodput incl. turnarounds | retransmitted bits / payload |
|---|---|---|---|---|---|---|
| 5 dB | no ARQ | 0.108 → 0.108 | 0/4 | — | 0 | 0 |
| 5 dB | SR-ARQ ≤ 1 retry | 0.129 → 0.036 | 2/4 | 19.6 s | 1279 b/s | 0.14 |
| 5 dB | SR-ARQ ≤ 3 retries | 0.151 → **0** | **4/4** | 20.5 s | 2546 b/s | 0.16 |
| 6 dB | no ARQ | 0 → 0 | 4/4 | 16.4 s | 3501 b/s | 0 |
| 6 dB | SR-ARQ ≤ 3 retries | 0 → 0 | 4/4 | 16.4 s | 3155 b/s | 0 |

ARQ rescues images in the waterfall region at the cost of about 4 s extra
latency per retry round (2 × 0.67 s propagation + feedback frame + resent
frame). When the channel is good, the final acknowledgement still costs
≈ 10 % of goodput (3501 → 3155 b/s) on the half-duplex link. At 4 dB
retries are wasted (2.9 × payload retransmitted, nothing delivered),
which motivates rate adaptation.

### 11.6 Experiment 7 — source rate × code rate under a latency budget

36 operating points (JPEG q ∈ {20, 40, 60, 80} × R ∈ {1/2, 2/3, 3/4} ×
SNR ∈ {5, 8, 11} dB), ARQ ≤ 3, 4 images each. With a 12 s per-image deadline
(utility = on-time fraction × SSIM): at 5 dB **no** point meets the deadline
(even q20/R1/2 needs 15.5 s); at 8 dB only q20 with R=1/2 (utility 0.448) or
R=2/3 (0.224) is feasible; at 11 dB q20 with R=2/3 or 3/4 delivers all four
images on time (utility 0.896) and q40/R=2/3 half of them (0.472). Latency grows
almost linearly with bpp (e.g. 11 dB, R=3/4: 8.6 s at q20, 22.8 s at q80).
Figures `exp07_utility_deadline12.png`, `exp07_latency.png`.

### 11.7 Experiment 8 — continuous source stability (multipath 10 dB, ARQ)

Measured mean service time per image: **19.2 s** (JPEG q50, ≈ 1 bpp) and
**10.3 s** (JPEG q20, ≈ 0.5 bpp). With the required **1 image/s camera the
utilisation is ρ = 19 (q50) and 10 (q20): the FIFO queue grows without bound**
(peak of 19 and 18 images waiting; mean delay 201 s and 103 s). In
`exp08_queue_length.png` the queue drains after ~20 s only because the
simulated camera stops after 20 images; the T = 30 s curves stay at 0. Stability
needs an interval ≥ 20 s (q50, ρ = 0.96, mean delay 24 s) or ≥ 15 s (q20,
ρ = 0.69, 9.4 s). A deadline policy (drop if waiting > 60 s) bounds the mean
delay of the delivered images to 47–66 s for all overloaded intervals, at the
price of discarding 16 (q50) or 12 (q20) of the 20 images at 1 image/s. Compression alone
therefore does **not** make the system stable at 1 image/s with this ~8 kHz
acoustic link; either the camera rate, the image size/quality or the bandwidth
must change (e.g. sending one image every 20 s, or region-of-interest crops).

### 11.8 Experiment 9 — full pipeline on all 23 images (JPEG XL d = 3, 0.82 bpp, time-varying channel)

| Run | channel | ARQ | delivered | PER (first) | BER_pre → BER_post | erasure rate | PSNR(I, I_r) |
|---|---|---|---|---|---|---|---|
| A | 9 dB | ≤ 3 | **23/23** | 0 | 6.7e-2 → 0 | 0 | 33.66 dB (= I_c) |
| C | 7 dB | off | 20/23 | 0.0051 | 9.5e-2 → 7e-5 | 0.42 % | 33.47 dB (20 images) |
| B | 5 dB | off | 0/23 | 0.286 | 1.3e-1 → 7.7e-3 | 28.7 % | — |

Run C shows the "cliff": only 4 of 786 packets were lost, but each lost packet
made its whole image undecodable (3 images). All five consistency rules
(Section `exp09_end_to_end.m`) held for 69/69 image runs: every delivered image
satisfied I_r == I_c bit-exactly, every incomplete image had lost packets and
was not decoded, erased bits matched the lost packets byte-exactly, and
PER_final·n equalled the number of lost packets. Example panels:
`exp09_A_examples.png`, `exp09_C_examples.png`.

### 11.9 Experiment 5 — fixed vs adaptive LDPC rate

Setup: 5 SNR traces (s_k = 8 + 5 sin(2πk/12) + N(0,1) dB, seeds 7–11) × 16
images, multipath, JPEG q30, ARQ ≤ 3, camera interval 30 s, paired design.
The adaptive rule uses the Exp-3 thresholds (estimated SNR for first-attempt
PER ≤ 10 %: 3.7 / 7.4 / 9.0 / 11.1 dB for R = 1/2 / 2/3 / 3/4 / 5/6) plus a
1 dB margin, applied to the **previous** image's SNR estimate.

| Policy | delivered (95 % CI) | PER first / final | goodput incl. turnarounds | mean rate |
|---|---|---|---|---|
| fixed R=1/2 | **65/80 = 0.81** [0.71, 0.88] | 0.194 / 0.172 | **1573 b/s** | 0.50 |
| fixed R=3/4 | 40/80 = 0.50 [0.39, 0.61] | 0.520 / 0.513 | 747 b/s | 0.75 |
| adaptive | 59/80 = 0.74 [0.63, 0.82] | 0.251 / 0.224 | 1422 b/s | 0.61 |

Paired per-image comparison: adaptive delivered 20 images that fixed R=3/4
lost and lost only 1 it delivered; but against fixed R=1/2 it delivered **no**
extra image and lost 6. **This is a negative result for the rule as
configured.** Five of the six losses are image 6 of each trace, where the
trace falls by ≈ 3 dB between consecutive images: the controller, acting on
the previous image's estimate (≈ 10 dB), selects R = 3/4, and the current SNR
(6.4–6.8 dB) is below that rate's cliff on the static multipath channel. The
sixth (trace 8, image 5) used R = 5/6 at a true SNR of 11.2 dB, right at that
rate's threshold.
The 1 dB margin is smaller than the image-to-image SNR change (σ = 1 dB noise
plus up to 2.6 dB deterministic slope), and with a channel whose PER curves
are near-vertical, a wrong guess costs the whole image. The adaptive policy
nevertheless dominates the aggressive fixed rate, and its mean rate (0.61)
shortened service when it was right; a margin tied to the measured SNR
variability, or channel prediction as in Radosevic et al., is the obvious
next step **[Future]**. Figures: `exp05_adaptive_trace.png`, `exp05_goodput.png`.

### 11.10 Experiment 10 — deadline-aware joint source/channel selection

Setup: 5 SNR traces (seeds 7–11) × 16 images = 80 images per policy, deadline 12 s, ARQ ≤ 3, paired design.

| Policy | on time (95 % CI) | utility | SSIM of on-time images | mean latency | bpp |
|---|---|---|---|---|---|
| fixed q40 R1/2 | 19/80 = 0.24 [0.16, 0.34] | 0.228 | 0.962 | 14.2 s | 0.72 |
| fixed q60 R1/2 | 1/80 = 0.01 [0.00, 0.07] | 0.012 | 0.988 | 21.8 s | 1.13 |
| fixed q40 R3/4 | 28/80 = 0.35 [0.26, 0.46] | 0.334 | 0.954 | 10.0 s | 0.72 |
| rate-only adaptive q40 | 28/80 = 0.35 [0.26, 0.46] | 0.335 | 0.957 | 12.8 s | 0.72 |
| **JSCC adaptive** | **51/80 = 0.64 [0.53, 0.73]** | **0.579** | 0.909 | 9.5 s | 0.50 |

Paired: JSCC was on time for 23–50 images where another policy was late, and
**never** late where another policy was on time. The CI of JSCC does not
overlap any baseline's. The gain comes from dropping image quality (SSIM 0.91
vs 0.95–0.96) when the deadline cannot otherwise be met — the hypothesis of
Section 3 is supported for this simulated setup, with the limitations listed
in Section 13 (table measured on the same channel model, small image set).

## 11b. Second iteration: added and modernised components **[Executed]**

After a requirement-by-requirement re-check of the original prompt
(`docs/REQUIREMENTS_TRACE.md`) the following were added. Each has unit tests
(N, O, P, Q and additions to E, K) and the experiments below.

* **Whole-stream integrity record** — CRC-32 of every compressed file,
  re-checked after reassembly; a mismatching stream is never decoded (Test K).
* **Channel Model E (replay)** — time-varying impulse responses loaded from a
  file (`load_replay_channel`), applied sample by sample. The bundled file is
  **synthetic** (generated from the Model D statistics by
  `tools/make_replay_example.m`) and only validates the interface; no measured
  sounding was available offline (Test N: image delivered at 12 dB).
* **Reed–Solomon RS(255,223)** — systematic GF(256) encoder,
  Berlekamp–Massey / Chien / Forney decoder, shortened per packet (Test E:
  corrects 16 byte errors, flags 20 as uncorrectable).
* **CA-SCL polar decoding** — list size 8 with a CRC-16 per block (Tal &
  Vardy). On BPSK/AWGN with N = 1024, R ≈ 1/2: frame error rate 0.81 → 0.31
  at Es/N0 = −2 dB, 0.52 → 0.03 at −1.5 dB and 0.15 → 0 at −1 dB vs SC
  (100 codewords per point).
* **Packet-level fountain code** — systematic random linear code over GF(2)
  with Gaussian-elimination decoding; replaces "resend packet n" by "send any
  new symbols"; burst size from an a-priori loss estimate (Test O).
* **ROI-aware two-layer coding, UEP and ROI-only retransmission** —
  spectral-residual saliency (Hou & Zhang 2007) selects the region; base layer
  = whole image JPEG q15, ROI layer = crop JPEG q70 (Test P).
* **Adaptive modulation and coding** — QPSK/16QAM × LDPC rates with a
  variability-aware controller (Test Q; Exp 5b).
* **Deep JSCC** — a learned joint source–channel encoder/decoder trained
  through the OFDM underwater channel and evaluated through the real Octave
  receiver (Exp 12).

### 11.11 Experiment 11 — ROI coding, UEP and quality-aware retransmission

Images euvp_01..08, multipath, no ARQ unless stated, 8 images per point;
displayed image = decoded layers, gray where a layer is missing.

| Scheme | coded bits / image | ROI delivered from | ROI PSNR when delivered | full-image PSNR at 6–8 dB |
|---|---|---|---|---|
| A single layer q*, R=2/3 | 108 k | 10 dB | 35.1 dB | 11.6 dB (lost) |
| B two-layer EEP R=2/3 | 106 k | 10 dB | 41.8 dB | ≤ 13.7 dB (lost) |
| C two-layer UEP (ROI 1/2, base 3/4) | 131 k | **6 dB** | 41.8 dB | 13.4 dB (base lost) |
| D = C + ROI-only ARQ (≤ 3) | 131–146 k | **5 dB** | 41.8 dB | 13.4 dB |
| E two-layer EEP R=1/2 | 151 k | 6 dB | 41.8 dB | **32.9 dB** |
| F single layer q*, R=1/2 | 153 k | 6 dB (7 of 8) / 7 dB | 35.1 dB | 33.9–36.1 dB |

Findings: (i) at the same protection (E vs F, ≈ equal coded bits) two-layer
ROI coding gives **+6.7 dB ROI PSNR** (41.8 vs 35.1 dB) at the cost of
≈ 3 dB whole-image PSNR — it moves bits to where the subject is.
(ii) UEP (C) delivers the ROI at the same SNR as full R=1/2 protection (E) with
13 % fewer coded bits, but its R=3/4 base layer is lost below 10 dB; UEP is
worthwhile only when the background matters little. (iii) Retransmitting only
the ROI layer (D) extends ROI delivery down to 5 dB. ROI detection is a simple
saliency method (it picked coral rather than the fish in euvp_03).
Figures `exp11_roi_quality.png`, `exp11_example_6dB.png`.

### 11.12 Experiment 13 — added channel codes and fountain recovery

Part A, packet error rate without ARQ (2 images, 83 packets per point):

| SNR | LDPC 1/2 | polar SC 1/2 | polar CA-SCL8 1/2 | RS(255,223) |
|---|---|---|---|---|
| AWGN 1 dB | 0.747 | 1.000 | **0.361** | 1.000 |
| AWGN 2 dB | 0.012 | 0.072 | **0** | 1.000 |
| AWGN 8 dB | 0 | 0 | 0 | 0.012 |
| AWGN 10 dB (goodput) | 3495 b/s | 3113 b/s | 3113 b/s | **6029 b/s** |
| multipath 5 dB | 0.157 | 0.904 | **0.120** | 1.000 |
| multipath 6 dB | 0 | 0.181 | 0 | 1.000 |
| multipath 14 dB | 0 | 0 | 0 | **1.000** |

CA-SCL closes the ≈ 1 dB gap between SC polar and our LDPC and is slightly
better than LDPC near threshold (decoding cost ≈ 0.15 s per codeword in
Octave). Hard-decision RS at rate 0.87 is the most efficient code on a clean
AWGN link but **never works on the static multipath channel** (subcarriers in
spectral notches produce byte-error bursts beyond t = 16) — soft-decision
codes are essential here.

Part B, fountain vs selective-repeat ARQ (multipath, LDPC 1/2, 4 images):

| SNR | SR-ARQ: delivered / occupation per image | fountain (10 % sizing) | fountain (25 % sizing) |
|---|---|---|---|
| 4.5 dB | 0/4, 39.3 s | 1/4, 44.2 s | **4/4**, 46.8 s |
| 5.0 dB | 3/4, 23.8 s | **4/4**, 22.4 s | 4/4, 24.0 s |
| 5.5 dB | 4/4, **18.0 s** | 4/4, 20.4 s | 4/4, 24.0 s |
| ≥ 6 dB | 4/4, **17.4 s** (3501 b/s) | 4/4, 20.4 s (2932 b/s) | 4/4, 24.0 s (2466 b/s) |

(Re-run after a generator fix: the first fountain-coefficient generator
produced correlated rows for some stream sizes, found when the MATLAB run of
Test O used K = 22; Test O now checks every K from 10 to 60.)
The fountain code wins at the margin (all 4 images at 4.5 dB with 25 % sizing
vs 0 for ARQ, because any new symbol repairs any loss) and loses 16–30 % goodput on good channels,
where its proactive redundancy is unnecessary. The redundancy should
therefore be adapted to the measured loss rate — a natural extension of the
AMC controller.

### 11.13 Experiment 5b — adaptive modulation and coding, improved controller

16QAM thresholds were measured first (multipath, ARQ ≤ 3; first-attempt
PER ≤ 10 % at an estimated SNR of 9.5 dB for 16QAM R=1/2 and 14.9 dB for R=3/4,
vs 3.7 / 7.4 / 9.0 / 11.1 dB for QPSK R=1/2 … 5/6). The v2 controller
(`amc_controller.m`) predicts pessimistically from the last two estimates and
uses a margin of 0.5 dB + 1.5 × (RMS image-to-image SNR change). Same five
traces × 16 images as Exp 5 (paired):

| Policy | delivered (95 % CI) | goodput incl. turnarounds | mean code rate | 16QAM use |
|---|---|---|---|---|
| fixed QPSK R=1/2 | **65/80 = 0.81** [0.71, 0.88] | **1573 b/s** | 0.50 | 0 % |
| Exp-5 rule (v1) | 59/80 = 0.74 [0.63, 0.82] | 1422 b/s | 0.61 | 0 % |
| v2 rate-only | 63/80 = 0.79 [0.69, 0.86] | 1513 b/s | 0.53 | 0 % |
| v2 rate + modulation | 64/80 = 0.80 [0.70, 0.87] | 1554 b/s | 0.53 | 1.3 % |

Paired against fixed R=1/2, v1 lost 6 images that the fixed rate delivered,
v2 rate-only lost 2 and v2 with modulation lost 1; none of the adaptive
policies delivered an image the fixed rate lost. The improved controller
removes most of the v1 failures, but **on this trace (3–14 dB) and this static
multipath channel no adaptive policy beats the robust fixed rate**; the
differences are within the confidence intervals. 16QAM was almost never
selected because its thresholds (9.5 / 14.9 dB plus margin) sit near the top of
the trace. AMC would pay off on links that stay well above ~12 dB, or with
channel prediction; we report the negative result as measured.

### 11.14 Experiment 12 — Deep JSCC vs separated digital coding (same channel symbols)

Model: fully convolutional encoder/decoder with SNR (FiLM) conditioning,
1.52 M parameters, latent of 16384 complex symbols per 256×256 image
(bandwidth ratio 1/12), trained for 3000 steps (batch 16, 128×128 crops) on
CPU through a differentiable model of the same OFDM grid and image-method
channel with Rician perturbation (training images: euvp_01–17, their EUVP
enhanced versions, 5 scikit-image photos; final training-batch PSNR ≈ 24 dB).
Evaluation on the **held-out** images euvp_18–23 through the real Octave
transmitter, channel and receiver (`cfg.mod.scheme = 'analog'`: pilot-based
channel estimation, LMMSE-equalised symbols handed to the decoder). Digital
baselines use the highest JPEG / JPEG XL quality whose packets fit the same
16384 QPSK symbols at LDPC R = 1/2 or 3/4 (≈ 0.22–0.36 bpp), no ARQ; a lost
image is displayed as flat gray (PSNR 10.5 dB).

| SNR | Deep JSCC PSNR / SSIM | best digital (genie choice per image) PSNR / SSIM | digital images delivered |
|---|---|---|---|
| 0 dB | **22.8 / 0.58** | 10.5 / 0.37 (all lost) | 0 % |
| 2 dB | **23.1 / 0.59** | 10.5 / 0.37 | 0 % |
| 4 dB | **23.4 / 0.59** | 10.5 / 0.37 | 0 % |
| 6 dB | 23.5 / 0.60 | **25.4 / 0.74** (multipath), 23.3 / 0.69 (time-varying) | 100 % / 83 % |
| 8 dB | 23.7 / 0.60 | **25.6 / 0.75** | 100 % |
| 12 dB | 23.9 / 0.60 | **27.5 / 0.81** | 100 % |

(multipath and time-varying rows are within 0.1 dB for Deep JSCC.)
**Deep JSCC degrades gracefully:** it delivers a recognisable image at every
tested SNR, including 0–4 dB where every digital option loses the whole
image, and it needs no feedback round trip. **Above ≈ 6 dB the separated
system wins** by 2–4 dB PSNR and ≈ 0.15–0.2 SSIM, because our small model,
trained on 39 images on a CPU, saturates at ≈ 24 dB and produces smooth,
detail-poor reconstructions (`exp12_examples_6dB.png`). This reproduces the
qualitative behaviour reported for Deep JSCC in the literature; closing the
high-SNR gap needs a larger model, far more underwater training images and
GPU training (**[Future]**). Encoder SNR = true SNR (assumed fed back);
decoder SNR = receiver estimate. Figures `exp12_deep_jscc_psnr.png`,
`exp12_deep_jscc_ssim.png`.

## 12. Discussion

1. **The link, not the codec, dominates.** Between JPEG and JPEG XL the
   difference at equal quality is ±15 % in rate; between LDPC 1/2 and 3/4 the
   required SNR differs by 6 dB on multipath, and ARQ turnarounds add ≈ 4 s.
2. **All-or-nothing decoding.** Standard JPEG/JPEG XL files need every packet;
   one lost packet in ~30 destroys the image (Exp 9 C). ARQ or erasure coding
   is therefore essential, and progressive/UEP or learned JSCC schemes are
   attractive to soften this cliff **[Future]**.
3. **Queue stability is a first-order design constraint**: at 1 image/s even
   0.5 bpp images overload the link by 10×.
4. **Adaptation** helps only when the CSI is fresh relative to the channel's
   variation and when thresholds include enough margin (Exp 5, 5b: even the
   improved AMC controller only matches a robust fixed rate on this channel);
   combining it with source-rate selection under an explicit deadline is where
   the gains appear (Exp 10).
5. **Where each modern technique helps (second iteration).** Learned JSCC
   (Exp 12) removes the cliff at low SNR but loses at high SNR with our small
   model; fountain coding (Exp 13B) helps at the margin and costs goodput on
   good links; CA-SCL makes polar codes competitive with LDPC; ROI coding
   (Exp 11) buys +6.7 dB on the subject for −3 dB on the background. No single
   technique dominates everywhere — the best system switches between them
   according to SNR and the application's priorities, which is the natural
   design for a future controller.

## 13. Limitations

* Experiments were executed in GNU Octave 8.4. The test suite was also run
  in **MATLAB Online** by the user (October 2026): 18/19 groups passed on
  first run; the one failure (Test O) exposed a real bug in the fountain
  generator, fixed and re-verified, and two MATLAB portability issues
  (Octave-only `OCTAVE_VERSION` reference, zero-size invisible figures in
  MATLAB Online) were fixed in `platform_str.m` and `save_figure.m`. MATLAB and Octave
  random generators differ, so MATLAB numbers will differ statistically.
* LDPC matrices are our own QC family (802.11n structure), not the standard tables.
* Channel: geometric isovelocity multipath with rounded sample delays, a
  common Doppler scale, Rician fading with independent draws per frame,
  white Gaussian noise; no measured channel replay (no data available
  offline). Propagation loss is not applied to the waveform — SNR is the
  controlled variable.
* Frame-format side information (number of OFDM symbols, packet slot
  lengths) is assumed known at the receiver; the feedback channel is error-free.
* Small sample sizes: 4 images per sweep point (≈ 110 packets), 16–80 images
  in the adaptation studies; differences inside the reported CIs are not significant.
* The EUVP images are already JPEG-compressed 256×256 frames; codec
  comparisons on raw camera data may differ.
* Processing times are wall-clock times of an interpreted implementation and
  external processes; they are included in the timeline but are not
  representative of embedded hardware.
* Pretrained learned codecs (CompressAI) and UIEB/RUIE datasets not used
  (network policy). The Deep JSCC model was trained here on only 39 images on
  CPU (3000 steps); it is a proof of concept, not an optimised model.
* Channel Model E was validated with a synthetic replay file only.
* ROI detection is a simple saliency method; the UEP/EEP schemes of Exp 11 do
  not all use identical coded-bit budgets (budgets are reported).
* The single-carrier baseline has no multipath equaliser.

## 14. Conclusion

The project delivers a working, tested, end-to-end simulator in which real
compressed underwater images traverse a realistic acoustic OFDM link and are
reconstructed bit-exactly whenever all packets survive. The measurements
quantify where the system's limits lie — channel-code rate and Doppler
handling at the physical layer, the decodability cliff at the application
layer, and queue stability at the system level — and they show that
selecting source and channel rates jointly under an explicit latency budget is
a more productive lever than either codec choice or channel-rate adaptation
alone. The second iteration added the modern components — Deep JSCC,
CA-SCL polar, fountain coding, ROI-aware UEP, AMC and channel replay — and
measured exactly where each helps: Deep JSCC at low SNR, CA-SCL near the
coding threshold, fountain codes at the margin, ROI coding for subject
quality.

## 15. Future work

Larger Deep JSCC models trained on GPU with thousands of underwater images,
and a hybrid controller that switches between Deep JSCC (low SNR) and
separated coding (high SNR); adaptive fountain redundancy driven by the
measured loss rate; non-binary or longer LDPC codes; adaptive DFE for the
single-carrier mode; measured-channel replay (e.g. Watermark-type data);
erasure (fountain) coding across packets to replace ARQ round trips;
progressive JPEG / JPEG XL progressive passes or ROI coding with unequal error
protection; learned codecs and deep JSCC on a machine with model weights;
a denser Exp-7 table and online learning of the operating-point table.

## 16. References

See `docs/LITERATURE_REVIEW.md` for the annotated list with verification
status. Principal items: Stojanovic (ACM MC2R 2007); Stojanovic & Preisig
(IEEE Commun. Mag. 2009); Li, Zhou, Stojanovic, Freitag, Willett (IEEE JOE 33,
198–209, 2008); Radosevic et al. (IEEE JOE 39(2), 357–370, 2014);
Al-Kadhimi et al. (Acta Polytechnica 64(2), 2024); Arıkan (IEEE TIT 2009);
IEEE Std 802.11n-2009; Alakuijala et al. (SPIE 11137, 2019); Sneyers et al.
(arXiv:2506.05987, 2025); Wang et al. (IEEE TIP 2004); Bjøntegaard (VCEG-M33,
2001); Islam, Xia, Sattar (IEEE RA-L 2020, EUVP); Pelekanakis (MIT S.M. thesis,
2004); Esmaiel et al. (Sensors 2019); Bourtsoulatze, Kurka, Gündüz (IEEE TCCN
2019); Anjum, Qi, Pompili (WUWNet 2022).
