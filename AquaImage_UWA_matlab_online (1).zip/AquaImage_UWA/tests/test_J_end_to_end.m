function test_J_end_to_end()
%TEST_J_END_TO_END Real compressed underwater image through the complete chain
%   (OFDM, image-method multipath + Doppler, LDPC 1/2, ARQ) and back.
cfg = test_config();
cfg.chan.model = 'doppler';
cfg.chan.snrDb = 10;
cfg.source.numImages = 2;
set_seed(15);
S = run_link_simulation(cfg, struct('tag', 'test_J', 'saveArtifacts', false));
for k = 1:2
    e = S.perImage(k);
    check(e.success && e.streamIdentical && e.IcEqualsIr, ...
        'img %d: %d B JPEG in %d pkts, BER_pre %.2e -> BER_post %.1e, Doppler a_hat %.2e (true %.2e), I_r == I_c, PSNR(I,I_r) %.2f dB', ...
        k - 1, e.compBytes, e.nPkts, e.preErr / e.preN, e.postErr / e.postN, e.aHat, cfg.chan.velocity_mps / cfg.chan.c, e.psnr_I_Ir);
end
end
