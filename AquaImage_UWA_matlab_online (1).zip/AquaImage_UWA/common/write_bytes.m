function write_bytes(fname, b)
%WRITE_BYTES Write a uint8 vector to a file exactly as given.
fid = fopen(fname, 'wb');
if fid < 0
    error('write_bytes:open', 'Cannot create file %s', fname);
end
fwrite(fid, uint8(b(:)), 'uint8');
fclose(fid);
end
