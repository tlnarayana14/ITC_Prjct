function test_M_continuous_source()
%TEST_M_CONTINUOUS_SOURCE Several images enter the FIFO queue and are served in order.
cfg = test_config();
cfg.chan.model = 'ideal';
cfg.source.numImages = 4;
cfg.source.interval_s = 1.0;
set_seed(18);
S = run_link_simulation(cfg, struct('tag', 'test_M', 'saveArtifacts', false));
tl = S.timeline;
check(all(diff(tl.tStart) > 0), 'images start transmission in generation order');
check(all(tl.tStart(2:end) >= tl.tEnd(1:end - 1) - 1e-9), 'half-duplex link: next image starts after the previous one releases the link');
check(all([S.perImage.success]), 'all 4 images delivered');
check(all(diff(tl.tDelivered) > 0), 'delivery order equals generation order');
svc = tl.tEnd(1) - tl.tStart(1);
check(svc > cfg.source.interval_s && max(tl.Q) >= 1, 'service time %.1f s > 1 s interval -> queue builds up (max %d waiting)', svc, max(tl.Q));
check(all(tl.wait(2:end) > 0) && all(diff(tl.wait) > 0), 'waiting time grows image after image (%s s)', mat2str(round(10 * tl.wait) / 10));
% deadline policy drops stale images
cfg.queue.policy = 'deadline'; cfg.queue.deadline_s = 30;
S2 = run_link_simulation(cfg, struct('tag', 'test_M', 'saveArtifacts', false));
check(any(S2.timeline.dropped) && S2.summary.nDropped == nnz(S2.timeline.dropped), 'deadline 30 s: %d stale image(s) dropped and counted as lost', S2.summary.nDropped);
end
