function [out, frameKey] = transmit_roi_uep(I, bb, imageId, cfg, opt, frameKey)
%TRANSMIT_ROI_UEP Two-layer ROI-aware transmission with (un)equal error protection.
%
%   Layers (both real JPEG files, each packetised/protected/sent with
%   TRANSMIT_IMAGE under its own image ID):
%     base : the whole image at low quality  opt.qBase, code rate opt.rBase
%     roi  : the ROI crop bb at high quality opt.qRoi, code rate opt.rRoi
%   opt.arqRoi / opt.arqBase : max retries per layer (image-quality-aware
%   retransmission: e.g. retransmit only the ROI layer).
%   Receiver composition (nothing is invented):
%     base decoded -> canvas = base;  otherwise canvas = flat gray (no data)
%     ROI decoded  -> ROI pixels of the canvas replaced by the ROI layer
%   out: displayed image Iout, flags baseOk/roiOk, bytes and coded bits per
%   layer, airtime, and the per-layer TRANSMIT_IMAGE results.
r = bb(1):bb(1) + bb(3) - 1; c = bb(2):bb(2) + bb(4) - 1;
cb = cfg; cb.codec.jpegQuality = opt.qBase; cb.fec.rate = opt.rBase;
cb.arq.enabled = opt.arqBase > 0; cb.arq.maxRetries = opt.arqBase;
cr = cfg; cr.codec.jpegQuality = opt.qRoi; cr.fec.rate = opt.rRoi;
cr.arq.enabled = opt.arqRoi > 0; cr.arq.maxRetries = opt.arqRoi;
encB = source_encode(I, cb);
encR = source_encode(I(r, c, :), cr);
[resR, frameKey] = transmit_image(encR, 2 * imageId + 1, cr, fec_setup(cr), frameKey);   % ROI first (priority)
[resB, frameKey] = transmit_image(encB, 2 * imageId, cb, fec_setup(cb), frameKey);
Iout = uint8(128 * ones(size(I)));          % flat gray = 'no data'
if resB.success, Iout = resB.Ir; end
if resR.success, Iout(r, c, :) = resR.Ir; end
out.Iout = Iout; out.baseOk = resB.success; out.roiOk = resR.success;
out.bytes = numel(encB.bytes) + numel(encR.bytes);
out.bytesBase = numel(encB.bytes); out.bytesRoi = numel(encR.bytes);
out.coded = resB.bits.coded + resR.bits.coded;
out.airtime = sum(resB.segments(:, 2)) + sum(resR.segments(:, 2));
out.Ic = encB.Ic; out.Ic(r, c, :) = encR.Ic;              % error-free two-layer reference
out.resB = resB; out.resR = resR;
end
