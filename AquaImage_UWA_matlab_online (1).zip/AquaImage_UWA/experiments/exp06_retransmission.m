function T = exp06_retransmission()
%EXP06_RETRANSMISSION Experiment 6: no ARQ vs selective-repeat ARQ (1 and 3 retries)
%   on the multipath channel around the LDPC R=1/2 waterfall (3..8 dB).
%   The camera interval is set to 120 s so that the reported delay is the
%   per-image service latency (no queueing): data airtime + ARQ turnarounds
%   (2 x 0.67 s propagation + feedback frame) + receiver decoding.
%   Overheads: retransmitted packet bits and feedback bits relative to the
%   compressed payload actually delivered.
base = experiment_base();
base.source.interval_s = 120;
snrs = [3 4 5 6 8];
v = struct('name', {}, 'apply', {});
v(end + 1) = struct('name', 'no ARQ', 'apply', @(c) seta(c, false, 0));
v(end + 1) = struct('name', 'SR-ARQ, max 1 retry', 'apply', @(c) seta(c, true, 1));
v(end + 1) = struct('name', 'SR-ARQ, max 3 retries', 'apply', @(c) seta(c, true, 3));
T = link_sweep(base, v, snrs, 'exp06');
for i = 1:numel(T)
    T(i).retxOverhead = T(i).retxInfoBits / max(T(i).payloadBits, 1);
    T(i).feedbackOverhead = T(i).feedbackBits / max(T(i).payloadBits, 1);
    % useful bits per second of link occupation (data frames + turnarounds)
    T(i).busyGoodput_bps = T(i).linkGoodput_bps * T(i).airtime_s / (T(i).airtime_s + T(i).turnaround_s);
end
rd = base.out.resultsDir; fd = fullfile(rd, 'figures');
save_sweep(T, fullfile(rd, 'tables', 'exp06_retransmission.csv'));
plot_sweep(T, 'PER_final', 'final packet loss rate', 'Exp 6: unrecovered packets (multipath, LDPC 1/2)', fullfile(fd, 'exp06_per_final.png'), true, 1e-4);
plot_sweep(T, 'deliveryRate', 'image delivery success', 'Exp 6: image delivery with/without ARQ', fullfile(fd, 'exp06_delivery.png'), false);
plot_sweep(T, 'meanDelay_s', 'mean latency of delivered images (s)', 'Exp 6: latency (no queueing)', fullfile(fd, 'exp06_latency.png'), false);
plot_sweep(T, 'busyGoodput_bps', 'goodput (useful bit/s of link occupation)', 'Exp 6: useful throughput incl. ARQ turnarounds', fullfile(fd, 'exp06_goodput.png'), false);
plot_sweep(T, 'retxOverhead', 'retransmitted bits / payload bits', 'Exp 6: retransmission overhead', fullfile(fd, 'exp06_retx_overhead.png'), false);
end

function c = seta(c, on, n)
c.arq.enabled = on; c.arq.maxRetries = n;
end
