function [img, note] = preprocess_image(img, cfg)
%PREPROCESS_IMAGE Optional, documented preprocessing before source coding.
%
%   [img, note] = PREPROCESS_IMAGE(img, cfg)
%     img : uint8 H x W x C (C = 1 or 3)
%     cfg.source.maxDim  : 0 = no resizing; otherwise downscale (bilinear,
%                          with a box pre-filter) so max(H,W) <= maxDim
%     cfg.source.forceRGB: replicate a grayscale image to 3 channels
%   No toolbox functions are used (interp2/conv2 are core MATLAB/Octave).

note = 'none';
if ~isa(img, 'uint8')
    error('preprocess_image:class', 'Expected uint8 input.');
end
if cfg.source.maxDim > 0 && max(size(img, 1), size(img, 2)) > cfg.source.maxDim
    s = cfg.source.maxDim / max(size(img, 1), size(img, 2));
    H = size(img, 1); W = size(img, 2);
    Hn = max(1, round(H * s)); Wn = max(1, round(W * s));
    f = max(1, round(1 / s));
    k = ones(f) / f^2;                                  % anti-alias box filter
    [xq, yq] = meshgrid(linspace(1, W, Wn), linspace(1, H, Hn));
    out = zeros(Hn, Wn, size(img, 3));
    for c = 1:size(img, 3)
        ch = conv2(double(img(:, :, c)), k, 'same');
        out(:, :, c) = interp2(ch, xq, yq, 'linear');
    end
    img = uint8(round(out));
    note = sprintf('downscaled %dx%d -> %dx%d', W, H, Wn, Hn);
end
if cfg.source.forceRGB && size(img, 3) == 1
    img = repmat(img, [1 1 3]);
    if strcmp(note, 'none'), note = 'gray->RGB'; else, note = [note '; gray->RGB']; end
end
end
