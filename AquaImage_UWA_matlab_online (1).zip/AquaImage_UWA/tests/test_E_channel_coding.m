function test_E_channel_coding()
%TEST_E_CHANNEL_CODING Code construction, encoding, framing, error-free decoding.
cfg = test_config();
set_seed(11);
for R = [1/2 2/3 3/4 5/6]
    code = ldpc_build(R, 54, 1);
    u = randi([0 1], code.K, 20);
    cw = ldpc_encode(code, u);
    check(nnz(mod(code.H * cw, 2)) == 0, 'LDPC R=%s N=%d K=%d: H*c = 0 for 20 random words', rate_str(R), code.N, code.K);
    check(isequal(cw(1:code.K, :), u), 'LDPC R=%s is systematic', rate_str(R));
    G = code.H * code.H.'; G = G - diag(diag(G));
    check(full(max(G(:))) <= 1, 'LDPC R=%s Tanner graph has no 4-cycles', rate_str(R));
    [uh, inf] = ldpc_decode(code, 10 * (1 - 2 * cw), 50, 0.75);
    check(isequal(uh, u) && all(inf.iterations <= 1), 'LDPC R=%s noiseless decoding exact', rate_str(R));
end
% framing / shortening with real packet lengths (not multiples of K)
for codeName = {'ldpc', 'polar', 'polar_scl', 'none'}
    c = cfg; c.fec.code = codeName{1}; c.fec.rate = 1/2;
    fec = fec_setup(c);
    Ls = [8 * 214, 8 * 57, 8 * 999, 1];
    msgs = arrayfun(@(L) randi([0 1], L, 1), Ls, 'UniformOutput', false);
    [coded, lay] = fec_encode(fec, msgs);
    switch fec.type
        case 'ldpc', expTx = sum(arrayfun(@(l) l.nBlocks * fec.N - l.pad, lay));
        case {'polar', 'polar_scl'}, expTx = sum([lay.nBlocks]) * fec.N;
        case 'none', expTx = sum(Ls);
    end
    check(numel(coded) == expTx, '%s: transmitted bits %d = blocks*N minus shortened padding (pad total %d)', fec.type, numel(coded), sum([lay.pad]));
    dec = fec_decode(fec, 20 * (1 - 2 * coded), lay);
    check(isequal(dec, msgs), '%s: 4 messages of %s bits decode exactly with no channel errors', fec.type, mat2str(Ls));
end
% Reed-Solomon (byte-oriented): exact framing and correction of up to t byte errors
c = cfg; c.fec.code = 'rs'; fec = fec_setup(c);
msgs = {randi([0 1], 8 * 214, 1), randi([0 1], 8 * 500, 1)};
[coded, lay] = fec_encode(fec, msgs);
check(numel(coded) == 8 * (214 + 32 + 500 + 3 * 32), 'RS(255,223): 214 B -> 246 B; 500 B -> 3 blocks (223+223+54 B, +96 B parity)');
llr = 10 * (1 - 2 * coded);
bytePos = [3 40 77 100 150 200 210 220 230 240 241 242 243 244 245 246];      % 16 byte errors in block 1
for b = bytePos, llr(8 * (b - 1) + 4) = -llr(8 * (b - 1) + 4); end
dec = fec_decode(fec, llr, lay);
check(isequal(dec, msgs), 'RS corrects 16 byte errors in one codeword (t = 16) and decodes both messages exactly');
% polar ordering sanity: reliable set must decode noisy AWGN far better than its complement
c = cfg; c.fec.code = 'polar'; c.fec.rate = 1/2; fec = fec_setup(c);
u = randi([0 1], fec.K, 200);
x = polar_encode(fec.code, u);
sig = 1 / sqrt(2 * 10^(2.5 / 10));
y = (1 - 2 * x) + sig * randn(size(x));
uh = polar_sc_decode(fec.code, 2 * y / sig^2);
fer = mean(any(uh ~= u, 1));
check(fer < 0.2, 'polar N=1024 R=1/2 SC at Es/N0=2.5 dB: FER %.3f (< 0.2, info set ordering correct)', fer);
end
