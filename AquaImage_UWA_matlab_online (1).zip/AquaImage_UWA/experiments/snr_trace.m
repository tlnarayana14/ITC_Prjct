function s = snr_trace(n, seed)
%SNR_TRACE Slowly varying link-quality trace used by Experiments 5 and 10.
%   s(k) = 8 + 5 sin(2 pi (k-1)/12) + e_k,  e_k ~ N(0, 1)  (dB, per image)
%   models SNR changes between images (e.g. range/geometry/noise changes over
%   minutes); within an image the channel follows the configured model.
%   Uses its own LCG so the trace is identical across runs and platforms.
st = mod(seed * 69069 + 1, 2^32);
e = zeros(1, n);
for k = 1:n
    % Box-Muller from two LCG uniforms
    st = mod(69069 * st + 1, 2^32); u1 = (st + 1) / (2^32 + 1);
    st = mod(69069 * st + 1, 2^32); u2 = st / 2^32;
    e(k) = sqrt(-2 * log(u1)) * cos(2 * pi * u2);
end
s = 8 + 5 * sin(2 * pi * (0:n - 1) / 12) + e;
end
