function R = exp05_adaptive_ldpc(traceSeeds)
%EXP05_ADAPTIVE_LDPC Experiment 5: fixed vs rule-based adaptive LDPC rate.
%
%   Link quality varies from image to image following SNR_TRACE (about
%   3..14 dB, multipath channel). Policies (all with SR-ARQ, max 3 retries):
%     fixed R=1/2, fixed R=3/4, adaptive (RATE_CONTROLLER: highest rate whose
%     Exp-3 threshold "first-attempt PER <= 10% at this ESTIMATED SNR" plus a
%     1 dB margin is below the previous image's SNR estimate).
%   Per trace: 16 distinct images, JPEG q30, camera interval 30 s. The same
%   images, SNR trace and random seed are used for every policy (paired
%   design). Repeated for 5 independent traces (traceSeeds) -> 80 images per
%   policy; Wilson 95% intervals for delivery, paired win/loss counts.
%   Requires results/tables/exp03_snr_sweep_multipath_arq.csv (Exp 3).
if nargin < 1, traceSeeds = 7:11; end
base = experiment_base();
base.arq.enabled = true; base.arq.maxRetries = 3;
base.source.numImages = 16;
base.source.interval_s = 30;
td = fullfile(base.out.resultsDir, 'tables');
T3 = read_csv_struct(fullfile(td, 'exp03_snr_sweep_multipath_arq.csv'));
rates = [1/2 2/3 3/4 5/6];
thr = per_thresholds(T3, rates, 0.10);
write_csv(fullfile(td, 'exp05_thresholds.csv'), {'rate', 'estSnrThresholdDb_PER10'}, num2cell([rates(:), thr(:)]));
ok = ~isnan(thr);
rates = rates(ok); thr = thr(ok);
pol = struct('name', {'fixed R=1/2', 'fixed R=3/4', 'adaptive'}, ...
    'ctrl', {@(s) struct('rate', 1/2), @(s) struct('rate', 3/4), @(s) rate_controller(s, rates, thr, 1.0)});
nP = numel(pol);
acc = repmat(struct('useful', 0, 'airtime', 0, 'turn', 0, 'deliv', [], 'delay', [], 'firstFail', 0, 'lost', 0, ...
    'pkts', 0, 'rate', [], 'psnr', []), 1, nP);
pr = {}; R.firstRuns = {};
for ts = traceSeeds
    trace = snr_trace(base.source.numImages, ts);
    for p = 1:nP
        set_seed(base.seed + 500 + ts);
        S = run_link_simulation(base, struct('tag', 'exp05', 'saveArtifacts', false, 'snrTrace', trace, 'controller', pol(p).ctrl));
        s = S.summary; P = S.perImage;
        acc(p).useful = acc(p).useful + s.usefulBits;
        acc(p).airtime = acc(p).airtime + s.airtime_s;
        acc(p).turn = acc(p).turn + s.turnaround_s;
        acc(p).deliv = [acc(p).deliv, [P.success]];
        acc(p).delay = [acc(p).delay, [P([P.success]).delay_s]];
        acc(p).firstFail = acc(p).firstFail + sum([P.firstFail]);
        acc(p).lost = acc(p).lost + sum([P.lost]);
        acc(p).pkts = acc(p).pkts + sum([P.nPkts]);
        acc(p).rate = [acc(p).rate, [P.rate]];
        acc(p).psnr = [acc(p).psnr, [P([P.success]).psnr_I_Ir]];
        for k = 1:numel(P)
            pr(end + 1, :) = {pol(p).name, ts, k - 1, trace(k), P(k).snrEstDb, P(k).rate, P(k).firstFail, ...
                P(k).nPkts, P(k).success, P(k).airtime_s + P(k).turnaround_s}; %#ok<AGROW>
        end
        if ts == traceSeeds(1), R.firstRuns{p} = S; R.firstTrace = trace; end
        fprintf('[exp05] trace %d %-12s delivered %d/%d mean rate %.3f\n', ts, pol(p).name, nnz([P.success]), numel(P), mean([P.rate]));
    end
end
rows = {};
for p = 1:nP
    a = acc(p);
    n = numel(a.deliv); k = nnz(a.deliv);
    [lo, hi] = wilson_ci(k, n);
    rows(end + 1, :) = {pol(p).name, k, n, k / n, lo, hi, a.firstFail / a.pkts, a.lost / a.pkts, ...
        a.useful / a.airtime, a.useful / (a.airtime + a.turn), mean(a.delay), mean(a.psnr), mean(a.rate)}; %#ok<AGROW>
end
% paired comparison adaptive vs each fixed policy (per image)
pw = {};
for p = 1:2
    d1 = acc(3).deliv; d0 = acc(p).deliv;
    pw(end + 1, :) = {['adaptive vs ' pol(p).name], nnz(d1 & ~d0), nnz(~d1 & d0), nnz(d1 == d0)}; %#ok<AGROW>
end
hdr = {'policy', 'delivered', 'images', 'deliveryRate', 'delivery_lo95', 'delivery_hi95', 'PER_initial', 'PER_final', ...
    'linkGoodput_bps', 'busyGoodput_bps', 'meanDelay_s', 'psnr_I_Ir', 'meanRate'};
write_csv(fullfile(td, 'exp05_adaptive.csv'), hdr, rows);
write_csv(fullfile(td, 'exp05_paired.csv'), {'comparison', 'onlyFirstDelivered', 'onlySecondDelivered', 'same'}, pw);
write_csv(fullfile(td, 'exp05_per_image.csv'), {'policy', 'traceSeed', 'image', 'snrTrueDb', 'snrEstDb', 'rate', 'firstFail', 'nPkts', 'success', 'serviceTime_s'}, pr);
for p = 1:nP
    fprintf('[exp05] %-12s delivered %d/%d (%.2f [%.2f,%.2f]) PERinit %.3f busy goodput %.0f b/s delay %.1f s rate %.3f\n', rows{p, 1}, rows{p, 2}, rows{p, 3}, rows{p, 4}, rows{p, 5}, rows{p, 6}, rows{p, 7}, rows{p, 10}, rows{p, 11}, rows{p, 13});
end
% figures (first trace for the time series, pooled numbers for the bars)
f = prepare_figure(820, 620);
subplot(2, 1, 1);
Pa = R.firstRuns{3}.perImage; tr = R.firstTrace;
plot(0:numel(tr) - 1, tr, 'k-o', 0:numel(tr) - 1, [Pa.snrEstDb], 'b-s', 'LineWidth', 1.3); grid on; hold on;
yyaxis_fallback(0:numel(Pa) - 1, [Pa.rate]);
ylabel('SNR (dB)'); legend({'true in-band SNR', 'receiver estimate', 'adaptive rate x 10'}, 'Location', 'best');
title(sprintf('Exp 5: SNR trace %d and adaptive LDPC rate (uses previous image''s estimate)', traceSeeds(1)));
subplot(2, 1, 2); hold on;
st = {'o-', 's-', 'd-'};
for p = 1:nP
    P = R.firstRuns{p}.perImage;
    plot(0:numel(P) - 1, [P.airtime_s] + [P.turnaround_s], st{p}, 'LineWidth', 1.3);
end
grid on; xlabel('image index'); ylabel('link occupation per image (s)');
legend({pol.name}, 'Location', 'best');
save_figure(f, fullfile(base.out.resultsDir, 'figures', 'exp05_adaptive_trace.png'));
f = prepare_figure(760, 420);
bar([cell2mat(rows(:, 4)), cell2mat(rows(:, 10)) / 5000]); set(gca, 'XTickLabel', rows(:, 1)); grid on;
legend({'image delivery rate', 'goodput incl. turnarounds / 5000 bit/s'}, 'Location', 'northeast');
title(sprintf('Exp 5: fixed vs adaptive LDPC, %d traces x 16 images', numel(traceSeeds)));
save_figure(f, fullfile(base.out.resultsDir, 'figures', 'exp05_goodput.png'));
R.rows = rows; R.paired = pw; R.thr = thr; R.rates = rates;
end

function yyaxis_fallback(x, r)
% draw the selected code rate (scaled x10) on the SNR axis (portable, no yyaxis)
plot(x, 10 * r, 'r-^', 'LineWidth', 1.1);
end
