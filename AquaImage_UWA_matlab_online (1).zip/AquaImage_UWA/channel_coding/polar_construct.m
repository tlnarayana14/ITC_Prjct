function pc = polar_construct(N, K, designSNRdB)
%POLAR_CONSTRUCT Polar code information set via the Bhattacharyya-parameter bound.
%
%   pc = POLAR_CONSTRUCT(N, K, designSNRdB)
%     N : block length (power of 2);  K : information bits
%     designSNRdB : design Es/N0 of the equivalent BI-AWGN (BPSK) channel
%   Uses z0 = exp(-Es/N0) and the recursion z- = 2z - z^2, z+ = z^2
%   (Arikan, IEEE Trans. IT 2009). The K most reliable synthetic channels
%   (smallest z) carry information; the rest are frozen to 0.
%   Natural (non bit-reversed) ordering, consistent with polar_encode.m and
%   polar_sc_decode.m:  x = u * F^{(x)n},  F = [1 0; 1 1].
n = log2(N);
if n ~= round(n), error('polar_construct:N', 'N must be a power of 2.'); end
lz = -10^(designSNRdB / 10);       % log(z0), log domain avoids underflow ties
for lev = 1:n
    zn = zeros(1, 2 * numel(lz));
    zn(1:2:end) = lz + log(2 - exp(lz));   % "minus" (worse): z- = 2z - z^2
    zn(2:2:end) = 2 * lz;                  % "plus"  (better): z+ = z^2
    lz = zn;
end
z = lz;                                    % stored as log-Bhattacharyya values
% Index i (0-based) = 2*parent + child, so the FIRST polarization level is
% the most significant bit -- the same order in which polar_sc_decode.m splits
% u into [first half (W-), second half (W+)]. No bit reversal is needed
% (verified empirically in tests/test_E_channel_coding.m).
[~, ord] = sort(z, 'ascend');
info = false(N, 1);
info(ord(1:K)) = true;
pc = struct('N', N, 'K', K, 'info', info, 'z', z(:), 'designSNRdB', designSNRdB);
end
