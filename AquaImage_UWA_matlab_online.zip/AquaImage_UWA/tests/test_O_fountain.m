function test_O_fountain()
%TEST_O_FOUNTAIN Packet-level fountain code: any K independent symbols decode;
%   erasures of systematic packets are repaired; end-to-end image delivery.
cfg = test_config();
r = load_image_record(fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_06.jpg'), 0);
enc = source_encode(r.pixels, cfg);
K = ceil(numel(enc.bytes) / cfg.pkt.payloadBytes);
pk = fountain_encode(enc.bytes, 3, enc.codecId, 0:K + 9, cfg);
rx = cellfun(@(b) parse_packet(b, cfg), pk);
check(all([rx.valid]), '%d fountain packets (K = %d) pass CRC and length checks', numel(rx), K);
[s, rk] = fountain_decode(rx(1:K), 3, cfg);
check(isequal(s, enc.bytes) && rk == K, 'systematic symbols alone decode the exact stream');
drop = [2 5 9 K];                                       % erase 4 source packets
keep = setdiff(1:numel(rx), drop);
[s2, rk2] = fountain_decode(rx(keep), 3, cfg);
check(isequal(s2, enc.bytes), '4 erased source packets recovered from repair symbols (rank %d of %d)', rk2, K);
[s3, rk3] = fountain_decode(rx(1:K - 2), 3, cfg);
check(isempty(s3) && rk3 == K - 2, 'fewer than K symbols -> no stream, rank deficit reported (%d)', K - rk3);
cfg.recovery.mode = 'fountain'; cfg.chan.model = 'multipath'; cfg.chan.snrDb = 5.5;
set_seed(21);
S = run_link_simulation(cfg, struct('tag', 'test_O', 'saveArtifacts', false));
e = S.perImage(1);
check(e.success && e.IcEqualsIr, 'image delivered with fountain recovery at 5.5 dB (first-burst PER %.3f, %d symbols for K = %d)', e.PER_initial, e.nTransmissions, e.nPkts);
end
