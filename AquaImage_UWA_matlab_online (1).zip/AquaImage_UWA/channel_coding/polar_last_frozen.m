function fz = polar_last_frozen(pc, pad)
%POLAR_LAST_FROZEN Frozen mask for a shortened last polar block.
%   The 'pad' least reliable information positions (largest Bhattacharyya
%   parameter) are additionally frozen to the known value 0.
fz = ~pc.info;
if pad <= 0, return; end
idx = find(pc.info);
[~, o] = sort(pc.z(idx), 'descend');
fz(idx(o(1:pad))) = true;
end
