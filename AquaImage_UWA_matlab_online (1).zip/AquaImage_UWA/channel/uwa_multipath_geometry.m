function pth = uwa_multipath_geometry(cfg)
%UWA_MULTIPATH_GEOMETRY Deterministic shallow-water multipath by the image method.
%
%   pth = UWA_MULTIPATH_GEOMETRY(cfg) for an isovelocity waveguide of depth h
%   (flat surface and bottom), source depth zs, receiver depth zr, range R.
%   For m = 0,1,2,... the image-source vertical offsets are
%       Z1 = 2mh + zs - zr   (m surface,   m bottom reflections)
%       Z2 = 2mh + zs + zr   (m+1 surface, m bottom)
%       Z3 = 2(m+1)h - zs - zr (m surface, m+1 bottom)
%       Z4 = 2(m+1)h - zs + zr (m+1 surface, m+1 bottom)
%   path length l = sqrt(R^2 + Z^2), delay l/c, and amplitude
%       g = Gs^ns * Gb^nb / sqrt( l^k * a(fc)^(l/1000) )
%   (practical spreading exponent k, Thorp absorption a(f) in linear units
%   per km). Carrier phase exp(-j 2 pi fc tau) is included. Paths weaker
%   than cfg.chan.minRelPowerDb relative to the strongest are dropped and
%   the rest are normalised to unit total power (the SNR is defined at the
%   receiver, so absolute loss is reported separately in pth.TLdB).
%
%   Output: pth.delay_s (relative to first arrival, ascending), pth.gain
%   (complex, sum|g|^2 = 1), pth.ns, pth.nb, pth.len_m, pth.TLdB (direct
%   path transmission loss), pth.delaySpread_s.
c = cfg.chan.c; h = cfg.chan.depth_m; zs = cfg.chan.txDepth_m; zr = cfg.chan.rxDepth_m;
R = cfg.chan.range_m; fc = cfg.phy.fc; k = cfg.chan.spreadingK;
Gs = cfg.chan.surfRefl; Gb = cfg.chan.botRefl;
aLin = 10^(thorp_absorption(fc / 1000) / 10);    % per km
Z = []; ns = []; nb = [];
for m = 0:cfg.chan.maxBounces
    Z  = [Z, abs(2*m*h + zs - zr), 2*m*h + zs + zr, 2*(m+1)*h - zs - zr, 2*(m+1)*h - zs + zr]; %#ok<AGROW>
    ns = [ns, m, m + 1, m, m + 1]; %#ok<AGROW>
    nb = [nb, m, m, m + 1, m + 1]; %#ok<AGROW>
end
l = sqrt(R^2 + Z.^2);
tau = l / c;
A = l.^k .* aLin.^(l / 1000);
g = (Gs.^ns) .* (Gb.^nb) ./ sqrt(A) .* exp(-1j * 2 * pi * fc * tau);
pw = abs(g).^2;
keep = 10 * log10(pw / max(pw)) >= cfg.chan.minRelPowerDb;
[tau, o] = sort(tau(keep));
g = g(keep); g = g(o); ns = ns(keep); ns = ns(o); nb = nb(keep); nb = nb(o); l = l(keep); l = l(o);
pth.TLdB = 10 * log10(A(1));           % direct path (m=0, Z1) loss in dB re 1 m
g = g / sqrt(sum(abs(g).^2));
pth.delay_s = tau - tau(1);
pth.absDelay_s = tau(1);
pth.gain = g;
pth.ns = ns; pth.nb = nb; pth.len_m = l;
pth.delaySpread_s = max(pth.delay_s);
end
