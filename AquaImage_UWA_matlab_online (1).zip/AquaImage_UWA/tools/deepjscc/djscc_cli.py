#!/usr/bin/env python3
"""Command-line bridge between the Octave/MATLAB link and the Deep JSCC model.

  djscc_cli.py encode model.pt image.png symbols.f32 snr_db
      -> interleaved complex64 symbols (unit power) as float32 [re, im, re, im, ...]
  djscc_cli.py decode model.pt eq.f32 out.png snr_db height width
      -> reconstructed image from LMMSE-equalised symbols returned by the
         receiver (phy_ofdm_rx with cfg.mod.scheme = 'analog')
Images must have height and width divisible by 16.
"""
import sys, os
import numpy as np
import torch
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from djscc import load_model, latent_to_symbols, symbols_to_latent, interleaver, C_LATENT

torch.set_num_threads(1)
cmd, model = sys.argv[1], sys.argv[2]
enc, dec, _ = load_model(model)
with torch.no_grad():
    if cmd == 'encode':
        img = np.asarray(Image.open(sys.argv[3]).convert('RGB')).astype(np.float32) / 255
        snr = torch.tensor([float(sys.argv[5])])
        x = torch.tensor(img.transpose(2, 0, 1)[None].copy())
        s = latent_to_symbols(enc(x, snr))[0]
        s = s[torch.tensor(interleaver(s.numel()))]
        np.stack([s.real.numpy(), s.imag.numpy()], 1).astype(np.float32).tofile(sys.argv[4])
    elif cmd == 'decode':
        v = np.fromfile(sys.argv[3], dtype=np.float32).reshape(-1, 2)
        r = torch.tensor(v[:, 0]) + 1j * torch.tensor(v[:, 1])
        snr = torch.tensor([float(sys.argv[5])])
        H, W = int(sys.argv[6]), int(sys.argv[7])
        perm = torch.tensor(interleaver(r.numel()))
        rr = torch.empty_like(r); rr[perm] = r
        xh = dec(symbols_to_latent(rr[None], (C_LATENT, H // 16, W // 16)), snr)[0]
        Image.fromarray((xh.numpy().transpose(1, 2, 0) * 255).round().clip(0, 255).astype(np.uint8)).save(sys.argv[4])
    else:
        raise SystemExit('unknown command')
