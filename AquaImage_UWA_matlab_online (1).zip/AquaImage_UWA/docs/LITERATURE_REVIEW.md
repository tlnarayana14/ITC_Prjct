# Focused literature review and research-contribution definition

Scope: the design choices of AquaImage_UWA and the positioning of its
research extension (Experiment 10). This is a **focused** review done within
one working session with web search; it is not a systematic survey, and the
novelty statement in §4 is limited accordingly.

Verification legend — **[V]**: bibliographic details checked online during this
project; **[S]**: standard reference cited from the author's knowledge, not
re-checked online in this session (please verify before publication).

## 1. Underwater acoustic (UWA) channel and physical layer

* **Channel physics.** Stojanovic & Preisig give the reference description of
  UWA channels: frequency-dependent absorption, multipath from surface/bottom
  reflections and refraction, and motion-induced Doppler that is large relative
  to the carrier because sound is slow **[S]** (M. Stojanovic, J. Preisig,
  "Underwater acoustic communication channels: propagation models and
  statistical characterization," *IEEE Commun. Mag.*, 47(1), 2009). The
  attenuation model A(l,f) = l^k a(f)^l with Thorp's absorption and the
  ambient-noise model come from M. Stojanovic, "On the relationship between
  capacity and distance in an underwater acoustic communication channel,"
  *ACM SIGMOBILE MC2R*, 11(4), 2007 **[S]**.
  *Used in:* `channel/thorp_absorption.m`, `channel/uwa_multipath_geometry.m`
  (image-method paths with spreading + absorption + reflection losses).
* **OFDM with Doppler compensation.** Li, Zhou, Stojanovic, Freitag & Willett
  show that UWA OFDM needs a two-step Doppler treatment: resampling to remove
  the (nonuniform, wideband) Doppler scaling, then fine compensation of the
  residual frequency offset using null subcarriers, with pilots for channel
  estimation **[V]** (*IEEE J. Oceanic Eng.*, 33, 198–209, 2008,
  doi:10.1109/JOE.2008.920471). *Used in:* `phy/phy_ofdm_rx.m` (chirp
  preamble/postamble scale estimate → spline resampling → CFO removal →
  null-subcarrier residual-CFO search → pilot-based LS channel estimation).
  Our parameters (K = 1024 subcarriers in 8 kHz at 24 kHz, 25 ms guard) are of
  the same order as that line of work but are our own choice.
* **Adaptive UWA OFDM.** Radosevic, Ahmed, Duman, Proakis & Stojanovic
  feed back either per-subcarrier modulation/power or a sparse channel estimate
  and predict the channel one travel time ahead **[V]** (*IEEE J. Oceanic
  Eng.*, 39(2), 357–370, 2014, doi:10.1109/JOE.2013.2253212). This motivates
  treating feedback delay explicitly; our controllers act on the *previous
  image's* SNR estimate.
* **Coding for UWA OFDM.** LDPC (binary and non-binary) is the common choice for
  UWA OFDM; a recent example compares protograph LDPC, polar and turbo product
  codes for **image** transmission over OFDM UWA channels **[V]**
  (Al-Kadhimi, Abdelkareem & Tsimenidis, *Acta Polytechnica* 64(2), 68–76,
  2024, doi:10.14311/AP.2024.64.0068).

## 2. Channel coding and integrity

* **LDPC.** We use a quasi-cyclic code family with the IEEE 802.11n/ac encoder
  structure (block dual-diagonal parity, weight-3 h_b column) so that encoding
  is linear-time **[S]** (IEEE Std 802.11n-2009). A first attempt with a
  bit-level accumulator parity part produced a measurable error floor (weight-5
  codewords created by adjacent circulant columns); switching to the block
  dual-diagonal structure removed it (`channel_coding/ldpc_build.m`).
* **Polar codes.** Arıkan's channel polarisation with successive-cancellation
  decoding **[S]** (*IEEE Trans. Inf. Theory*, 55(7), 2009). We construct the
  information set with the Bhattacharyya-bound recursion in the log domain.
* **CRC.** CRC-32 (IEEE 802.3 / zlib parameters) detects all 1-bit errors and
  all bursts up to 32 bits; for random patterns the miss probability is about
  2^-32. A CRC never corrects errors. Our tests confirm detection of every
  injected 1-bit and burst pattern and agreement with Python `zlib.crc32`.

## 3. Image coding and image transmission over UWA links

* **Codecs.** JPEG XL is standardised as ISO/IEC 18181; an overview of its
  history, coding tools and design rationale is given by Sneyers, Alakuijala
  et al. **[V]** (arXiv:2506.05987, 2025) and the architecture paper by
  Alakuijala et al. **[V]** (*Proc. SPIE* 11137, 111370K, 2019,
  doi:10.1117/12.2529237). Its reference encoder is tuned for perceptual
  quality — consistent with our Exp 1 result that libjxl wins on SSIM but not
  on PSNR for these images. Learned codecs (Ballé et al., ICLR 2018 **[S]**;
  CompressAI library, Bégaint et al., arXiv:2011.03029 **[S]**) were not
  executed here.
* **Rate-distortion comparison method.** Bjøntegaard delta rate **[S]**
  (G. Bjøntegaard, VCEG-M33, 2001). **SSIM** **[S]** (Wang, Bovik, Sheikh,
  Simoncelli, *IEEE Trans. Image Process.*, 13(4), 2004).
* **Datasets.** EUVP **[V]** (Islam, Xia, Sattar, "Fast underwater image
  enhancement for improved visual perception," arXiv:1903.09766 / *IEEE RA-L*
  2020). UIEB (Li et al., *IEEE TIP* 2020) and RUIE (Liu et al., *IEEE TCSVT*
  2020) **[S]** were not accessible from the sandbox.
* **Early high-rate image/video links.** Pelekanakis combined DCT image
  compression with variable-rate QAM and DFE equalisation for underwater video
  **[V]** (S.M. thesis, MIT, 2004, hdl:1721.1/33676).
* **Unequal error protection.** Esmaiel et al. split SPIHT bits into critical and
  non-critical classes and protect them unequally with spatial modulation over
  measured and simulated UWA channels **[V]** (*Sensors* 19(23):5271, 2019,
  doi:10.3390/s19235271).
* **Learned joint source–channel coding.** Deep JSCC avoids the "cliff effect"
  of separated digital systems (Bourtsoulatze, Kurka, Gündüz, *IEEE TCCN*
  5(3), 567–579, 2019, doi:10.1109/TCCN.2019.2919300) **[V]**. For UWA, Anjum,
  Qi & Pompili propose a CNN/LSTM deep JSCC producing variable-length codewords
  conditioned on channel-state feedback, compared with JPEG/JPEG2000 + LDPC/Turbo
  baselines on simulated Rician channels and a pool testbed **[V]** (WUWNet'22,
  2022, doi:10.1145/3567600.3568138).

## 3b. References added in the second iteration

* **Polar list decoding:** I. Tal, A. Vardy, "List decoding of polar codes,"
  *IEEE Trans. Inf. Theory*, 61(5), 2015 **[S]**; LLR-domain path metric:
  Balatsoukas-Stimming, Parizi, Burg, *IEEE Trans. Signal Process.*, 2015 **[S]**.
  Used in `polar_scl_decode.m` (CA-SCL, L = 8, CRC-16).
* **Saliency / ROI:** X. Hou, L. Zhang, "Saliency detection: a spectral
  residual approach," CVPR 2007 **[S]**. Used in `roi_detect.m`.
* **Reed–Solomon decoding:** Berlekamp–Massey, Chien search and Forney's
  algorithm (textbook material, e.g. Lin & Costello, *Error Control Coding*) **[S]**.
* **Fountain / random linear codes:** random linear codes over GF(2) as
  rateless erasure codes (cf. LT/Raptor codes, Luby 2002; Shokrollahi 2006) **[S]**.
* **Deep JSCC:** Bourtsoulatze, Kurka, Gündüz (IEEE TCCN 2019) **[V]** — basis of
  `tools/deepjscc`; SNR conditioning in the spirit of attention-based DJSCC
  (Xu et al., IEEE TCSVT 2022 **[S]**); UWA Deep JSCC: Anjum, Qi, Pompili
  (WUWNet 2022) **[V]**.

## 4. Research gap and selected contribution

**What the reviewed work covers.** (a) PHY-level adaptation (modulation/power)
to measured channel state with feedback delay; (b) UEP of progressive
(wavelet) bitstreams; (c) learned JSCC that adapts codeword length to channel
state; (d) LDPC/polar/turbo comparisons for image transmission over UWA OFDM.

**What we did not find in this focused review.** An evaluation that, with
*standard, decodable codecs* (JPEG/JPEG XL files that any receiver can open),
*jointly* selects the source rate and the channel-code rate per image using
(i) the receiver's SNR estimate delayed by one image, (ii) **measured
service latency including selective-repeat ARQ round trips** over a
half-duplex acoustic link with 0.67 s one-way propagation, and (iii) a
per-image **deadline**, reporting on-time delivery rather than only PSNR at a
given BER. Cross-layer source/channel operating-point selection is well
established for terrestrial video, so this is positioned as an *evaluation of
a known idea under UWA-specific latency constraints*, **not** as a novel
algorithm. A systematic review would be needed before claiming novelty.

* **Research question.** Under a per-image latency deadline on a time-varying
  UWA link, does jointly choosing (JPEG quality, LDPC rate) from measured
  operating-point tables increase the expected delivered image quality compared
  with fixed settings and with channel-rate-only adaptation?
* **Hypothesis.** Yes: when the SNR is high, a higher code rate frees airtime
  that can be spent on higher image quality; when it is low, a lower image
  quality keeps the image within the deadline where rate-only adaptation
  cannot.
* **Baselines.** Fixed (q40, R1/2), (q60, R1/2), (q40, R3/4); rate-only adaptive
  (Exp 5 controller) at q40.
* **Independent variables.** Policy; SNR trace (fixed); deadline (12 s).
* **Dependent variables.** On-time delivery rate; utility = mean over images of
  1[on time]·SSIM(I, I_r); SSIM/PSNR of on-time images; latency.
* **Protocol.** Operating-point table measured in Exp 7 on 4 images at 3 SNRs;
  evaluated in Exp 10 on 16 images (12 unseen) under a 16-step SNR trace, same
  seed for all policies.
* **Expected trade-offs.** More aggressive points raise quality but risk
  deadline misses; the table is coarse (3 SNR buckets) and SNR estimates are
  one image old.
* **Limitations.** Small image set; simulated (not measured) channel; table
  built from the same channel model it is evaluated on; utility assigns 0 to a
  late image by definition.
