function R = exp12_deep_jscc(chansToRun)
%EXP12_DEEP_JSCC Experiment 12: learned Deep JSCC vs. separated digital coding
%   at the SAME number of channel symbols, through the SAME OFDM receiver and
%   underwater channel models.
%
%   Deep JSCC (tools/deepjscc): 256x256 image -> 16384 complex symbols
%   (bandwidth ratio 1/12), sent with cfg.mod.scheme = 'analog' through
%   phy_ofdm_tx -> uwa_channel -> phy_ofdm_rx (real sync, Doppler, CFO and
%   pilot-based channel estimation; LMMSE-equalised symbols returned). The
%   encoder is told the true SNR (assumed fed back); the decoder uses the
%   receiver's own SNR estimate.
%   Digital baselines: JPEG and JPEG XL at the highest quality whose packets
%   (header + CRC) fit the same 16384 QPSK symbols with LDPC R = 1/2 or 3/4,
%   no ARQ (same channel-use budget). "digital oracle" = best of the four
%   digital options per image and SNR (a genie upper bound for adaptive
%   digital selection).
%   Test images euvp_18..23 were NOT used for training. A digital image that
%   is not delivered is displayed as flat gray (no data invented), so mean
%   PSNR reflects what a user would see.
base = experiment_base();
model = fullfile(base.root, 'tools', 'deepjscc', 'djscc_uwa.pt');
cli = fullfile(base.root, 'tools', 'deepjscc', 'djscc_cli.py');
if exist(model, 'file') ~= 2
    error('exp12:model', 'Deep JSCC model not found: run python3 tools/deepjscc/train.py <root> first.');
end
tmp = base.codec.tmpDir;
nSym = 16384;
snrs = 0:2:12;
chans = {'multipath', 'timevarying'};
if nargin < 1, chansToRun = chans; end
cdir = fullfile(base.out.resultsDir, 'cache'); if exist(cdir, 'dir') ~= 7, mkdir(cdir); end
imgs = 18:23;
rows = {}; examples = struct();
for ch = chans
    for s = snrs
        for k = imgs
            cf = fullfile(cdir, sprintf('exp12_%s_s%d_k%d.mat', ch{1}, s, k));
            if exist(cf, 'file') == 2
                L = load(cf); rows = [rows; L.prow]; %#ok<AGROW>
                if isfield(L, 'ex'), fn = fieldnames(L.ex); for q = 1:numel(fn), examples.(fn{q}) = L.ex.(fn{q}); end, end
                continue;
            end
            if ~any(strcmp(chansToRun, ch{1})), continue; end
            n0 = size(rows, 1); ex = struct();
            r = load_image_record(fullfile(base.root, 'data', 'underwater_samples', sprintf('euvp_%02d.jpg', k)), k);
            I = r.pixels;
            c = base; c.chan.model = ch{1}; c.chan.snrDb = s;
            seed = base.seed + 12000 + 100 * s + k + 50 * strcmp(ch{1}, 'timevarying');
            % ---------------- Deep JSCC
            set_seed(seed);
            fi = [tempname(tmp) '.png']; fs = [tempname(tmp) '.f32']; fe = [tempname(tmp) '.f32']; fo = [tempname(tmp) '.png'];
            imwrite(I, fi);
            run_py(sprintf('python3 "%s" encode "%s" "%s" "%s" %g', cli, model, fi, fs, s));
            v = read_f32(fs); sym = v(1:2:end) + 1j * v(2:2:end);
            ca = c; ca.mod.scheme = 'analog';
            tx = phy_tx(sym, ca);
            rx = uwa_channel(tx, ca);
            [eq, d] = phy_rx(rx, tx.meta, ca);
            snrRx = d.snrEstDb - 10 * log10(ofdm_params(ca).K / ofdm_params(ca).nUsed);
            write_f32(fe, [real(eq(:)).'; imag(eq(:)).']);
            run_py(sprintf('python3 "%s" decode "%s" "%s" "%s" %g %d %d', cli, model, fe, fo, snrRx, size(I, 1), size(I, 2)));
            Id = imread(fo);
            rows(end + 1, :) = {ch{1}, s, k, 'Deep JSCC (1/12)', 1, psnr_u8(I, Id), ssim_luma(I, Id), tx.duration_s, nSym, NaN}; %#ok<AGROW>
            if s == 6, ex.(sprintf('%s_djscc_%d', ch{1}, k)) = Id; end
            % ---------------- digital baselines at the same symbol budget
            for codec = {'jpeg', 'jpegxl'}
                for Rc = [1/2 3/4]
                    cd = c; cd.codec.name = codec{1}; cd.fec.rate = Rc; cd.arq.enabled = false;
                    [enc, qv] = fit_budget(I, cd, nSym, Rc);
                    set_seed(seed);
                    if isempty(enc)
                        ok = false; Ir = uint8(128 * ones(size(I))); dur = NaN;
                    else
                        res = transmit_image(enc, k, cd, fec_setup(cd), 0);
                        ok = res.success; dur = sum(res.segments(:, 2));
                        if ok, Ir = res.Ir; else, Ir = uint8(128 * ones(size(I))); end
                    end
                    nm = sprintf('%s + LDPC %s', upper(strrep(codec{1}, 'jpegxl', 'jxl')), rate_str(Rc));
                    rows(end + 1, :) = {ch{1}, s, k, nm, ok, psnr_u8(I, Ir), ssim_luma(I, Ir), dur, nSym, qv}; %#ok<AGROW>
                    if s == 6 && strcmp(codec{1}, 'jpeg') && Rc == 1/2, ex.(sprintf('%s_jpeg_%d', ch{1}, k)) = Ir; end
                end
            end
            cellfun(@(f) delete_if(f), {fi, fs, fe, fo});
            prow = rows(n0 + 1:end, :);
            save(cf, 'prow', 'ex', '-v7');
            fn = fieldnames(ex); for q = 1:numel(fn), examples.(fn{q}) = ex.(fn{q}); end
        end
        fprintf('[exp12] %s SNR %d dB done\n', ch{1}, s);
    end
end
if numel(chansToRun) < numel(chans), R = struct(); return; end
% digital oracle (best digital option per channel/SNR/image)
D = rows(~strcmp(rows(:, 4), 'Deep JSCC (1/12)'), :);
keys = unique(strcat(D(:, 1), '|', cellfun(@num2str, D(:, 2), 'UniformOutput', false), '|', cellfun(@num2str, D(:, 3), 'UniformOutput', false)));
for i = 1:numel(keys)
    p = strsplit(keys{i}, '|');
    m = strcmp(D(:, 1), p{1}) & cell2mat(D(:, 2)) == str2double(p{2}) & cell2mat(D(:, 3)) == str2double(p{3});
    x = D(m, :); [~, b] = max(cell2mat(x(:, 6)));
    rows(end + 1, :) = {p{1}, str2double(p{2}), str2double(p{3}), 'digital oracle (best of 4)', x{b, 5}, x{b, 6}, x{b, 7}, x{b, 8}, nSym, NaN}; %#ok<AGROW>
end
td = fullfile(base.out.resultsDir, 'tables');
write_csv(fullfile(td, 'exp12_deep_jscc_points.csv'), {'channel', 'snrDb', 'image', 'scheme', 'delivered', 'psnr', 'ssim', 'airtime_s', 'channelSymbols', 'qualityParam'}, rows);
names = unique(rows(:, 4), 'stable');
S = {};
for ch = chans
    for m = 1:numel(names)
        for s = snrs
            x = rows(strcmp(rows(:, 1), ch{1}) & strcmp(rows(:, 4), names{m}) & cell2mat(rows(:, 2)) == s, :);
            S(end + 1, :) = {ch{1}, names{m}, s, mean(cell2mat(x(:, 5))), mean(cell2mat(x(:, 6))), mean(cell2mat(x(:, 7))), mean(cell2mat(x(:, 8)))}; %#ok<AGROW>
        end
    end
end
write_csv(fullfile(td, 'exp12_deep_jscc_summary.csv'), {'channel', 'scheme', 'snrDb', 'deliveryRate', 'psnr', 'ssim', 'airtime_s'}, S);
fd = fullfile(base.out.resultsDir, 'figures');
for metric = {'psnr', 'ssim'}
    f = prepare_figure(1150, 430);
    for ci = 1:numel(chans)
        subplot(1, 2, ci); hold on;
        for m = 1:numel(names)
            x = S(strcmp(S(:, 1), chans{ci}) & strcmp(S(:, 2), names{m}), :);
            col = ternary(strcmp(metric{1}, 'psnr'), 5, 6);
            st = ternary(m == 1, 'k-o', '--s'); if strcmp(names{m}, 'digital oracle (best of 4)'), st = 'r-^'; end
            plot(cell2mat(x(:, 3)), cell2mat(x(:, col)), st, 'LineWidth', 1.5);
        end
        grid on; xlabel('in-band SNR (dB)'); ylabel(sprintf('mean %s (displayed image)', upper(metric{1})));
        title(sprintf('Exp 12: %s, 16384 channel symbols per image', chans{ci}));
        legend(names, 'Location', 'southeast');
    end
    save_figure(f, fullfile(fd, sprintf('exp12_deep_jscc_%s.png', metric{1})));
end
fn = fieldnames(examples);
if ~isempty(fn)
    f = prepare_figure(1000, 520); n = min(4, numel(fn));
    for i = 1:n
        subplot(1, n, i); image(examples.(fn{i})); axis image off; title(strrep(fn{i}, '_', ' '));
    end
    save_figure(f, fullfile(fd, 'exp12_examples_6dB.png'));
end
R.rows = rows; R.summary = S;
end

function [enc, qv] = fit_budget(I, c, nSym, Rc)
% highest quality whose packets fit nSym QPSK symbols at code rate Rc
infoBits = floor(2 * nSym * Rc);
P = c.pkt.payloadBytes; ov = c.pkt.headerBytes + 4;
enc = []; qv = NaN;
if strcmp(c.codec.name, 'jpeg'), grid = 95:-5:5; grid = [grid 4 3 2 1]; else, grid = [0.5 1 1.5 2 3 4 5 6 8 10 12 15 20 25]; end
for g = grid
    if strcmp(c.codec.name, 'jpeg'), c.codec.jpegQuality = g; else, c.codec.jxlDistance = g; end
    e = source_encode(I, c);
    B = numel(e.bytes);
    if 8 * (B + ov * ceil(B / P)) <= infoBits
        enc = e; qv = g; return;
    end
end
end

function run_py(cmd)
[st, out] = system(cmd);
if st ~= 0, error('exp12:python', 'Deep JSCC helper failed: %s', out); end
end
function v = read_f32(f)
fid = fopen(f, 'rb'); v = fread(fid, Inf, 'float32'); fclose(fid);
end
function write_f32(f, M)
fid = fopen(f, 'wb'); fwrite(fid, M(:), 'float32'); fclose(fid);
end
function delete_if(f)
if exist(f, 'file') == 2, delete(f); end
end
