function [dec, state] = amc_controller(state, modes, thrDb, opt)
%AMC_CONTROLLER Adaptive modulation and coding with variability-aware margin.
%
%   [dec, state] = AMC_CONTROLLER(state, modes, thrDb, opt)
%     state.lastSnrEstDb  receiver estimate for the previous image (fed back)
%     state.hist          (kept by the caller via the persistent store below)
%     modes(i)            struct(scheme, rate, eff) sorted by increasing eff
%                         = bits per symbol x code rate
%     thrDb(i)            estimated SNR at which mode i reached first-attempt
%                         PER <= 10 % (Experiments 3 / 5b)
%     opt.allowModulation false -> QPSK modes only (rate-only adaptation)
%   Rule (fix for the Exp-5 failure mode, where one-image-old CSI picked too
%   high a rate on a falling SNR trace):
%     prediction  s_hat = s_k + min(0, s_k - s_{k-1})   (pessimistic trend)
%     margin      m = opt.m0 + opt.kSigma * sigma, sigma = RMS of past
%                 image-to-image estimate changes (initial value opt.sigma0)
%     choose the most efficient mode with thr + m <= s_hat, else the most robust.
persistent hist
if isfield(state, 'k') && state.k == 1, hist = []; end
dec.rate = modes(1).rate; dec.modScheme = modes(1).scheme;
s = state.lastSnrEstDb;
if isnan(s), return; end
hist(end + 1) = s;
if numel(hist) >= 2
    trend = min(0, hist(end) - hist(end - 1));
    sigma = sqrt(mean(diff(hist).^2));
else
    trend = 0; sigma = opt.sigma0;
end
if numel(hist) < 3, sigma = max(sigma, opt.sigma0); end
sHat = s + trend;
m = opt.m0 + opt.kSigma * sigma;
ok = find(thrDb + m <= sHat);
if ~opt.allowModulation
    ok = ok(arrayfun(@(i) strcmpi(modes(i).scheme, 'qpsk'), ok));
end
if ~isempty(ok)
    [~, j] = max([modes(ok).eff]);
    dec.rate = modes(ok(j)).rate; dec.modScheme = modes(ok(j)).scheme;
end
end
