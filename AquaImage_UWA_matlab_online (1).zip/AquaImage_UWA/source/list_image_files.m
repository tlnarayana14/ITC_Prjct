function files = list_image_files(folder, extensions)
%LIST_IMAGE_FILES Sorted list of supported still-image files in a folder.
%   files = LIST_IMAGE_FILES(folder, extensions) returns a cell array of full
%   paths whose (case-insensitive) extension is in EXTENSIONS, e.g.
%   {'.jpg','.png','.bmp','.tif'}. Errors if the folder has no usable image.
if exist(folder, 'dir') ~= 7
    error('list_image_files:nofolder', 'Image folder not found: %s', folder);
end
d = dir(folder);
files = {};
for k = 1:numel(d)
    if d(k).isdir, continue; end
    [~, ~, e] = fileparts(d(k).name);
    if any(strcmpi(e, extensions))
        files{end+1, 1} = fullfile(folder, d(k).name); %#ok<AGROW>
    end
end
files = sort(files);
if isempty(files)
    error('list_image_files:empty', 'No images with extensions {%s} in %s', strjoin(extensions, ' '), folder);
end
end
