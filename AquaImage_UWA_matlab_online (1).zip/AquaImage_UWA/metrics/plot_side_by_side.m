function plot_side_by_side(S, fname, maxRows)
%PLOT_SIDE_BY_SIDE Original I | locally decoded I_c | receiver output I_r per image.
%   Images that were not delivered show an explicit "NOT DELIVERED" panel
%   (no content is substituted).
if nargin < 3, maxRows = 3; end
P = S.perImage;
n = min(numel(P), maxRows);
d = fullfile(S.cfg.out.resultsDir, 'reconstructed_images', 'main');
f = prepare_figure(900, 300 * n);
for k = 1:n
    b = fullfile(d, sprintf('img%03d', P(k).id));
    I = imread([b '_original.png']);
    Ic = imread([b '_Ic_local_decode.png']);
    subplot(n, 3, 3 * k - 2); image(to_rgb(I)); axis image off;
    title(sprintf('I (img %d)', P(k).id));
    subplot(n, 3, 3 * k - 1); image(to_rgb(Ic)); axis image off;
    title(sprintf('I_c %s %.2f bpp, %.1f dB', P(k).codec, P(k).bpp, P(k).psnr_I_Ic));
    subplot(n, 3, 3 * k);
    if exist([b '_Ir_received.png'], 'file') == 2
        image(to_rgb(imread([b '_Ir_received.png']))); axis image off;
        title(sprintf('I_r received, %.1f dB, I_r=I_c: %d', P(k).psnr_I_Ir, P(k).IcEqualsIr));
    else
        axis off; text(0.5, 0.5, 'NOT DELIVERED', 'HorizontalAlignment', 'center');
        title(sprintf('I_r: %d/%d packets lost', P(k).lost, P(k).nPkts));
    end
end
save_figure(f, fname);
end

function J = to_rgb(I)
if size(I, 3) == 1, J = repmat(I, [1 1 3]); else, J = I; end
end
