function [bb, S] = roi_detect(img, cfg)
%ROI_DETECT Region of interest by spectral-residual saliency (Hou & Zhang, CVPR 2007).
%
%   [bb, S] = ROI_DETECT(img, cfg)
%     bb : [row0 col0 height width] (1-based), aligned to 16-pixel blocks,
%          covering the most salient region (marine animal, coral, diver ...)
%     S  : saliency map (image size, 0..1)
%   Steps: luma -> 64x64 -> log-amplitude spectrum minus its 3x3 local mean
%   (spectral residual) -> inverse FFT with the original phase -> squared
%   magnitude -> Gaussian blur -> resize. Pixels above
%   mean + cfg.roi.k*std define the region; its bounding box is expanded by
%   8 px, aligned to 16 px and limited to cfg.roi.maxArea of the image.
if nargin < 2 || ~isfield(cfg, 'roi'), cfg.roi = struct('k', 1.5, 'maxArea', 0.4); end
I = double(img);
if size(I, 3) == 3, Y = 0.299 * I(:, :, 1) + 0.587 * I(:, :, 2) + 0.114 * I(:, :, 3); else, Y = I; end
[H, W] = size(Y);
[xq, yq] = meshgrid(linspace(1, W, 64), linspace(1, H, 64));
y = interp2(Y, xq, yq, 'linear');
F = fft2(y);
A = log(abs(F) + 1e-9); P = angle(F);
Ap = [A(:, end) A A(:, 1)]; Ap = [Ap(end, :); Ap; Ap(1, :)];       % circular padding
R = A - conv2(Ap, ones(3) / 9, 'valid');
s = abs(ifft2(exp(R + 1j * P))).^2;
g = exp(-((-6:6).^2) / (2 * 2.5^2)); g = g / sum(g);
s = conv2(g, g, s, 'same');
[xs, ys] = meshgrid(linspace(1, 64, W), linspace(1, 64, H));
S = interp2(s, xs, ys, 'linear');
S = (S - min(S(:))) / max(max(S(:)) - min(S(:)), eps);
m = S > mean(S(:)) + cfg.roi.k * std(S(:));
if ~any(m(:)), m = S >= max(S(:)) * 0.9; end
[r, c] = find(m);
r0 = max(1, min(r) - 8); r1 = min(H, max(r) + 8);
c0 = max(1, min(c) - 8); c1 = min(W, max(c) + 8);
% shrink around the saliency centroid if the box is too large
maxA = cfg.roi.maxArea * H * W;
if (r1 - r0 + 1) * (c1 - c0 + 1) > maxA
    w = S .* m; cr = sum(sum(w .* (1:H).')) / sum(w(:)); cc = sum(sum(w .* (1:W))) / sum(w(:));
    sc = sqrt(maxA / ((r1 - r0 + 1) * (c1 - c0 + 1)));
    hh = (r1 - r0 + 1) * sc; ww = (c1 - c0 + 1) * sc;
    r0 = round(cr - hh / 2); c0 = round(cc - ww / 2); r1 = round(r0 + hh - 1); c1 = round(c0 + ww - 1);
end
% align to the 16-pixel grid, at least 64 x 64, inside the image
r0 = max(1, 16 * floor((r0 - 1) / 16) + 1); c0 = max(1, 16 * floor((c0 - 1) / 16) + 1);
h = max(64, 16 * ceil((r1 - r0 + 1) / 16)); w = max(64, 16 * ceil((c1 - c0 + 1) / 16));
h = min(h, 16 * floor(H / 16)); w = min(w, 16 * floor(W / 16));
r0 = min(r0, H - h + 1); c0 = min(c0, W - w + 1);
bb = [r0 c0 h w];
end
