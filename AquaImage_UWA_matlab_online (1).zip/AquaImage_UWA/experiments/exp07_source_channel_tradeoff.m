function R = exp07_source_channel_tradeoff()
%EXP07_SOURCE_CHANNEL_TRADEOFF Experiment 7: compression rate x channel-code rate.
%
%   Grid: JPEG quality {20,40,60,80} x LDPC rate {1/2,2/3,3/4} x true SNR
%   {5,8,11} dB on the multipath channel, SR-ARQ (max 3 retries), 4 images.
%   The camera interval is 120 s, so the per-image delay equals the SERVICE
%   LATENCY (first symbol on air -> image decoded), no queueing.
%   Resource budget: a latency deadline Tb per image (8, 12, 16 s). For each
%   operating point the utility is
%       U = mean over images of  1[delivered and latency <= Tb] * SSIM(I, I_r)
%   (an image that misses the deadline contributes 0; this is a utility
%   definition, NOT an image-quality measurement of an undelivered image).
%   Outputs: tables/exp07_points.csv (per image), exp07_utility.csv,
%   figures/exp07_utility_*.png. Exp 10 uses the table as a lookup.
base = experiment_base();
base.arq.enabled = true; base.arq.maxRetries = 3;
base.source.interval_s = 120;
qs = [20 40 60 80]; Rs = [1/2 2/3 3/4]; snrs = [5 8 11];
rows = {};
pt = 0;
for s = snrs
    for q = qs
        for Rc = Rs
            pt = pt + 1;
            c = base; c.codec.jpegQuality = q; c.fec.rate = Rc; c.chan.snrDb = s;
            set_seed(base.seed + 7000 + pt);
            S = run_link_simulation(c, struct('tag', 'exp07', 'saveArtifacts', false));
            P = S.perImage;
            for k = 1:numel(P)
                rows(end + 1, :) = {s, q, Rc, P(k).id, P(k).compBytes, P(k).bpp, P(k).success, P(k).delay_s, ...
                    P(k).ssim_I_Ic, P(k).psnr_I_Ic, P(k).airtime_s, P(k).turnaround_s, P(k).PER_initial, P(k).snrEstDb}; %#ok<AGROW>
            end
            fprintf('[exp07] SNR %2d q%2d R=%s: delivered %d/4, mean latency %.1f s, bpp %.2f\n', s, q, rate_str(Rc), ...
                nnz([P.success]), mean([P([P.success]).delay_s]), mean([P.bpp]));
        end
    end
end
hdr = {'snrDb', 'jpegQuality', 'rate', 'image', 'compBytes', 'bpp', 'success', 'latency_s', 'ssim_I_Ic', 'psnr_I_Ic', ...
    'airtime_s', 'turnaround_s', 'PER_initial', 'snrEstDb'};
td = fullfile(base.out.resultsDir, 'tables');
write_csv(fullfile(td, 'exp07_points.csv'), hdr, rows);
R.rows = rows;
R.U = jscc_utility(rows, qs, Rs, snrs, [8 12 16]);
write_csv(fullfile(td, 'exp07_utility.csv'), {'snrDb', 'deadline_s', 'jpegQuality', 'rate', 'onTimeRate', 'meanSsimOnTime', 'utility', 'meanLatency_s', 'snrEstDb'}, R.U);
% figure: utility vs JPEG quality, one panel per SNR (deadline 12 s)
f = prepare_figure(1100, 380);
for i = 1:numel(snrs)
    subplot(1, numel(snrs), i); hold on;
    for Rc = Rs
        m = cell2mat(R.U(:, 1)) == snrs(i) & cell2mat(R.U(:, 2)) == 12 & abs(cell2mat(R.U(:, 4)) - Rc) < 1e-9;
        plot(cell2mat(R.U(m, 3)), cell2mat(R.U(m, 7)), 'o-', 'LineWidth', 1.4);
    end
    grid on; ylim([0 1]); xlabel('JPEG quality'); ylabel('utility (on-time x SSIM)');
    title(sprintf('SNR %d dB, deadline 12 s', snrs(i)));
    legend(arrayfun(@(r) sprintf('LDPC %s', rate_str(r)), Rs, 'UniformOutput', false), 'Location', 'southwest');
end
save_figure(f, fullfile(base.out.resultsDir, 'figures', 'exp07_utility_deadline12.png'));
f = prepare_figure(1100, 380);
for i = 1:numel(snrs)
    subplot(1, numel(snrs), i); hold on;
    for Rc = Rs
        m = cell2mat(R.U(:, 1)) == snrs(i) & cell2mat(R.U(:, 2)) == 12 & abs(cell2mat(R.U(:, 4)) - Rc) < 1e-9;
        plot(cell2mat(R.U(m, 3)), cell2mat(R.U(m, 8)), 's-', 'LineWidth', 1.4);
    end
    grid on; xlabel('JPEG quality'); ylabel('mean service latency (s)');
    title(sprintf('SNR %d dB', snrs(i)));
    legend(arrayfun(@(r) sprintf('LDPC %s', rate_str(r)), Rs, 'UniformOutput', false), 'Location', 'northwest');
end
save_figure(f, fullfile(base.out.resultsDir, 'figures', 'exp07_latency.png'));
end
