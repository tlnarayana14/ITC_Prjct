function R = exp09_end_to_end()
%EXP09_END_TO_END Experiment 9: full real-data pipeline on all 23 images and
%   consistency of reconstruction outcomes with the measured bit/packet errors.
%
%   Run A: JPEG XL (distance 3), time-varying channel (multipath + Doppler +
%          Rician fading), 9 dB, LDPC 1/2, SR-ARQ max 3, camera 1 image/s.
%   Run B: same but 5 dB and NO ARQ (to produce incomplete images).
%   Run C: 7 dB, NO ARQ (mixture of delivered and incomplete images).
%   Consistency rules checked for every image:
%     R1 success  => all packets delivered, stream identical, I_r == I_c
%     R2 ~complete => at least one packet lost AND no image decoded
%     R3 delivered-bit errors == 0 unless a CRC-undetected packet occurred
%     R4 lost packets == erased payload bits / (8 * payload size) (bit-exact)
%     R5 PER_final * nPkts == number of lost packets
%   Artefacts (original, compressed file, I_c, received stream, I_r,
%   diagnostics JSON) are saved under results/reconstructed_images/exp09_*.
base = experiment_base();
base.source.numImages = 23;
base.codec.name = 'jpegxl'; base.codec.jxlDistance = 3;
base.chan.model = 'timevarying';
runs = {'A', 9, true; 'B', 5, false; 'C', 7, false};
rows = {}; R = struct();
for r = 1:size(runs, 1)
    c = base; c.chan.snrDb = runs{r, 2}; c.arq.enabled = runs{r, 3}; c.arq.maxRetries = 3;
    if ~codec_available('jpegxl', c), c.codec.name = 'jpeg'; c.codec.jpegQuality = 40; end
    set_seed(base.seed + 900 + r);
    tag = ['exp09_' runs{r, 1}];
    S = run_link_simulation(c, struct('tag', tag, 'saveArtifacts', true));
    P = S.perImage;
    chk = zeros(numel(P), 5);
    for k = 1:numel(P)
        e = P(k);
        chk(k, 1) = ~e.success || (e.lost == 0 && e.streamIdentical && e.IcEqualsIr);
        chk(k, 2) = e.complete || (e.lost > 0 && isnan(e.psnr_I_Ir));
        chk(k, 3) = e.e2eErr == 0 || e.undetected > 0;
        lastLen = e.compBytes - (e.nPkts - 1) * c.pkt.payloadBytes;
        lostSeq = e.reassembly.missing;
        expErased = 8 * (numel(lostSeq) * c.pkt.payloadBytes - any(lostSeq == e.nPkts - 1) * (c.pkt.payloadBytes - lastLen));
        chk(k, 4) = e.e2eErased == expErased;
        chk(k, 5) = abs(e.PER_final * e.nPkts - e.lost) < 1e-9;
        rows(end + 1, :) = {runs{r, 1}, e.id, e.compBytes, e.bpp, e.nPkts, e.firstFail, e.lost, e.preErr / e.preN, ...
            e.postErr / e.postN, e.e2eErr, e.e2eErased, e.complete, e.success, e.streamIdentical, e.psnr_I_Ic, e.psnr_I_Ir, ...
            e.ssim_I_Ir, e.IcEqualsIr, all(chk(k, :))}; %#ok<AGROW>
    end
    R.(runs{r, 1}) = struct('summary', S.summary, 'checks', chk);
    fprintf('[exp09] run %s: delivered %d/%d, consistency rules satisfied for %d/%d images\n', runs{r, 1}, ...
        S.summary.nDelivered, numel(P), nnz(all(chk, 2)), numel(P));
    plot_e2e_examples(S, tag, fullfile(base.out.resultsDir, 'figures', sprintf('exp09_%s_examples.png', runs{r, 1})));
    fid = fopen(fullfile(base.out.resultsDir, 'logs', sprintf('exp09_%s_summary.json', runs{r, 1})), 'w');
    fprintf(fid, '%s', jsonencode(S.summary)); fclose(fid);
end
hdr = {'run', 'image', 'compBytes', 'bpp', 'nPkts', 'firstFail', 'lost', 'BER_pre', 'BER_post', 'e2eErrBits', 'e2eErasedBits', ...
    'complete', 'success', 'streamIdentical', 'psnr_I_Ic', 'psnr_I_Ir', 'ssim_I_Ir', 'IrEqualsIc', 'allChecksOk'};
write_csv(fullfile(base.out.resultsDir, 'tables', 'exp09_end_to_end.csv'), hdr, rows);
R.rows = rows;
end

function plot_e2e_examples(S, tag, fname)
% four images: prefer showing both delivered and (if any) undelivered ones
P = S.perImage;
ok = find([P.success]); bad = find(~[P.success]);
sel = [bad(1:min(2, numel(bad))), ok(1:min(4 - min(2, numel(bad)), numel(ok)))];
d = fullfile(S.cfg.out.resultsDir, 'reconstructed_images', tag);
f = prepare_figure(900, 280 * numel(sel));
for i = 1:numel(sel)
    e = P(sel(i));
    b = fullfile(d, sprintf('img%03d', e.id));
    subplot(numel(sel), 3, 3 * i - 2); image(imread([b '_original.png'])); axis image off;
    title(sprintf('I, img %d', e.id));
    subplot(numel(sel), 3, 3 * i - 1); image(imread([b '_Ic_local_decode.png'])); axis image off;
    title(sprintf('I_c %s %.2f bpp, %.1f dB', e.codec, e.bpp, e.psnr_I_Ic));
    subplot(numel(sel), 3, 3 * i);
    if exist([b '_Ir_received.png'], 'file') == 2
        image(imread([b '_Ir_received.png'])); axis image off;
        title(sprintf('I_r: %d/%d first-try fails, I_r=I_c %d', e.firstFail, e.nPkts, e.IcEqualsIr));
    else
        axis off; text(0.5, 0.5, sprintf('NOT DELIVERED\n%d of %d packets lost', e.lost, e.nPkts), 'HorizontalAlignment', 'center');
        title('I_r: incomplete stream, not decoded');
    end
end
save_figure(f, fname);
end
