function test_P1_image_source()
%TEST_P1_IMAGE_SOURCE Phase 1: multi-format loading, metadata, camera schedule.
cfg = test_config();
d = fullfile(cfg.root, 'data', 'format_test');
files = list_image_files(d, cfg.source.extensions);
check(numel(files) == 6, 'format_test contains 6 images (found %d)', numel(files));
fmts = {};
for k = 1:numel(files)
    r = load_image_record(files{k}, k - 1);
    fmts{end + 1} = r.format; %#ok<AGROW>
    check(isa(r.pixels, 'uint8') && any(r.channels == [1 3]), '%s loads as uint8 with %d channel(s), %dx%d, %d-bit input, conversion: %s', ...
        r.format, r.channels, r.width, r.height, r.bitDepthIn, r.conversion);
    [~, n] = fileparts(files{k});
    switch n
        case 'fmt_png_gray', check(r.channels == 1, 'grayscale image keeps 1 channel');
        case 'fmt_jpg_crop', check(r.width == 200 && r.height == 150, 'non-square image dimensions preserved (200x150)');
        case 'fmt_tif_rgb16'
            check(r.bitDepthIn == 16, '16-bit TIFF depth recorded');
            ref = load_image_record(fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_20.jpg'), 0);
            check(isequal(r.pixels, ref.pixels), '16-bit TIFF (x*257) maps back exactly to its 8-bit source');
    end
end
for f = {'jpg', 'png', 'bmp', 'tif'}
    check(any(strcmp(fmts, f{1})), 'format %s exercised', f{1});
end
% camera schedule on the underwater folder
cfg.source.numImages = 30; cfg.source.interval_s = 0.5;
ev = image_source_schedule(cfg);
check(numel(ev) == 30 && isequal([ev.id], 0:29), 'unique sequential image IDs 0..29');
check(max(abs([ev.tGen] - (0:29) * 0.5)) < 1e-12, 'arrival times follow the configured 0.5 s interval');
check(strcmp(ev(24).path, ev(1).path), 'folder of 23 images is cycled for image 24');
try
    load_image_record(fullfile(d, 'does_not_exist.png'), 0);
    check(false, 'missing file must raise an error');
catch err
    check(~isempty(strfind(err.message, 'not found')), 'missing file gives a meaningful error: "%s"', err.message);
end
end
