function export_training_channel(cfg, fname)
%EXPORT_TRAINING_CHANNEL Write the OFDM/multipath parameters used to train Deep JSCC.
%   The Python training loop rebuilds per-subcarrier channel responses
%   H_k = sum_p g_p (Rician-perturbed) exp(-j 2 pi f_k tau_p) from exactly the
%   geometry, subcarrier grid and data-subcarrier map of the Octave simulator.
if nargin < 1, cfg = default_config(); end
if nargin < 2, fname = fullfile(cfg.root, 'data', 'channels', 'ofdm_training_channel.json'); end
p = ofdm_params(cfg);
pth = uwa_multipath_geometry(cfg);
s.delay_s = pth.delay_s(:).';
s.gain_re = real(pth.gain(:)).'; s.gain_im = imag(pth.gain(:)).';
s.freq_hz = (p.kRel(p.dataIdx) * p.df).';
s.nData = numel(p.dataIdx);
s.ricianK = cfg.chan.ricianK;
s.symbolPeriod_s = p.Nsym / p.fs;
s.fadingFd_Hz = cfg.chan.fadingFd_Hz;
s.K_over_Nused = p.K / p.nUsed;
fid = fopen(fname, 'w'); fprintf(fid, '%s', jsonencode(s)); fclose(fid);
end
