function x = polar_encode(pc, u)
%POLAR_ENCODE Polar encoding x = v * F^{(x)n} with frozen positions set to 0.
%   x = POLAR_ENCODE(pc, u)   u: K x B information bits, x: N x B code bits.
%   Recursive butterfly: x = [T(v1) xor T(v2); T(v2)] for v = [v1; v2].
if size(u, 1) ~= pc.K
    error('polar_encode:size', 'Expected %d info bits per column.', pc.K);
end
v = zeros(pc.N, size(u, 2));
v(pc.info, :) = u;
x = transform(v);
end

function x = transform(v)
N = size(v, 1);
if N == 1
    x = v; return;
end
h = N / 2;
a = transform(v(1:h, :));
b = transform(v(h + 1:end, :));
x = [mod(a + b, 2); b];
end
