function a = thorp_absorption(f_kHz)
%THORP_ABSORPTION Thorp's empirical absorption coefficient in dB/km (f in kHz).
%   10 log a(f) = 0.11 f^2/(1+f^2) + 44 f^2/(4100+f^2) + 2.75e-4 f^2 + 0.003
%   (as used e.g. in M. Stojanovic, "On the relationship between capacity
%   and distance in an underwater acoustic communication channel", 2007).
f2 = f_kHz.^2;
a = 0.11 * f2 ./ (1 + f2) + 44 * f2 ./ (4100 + f2) + 2.75e-4 * f2 + 0.003;
end
