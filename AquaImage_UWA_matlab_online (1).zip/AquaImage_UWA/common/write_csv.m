function write_csv(fname, header, data)
%WRITE_CSV Write a numeric/cell table to CSV (MATLAB+Octave portable).
%   header : cell array of column names
%   data   : numeric matrix or cell array (rows x cols); char cells are quoted
fid = fopen(fname, 'w');
if fid < 0
    error('write_csv:open', 'Cannot create %s', fname);
end
fprintf(fid, '%s\n', strjoin(header, ','));
if isnumeric(data)
    data = num2cell(data);
end
for r = 1:size(data, 1)
    parts = cell(1, size(data, 2));
    for c = 1:size(data, 2)
        v = data{r, c};
        if ischar(v)
            parts{c} = ['"' strrep(v, '"', '""') '"'];
        elseif islogical(v)
            parts{c} = sprintf('%d', v);
        elseif isempty(v)
            parts{c} = '';
        else
            parts{c} = sprintf('%.10g', v);
        end
    end
    fprintf(fid, '%s\n', strjoin(parts, ','));
end
fclose(fid);
end
