function p = ofdm_params(cfg)
%OFDM_PARAMS Derived CP-OFDM parameters for the acoustic band (cached).
%
%   Band: K subcarriers over B Hz (df = B/K), complex baseband sampled at
%   fs = osf*B (Nfft = osf*K). In-band index i = 0..K-1 corresponds to
%   baseband frequency (i - K/2)*df and FFT bin mod(i - K/2, Nfft) + 1.
%   Pilots : every pilotSpacing-th in-band subcarrier (QPSK, known)
%   Nulls  : numNull zero subcarriers: all non-pilot carriers among the 24
%            lowest and 24 highest in-band indices, the rest spread through
%            the band (deterministic hash) -> used for noise/ICI power and
%            residual-CFO estimation (null-subcarrier method)
%   Data   : the remaining in-band subcarriers
%   Channel estimation: time-domain LS with Lh = chEstTaps_s*B taps from
%   the pilot tones (requires Lh <= #pilots), optional averaging over
%   chEstAvgSymbols OFDM symbols, then significant-tap selection: taps with
%   |h_l|^2 <= tapThreshold * (N0/Npilot) are set to zero (most of the Lh
%   taps of a sparse acoustic channel contain only noise), and finally
%   interpolation to all subcarriers via the DFT matrix.
%   The FFT window starts 'backoff' samples before the end of the
%   CP (Ncp/8 = 3.1 ms) to tolerate paths arriving before the synchronised
%   (strongest) path.
%
%   Defaults (cfg): B = 8 kHz, K = 1024 -> df = 7.8125 Hz, T = 128 ms,
%   Tcp = 25 ms, 256 pilots, 96 nulls, 672 data subcarriers.

o = cfg.phy.ofdm;
B = cfg.phy.B;
p.B = B; p.K = o.K; p.osf = o.osf;
p.fs = o.osf * B;
p.Nfft = o.osf * o.K;
p.df = B / o.K;
p.T = 1 / p.df;
p.Ncp = round(o.cp_s * p.fs);
p.Nsym = p.Nfft + p.Ncp;
p.backoff = round(p.Ncp / 8);
p.fc = cfg.phy.fc;

i = (0:o.K - 1).';
p.kRel = i - o.K / 2;                         % relative subcarrier index
p.bin = mod(p.kRel, p.Nfft) + 1;              % FFT bin of each in-band carrier
isPilot = mod(i, o.pilotSpacing) == 0;
isNull = false(o.K, 1);
edge = [1:24, o.K - 23:o.K];
isNull(edge) = ~isPilot(edge);
need = o.numNull - nnz(isNull);
cand = find(~isPilot & ~isNull);
perm = hash_perm(numel(cand), 777);
isNull(cand(perm(1:need))) = true;
p.pilotIdx = find(isPilot);
p.nullIdx = find(isNull);
p.nullInband = setdiff(p.nullIdx, edge(:));  % nulls away from the band edges
p.dataIdx = find(~isPilot & ~isNull);
p.nUsed = o.K - numel(p.nullIdx);
p.pilotSym = det_qpsk_seq(numel(p.pilotIdx), 99);
p.scale = p.Nfft / sqrt(p.nUsed);             % unit average time-domain power

% LS channel estimator (time domain, taps at spacing 1/B)
p.Lh = round(o.chEstTaps_s * B);
l = 0:p.Lh - 1;
% Delay is measured from the start of the FFT window, which is 'backoff'
% samples early, so precursor paths (up to backoff) still have delay >= 0.
F = @(idx) exp(-1j * 2 * pi * (p.kRel(idx) * l) / o.K);
Fp = F(p.pilotIdx);
p.Fall = F((1:o.K).');                        % K x Lh
p.pinvFp = pinv(Fp);                          % Lh x nPilot (= Fp'/nPilot: equispaced pilots)
p.tapThreshold = o.tapThreshold;              % keep taps with |h|^2 > thr * tap noise var
p.avgSymbols = o.chEstAvgSymbols;             % moving average of pilot LS over symbols

% LFM chirp (preamble and postamble), unit power, sweeping the band
p.Nchirp = round(o.chirp_s * p.fs);
t = (0:p.Nchirp - 1).' / p.fs;
mu = B / o.chirp_s;
p.chirp = exp(1j * pi * (mu * t.^2 - B * t));
p.Nguard = round(cfg.phy.guard_s * p.fs);
end
