# Requirements traceability — original prompt §1–§33 → implementation → evidence

Status: ✅ done and executed · 🟡 done with a documented limitation · ⛔ not possible here (reason).
"Test" refers to `tests/test_*.m` (run with `run_all_tests`, report in
`results/logs/test_report.txt`); "Exp" to `experiments/exp*.m` (tables in
`results/tables`, figures in `results/figures`).

| § | Requirement | Where implemented | Evidence | Status |
|---|---|---|---|---|
| 1 | Build, run and validate, not just design; never claim unexecuted work | whole repo | logs, tests, `results/logs/RUN_NOTES.md` | ✅ (executed in GNU Octave 8.4; 🟡 MATLAB not available) |
| 2 | Continuous still-image camera, configurable rate, JPEG/PNG/BMP/TIFF, no video codec | `source/*`, `cfg.source.interval_s` | Test P1, Exp 8 | ✅ |
| 3 | Full TX / channel / RX pipeline in one workflow | `main.m`, `link/run_link_simulation.m` | Test J, Exp 9 | ✅ |
| 4 | Execution rules (no random payloads, CRC ≠ correction, no silent drops, honest incomplete images, no fabricated numbers) | `link/transmit_image.m`, `packetization/*` | Tests C, I, L; Exp 9 consistency rules 69/69 | ✅ |
| 5 | Research and algorithm selection with verifiable sources | `docs/LITERATURE_REVIEW.md` | [V]/[S] verification labels | ✅ |
| 6 | Image source: formats, metadata, gray/RGB, dimensions, bit depth, IDs, queue, timestamps, dataset investigation, user folder | `load_image_record`, `image_source_schedule`, `cfg.source.datasetPath` | Test P1 | ✅ 🟡 UIEB/RUIE not downloadable (EUVP samples used) |
| 7 | JPEG, JPEG XL, learned codec; size/CR/time/PSNR/SSIM; matched bitrate; lossless check; common interface | `source_coding/*`, `tools/learned_codec.py`, Deep JSCC (`tools/deepjscc`) | Test A, X; Exp 1, Exp 12 | ✅ 🟡 pretrained CompressAI weights unreachable; learned *JSCC* model trained and evaluated instead (Exp 12) |
| 8 | Exact compressed-stream extraction + metadata + integrity info | `source_encode` (`enc.bytes`, `enc.streamCrc32`) | Tests B, K (stream CRC check) | ✅ |
| 9 | Packetization with ID/seq/total/len/CRC, detect missing/dup/out-of-order/bad length/corruption/incomplete | `packetize`, `parse_packet`, `reassemble_packets` | Test C | ✅ |
| 10 | CRC fully specified, same at both ends, tests, overhead | `crc_spec`, `crc_compute` | Test D (zlib cross-check) | ✅ |
| 11 | LDPC primary (rates 1/2, 2/3, 3/4), framing/padding, bit-count tracking; optional polar and RS | `ldpc_*`, `polar_*`, `polar_scl_decode`, `rs_*`, `fec_*` | Tests E, H; Exp 2, 3, 13A | ✅ 🟡 LDPC tables are our own 802.11n-structured family |
| 12 | QPSK, soft decisions, documented mapping/conventions, no-noise and noisy tests | `modulation/*` | Tests F, G | ✅ (+ BPSK, 16QAM) |
| 13 | OFDM with pilots, CP, sync, channel estimation, equalisation; justified parameters; separate from simple chain | `phy/phy_ofdm_*`, `phy/phy_sc_*` | Tests F, G, J; Exp 4 | ✅ |
| 14 | Channel models A–E with documented assumptions | `channel/uwa_channel.m` (+ geometry, Thorp), `load_replay_channel` | Tests G, J, N; Exp 4 | ✅ A–D; 🟡 E = replay interface validated with a *synthetic* file — no measured data available offline |
| 15 | Complete receiver chain | `phy_ofdm_rx`, `transmit_frame`, `transmit_image` | Tests H, J | ✅ |
| 16 | Recovery policy: CRC accept/reject, SR retransmission, retry limit, no-ARQ baseline, overhead accounting | `transmit_image` (+ `transmit_image_fountain`) | Test I, O; Exp 6, 13B | ✅ |
| 17 | Bitstream reassembly checks incl. integrity | `reassemble_packets`, stream CRC | Tests C, K | ✅ |
| 18 | Matching decoder, saved artefacts, side-by-side, I_r = I_c check, no hallucinated content | `source_decode`, `save_artifacts`, `plot_side_by_side` | Exp 9 artefacts, Test K | ✅ |
| 19 | BER_pre / BER_post / BER_E2E / PER (initial & final) / delivery / goodput / delay with exact scopes | `metrics/summarize_run.m` | Tests L, I | ✅ |
| 20 | PSNR, SSIM, CR, size, delivery, optional ROI metrics; three-way I / I_c / I_r comparison | `psnr_u8`, `ssim_luma`, `image_quality_triplet`, `roi_metrics` | Test X (scikit-image equality), Test P | ✅ |
| 21 | Continuous source + queue: timestamps, finite capacity, FIFO/deadline/drop, queue length/delay/loss | `simulate_queue` | Test M; Exp 8 | ✅ |
| 22 | Adaptive source and channel coding (rule-based), feedback delay, vs fixed | `rate_controller`, `amc_controller`, `jscc_controller` | Test Q; Exp 5, 5b, 10 | ✅ (code rate, modulation, source quality) |
| 23 | Advanced features: learned compression, ROI, UEP, adaptive modulation, advanced channel, fountain/erasure, quality-aware retransmission, JSCC | Deep JSCC, `roi_detect` + `transmit_roi_uep`, `amc_controller`, replay channel, fountain code, ROI-only ARQ, JSCC controller | Exp 10, 11, 12, 5b, 13 | ✅ (see each experiment's limitations) |
| 24 | Experiments 1–10 with seeds, trials, uncertainty | `experiments/exp01..exp10` | tables + Wilson CIs | ✅ (+ Exp 5b, 11, 12, 13) |
| 25 | Organised MATLAB project structure, documented functions | repo layout (`README.md`) | — | ✅ |
| 26 | `main.m` + configuration switches + validation and meaningful errors | `main.m`, `default_config`, `validate_config` | Test P1 (missing file message) | ✅ |
| 27 | Tests A–M | `tests/` (+ N, O, P, Q, X) | `test_report.txt` | ✅ |
| 28 | Required plots | `results/figures` (≥ 38 files) | — | ✅ |
| 29 | Focused literature review, one research contribution with RQ/hypothesis/baselines/variables/protocol | `docs/LITERATURE_REVIEW.md` §4, Exp 10 | — | ✅ |
| 30 | Technical report with all sections, results only from executed runs | `docs/TECHNICAL_REPORT.md` | — | ✅ |
| 31 | Completion checklist | `docs/PROJECT_STATUS.md` | — | ✅ |
| 32 | Staged execution, status reports, status document | `docs/PROJECT_STATUS.md`, chat stage reports | — | ✅ |
| 33 | First milestone = working real-image baseline | `main.m` | `main_summary.json` | ✅ |

Remaining environment limits (cannot be resolved inside this sandbox):
MATLAB execution; pretrained CompressAI weights; UIEB/RUIE downloads;
measured underwater channel recordings; GPU-scale Deep JSCC training.
