#!/usr/bin/env python3
"""Independent reference values for the MATLAB/Octave metric and codec code.

  crosscheck_metrics.py metrics A.png B.png
      -> "psnr ssim" using scikit-image on BT.601 luma (same definition as
         metrics/ssim_luma.m: gaussian window sigma=1.5, K1=.01, K2=.03,
         population covariance, data_range=255) and PSNR over all channels.
  crosscheck_metrics.py jxl file.jxl ref.png
      -> "maxabsdiff fraction_differing" between imagecodecs' libjxl decoder
         output and ref.png (decoded by the djxl used in the simulator).
"""
import sys
import numpy as np
from PIL import Image

def luma(a):
    a = a.astype(np.float64)
    if a.ndim == 3:
        return 0.299 * a[..., 0] + 0.587 * a[..., 1] + 0.114 * a[..., 2]
    return a

if sys.argv[1] == "metrics":
    from skimage.metrics import structural_similarity, peak_signal_noise_ratio
    A = np.asarray(Image.open(sys.argv[2])); B = np.asarray(Image.open(sys.argv[3]))
    p = peak_signal_noise_ratio(A, B, data_range=255)
    s = structural_similarity(luma(A), luma(B), gaussian_weights=True, sigma=1.5,
                              use_sample_covariance=False, data_range=255)
    print(f"{p:.10f} {s:.10f}")
elif sys.argv[1] == "jxl":
    import imagecodecs
    d = imagecodecs.jpegxl_decode(open(sys.argv[2], "rb").read())
    r = np.asarray(Image.open(sys.argv[3]))
    if d.shape != r.shape:
        print("999 1"); sys.exit(0)
    a = np.abs(d.astype(int) - r.astype(int))
    print(f"{a.max()} {(a > 0).mean():.6f}")
