function [llr, d] = phy_rx(r, meta, cfg)
%PHY_RX Physical-layer receiver dispatcher; returns coded-bit LLRs (L = log P0/P1).
switch lower(meta.type)
    case 'sc',   [llr, d] = phy_sc_rx(r, meta, cfg);
    case 'ofdm', [llr, d] = phy_ofdm_rx(r, meta, cfg);
    otherwise, error('phy_rx:type', 'Unknown PHY %s', meta.type);
end
end
