function bd = bd_rate(R1, Q1, R2, Q2)
%BD_RATE Bjontegaard delta rate (%) of codec 2 relative to codec 1.
%   bd = BD_RATE(R1, Q1, R2, Q2): R = bitrates (e.g. bpp), Q = quality
%   (PSNR in dB or SSIM). Fits log10(R) as a cubic polynomial of Q for each
%   codec, integrates both over the overlapping quality interval and returns
%   100*(10^(mean difference) - 1). Negative = codec 2 needs fewer bits.
%   (G. Bjontegaard, VCEG-M33, 2001.) Requires >= 4 points per curve.
[Q1, i1] = sort(Q1(:)); R1 = R1(:); R1 = R1(i1);
[Q2, i2] = sort(Q2(:)); R2 = R2(:); R2 = R2(i2);
p1 = polyfit(Q1, log10(R1), 3);
p2 = polyfit(Q2, log10(R2), 3);
lo = max(min(Q1), min(Q2)); hi = min(max(Q1), max(Q2));
if hi <= lo
    bd = NaN; return;
end
P1 = polyint(p1); P2 = polyint(p2);
a1 = (polyval(P1, hi) - polyval(P1, lo)) / (hi - lo);
a2 = (polyval(P2, hi) - polyval(P2, lo)) / (hi - lo);
bd = 100 * (10^(a2 - a1) - 1);
end
