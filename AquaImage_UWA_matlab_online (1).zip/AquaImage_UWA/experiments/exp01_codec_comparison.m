function R = exp01_codec_comparison(cfg)
%EXP01_CODEC_COMPARISON Experiment 1: JPEG vs JPEG XL (vs learned, if available)
%   rate-distortion on all images of the dataset, no channel involved.
%
%   Variants: 'native' (256x256 EUVP frames) and 'shift4' (4-pixel crop on the
%   top/left -> 252x252) because the EUVP frames are themselves JPEG files
%   whose 8x8 block grid could favour JPEG re-encoding; the shifted variant
%   breaks the grid alignment.
%   Per image/setting: compressed bytes, bpp, CR, PSNR, SSIM (luma), encoder
%   and decoder wall-clock times (Octave/MATLAB host, includes file I/O).
%   Outputs: tables/exp01_codec_rd.csv, exp01_codec_summary.csv,
%   exp01_matched_bitrate.csv, figures/exp01_*.png, R struct.
if nargin < 1, cfg = default_config(); end
cfg = validate_config(cfg);
files = list_image_files(cfg.source.datasetPath, cfg.source.extensions);
jq = [10 20 30 40 50 60 70 80 90];
jd = [0.5 1 1.5 2 3 4 6 8];
hasJxl = codec_available('jpegxl', cfg);
hasLearned = codec_available('learned', cfg);
rows = {};
for v = {'native', 'shift4'}
    for f = 1:numel(files)
        r = load_image_record(files{f}, f - 1);
        I = r.pixels;
        if strcmp(v{1}, 'shift4'), I = I(5:end, 5:end, :); end
        settings = [num2cell([ones(numel(jq), 1), jq(:)], 2); ...
            ternary(hasJxl, num2cell([2 * ones(numel(jd), 1), jd(:)], 2), cell(0, 1)); {[3 0]}; ...
            ternary(hasJxl, {[2 0]}, cell(0, 1))];
        for s = 1:numel(settings)
            st = settings{s};
            c = cfg;
            switch st(1)
                case 1, c.codec.name = 'jpeg'; c.codec.jpegQuality = st(2); nm = 'JPEG'; par = st(2);
                case 2, c.codec.name = 'jpegxl'; c.codec.jxlDistance = st(2); nm = ternary(st(2) == 0, 'JPEG XL lossless', 'JPEG XL'); par = st(2);
                case 3, c.codec.name = 'png'; nm = 'PNG lossless'; par = 0;
            end
            e = source_encode(I, c);
            rows(end + 1, :) = {v{1}, f - 1, nm, par, numel(e.bytes), e.bpp, e.CR, psnr_u8(I, e.Ic), ...
                ssim_luma(I, e.Ic), e.encTime_s, e.decTime_s, e.lossless}; %#ok<AGROW>
        end
    end
    log_msg(cfg, 1, 'exp01: variant %s done (%d rows)', v{1}, size(rows, 1));
end
hdr = {'variant', 'image', 'codec', 'param', 'bytes', 'bpp', 'CR', 'psnr', 'ssim', 'encTime_s', 'decTime_s', 'lossless'};
tdir = fullfile(cfg.out.resultsDir, 'tables');
write_csv(fullfile(tdir, 'exp01_codec_rd.csv'), hdr, rows);

% ---- summary per codec/setting/variant
V = rows(:, 1); C = rows(:, 3); Pm = cell2mat(rows(:, 4)); N = cell2mat(rows(:, 5:11));
keys = unique(strcat(V, '|', C, '|', cellfun(@(x) sprintf('%g', x), rows(:, 4), 'UniformOutput', false)));
srows = {};
for k = 1:numel(keys)
    parts = strsplit(keys{k}, '|');
    m = strcmp(V, parts{1}) & strcmp(C, parts{2}) & abs(Pm - str2double(parts{3})) < 1e-9;
    x = N(m, :);
    srows(end + 1, :) = {parts{1}, parts{2}, str2double(parts{3}), nnz(m), mean(x(:, 1)), mean(x(:, 2)), ...
        mean(x(:, 3)), mean(x(:, 4)), std(x(:, 4)), mean(x(:, 5)), std(x(:, 5)), mean(x(:, 6)), mean(x(:, 7))}; %#ok<AGROW>
end
write_csv(fullfile(tdir, 'exp01_codec_summary.csv'), {'variant', 'codec', 'param', 'n', 'bytes', 'bpp', 'CR', ...
    'psnr', 'psnr_std', 'ssim', 'ssim_std', 'encTime_s', 'decTime_s'}, srows);

% ---- BD-rate (JPEG XL vs JPEG) per image, and matched-bitrate quality
R.bd = struct();
mrows = {};
targets = [0.5 1.0 1.5 2.0];
for v = {'native', 'shift4'}
    bdP = []; bdS = [];
    q = struct('JPEG', zeros(0, numel(targets), 2), 'JXL', zeros(0, numel(targets), 2));
    for f = 0:numel(files) - 1
        mj = strcmp(V, v{1}) & strcmp(C, 'JPEG') & cell2mat(rows(:, 2)) == f;
        mx = strcmp(V, v{1}) & strcmp(C, 'JPEG XL') & cell2mat(rows(:, 2)) == f;
        if ~any(mx), continue; end
        bdP(end + 1) = bd_rate(N(mj, 2), N(mj, 4), N(mx, 2), N(mx, 4)); %#ok<AGROW>
        bdS(end + 1) = bd_rate(N(mj, 2), N(mj, 5), N(mx, 2), N(mx, 5)); %#ok<AGROW>
        q.JPEG(end + 1, :, :) = interp_at(N(mj, 2), N(mj, 4:5), targets);
        q.JXL(end + 1, :, :) = interp_at(N(mx, 2), N(mx, 4:5), targets);
    end
    R.bd.(v{1}) = struct('psnr_mean', mean(bdP), 'psnr_std', std(bdP), 'ssim_mean', mean(bdS), 'ssim_std', std(bdS), 'n', numel(bdP));
    for t = 1:numel(targets)
        a = q.JPEG(:, t, :); b = q.JXL(:, t, :);
        okp = ~isnan(a(:, 1, 1)) & ~isnan(b(:, 1, 1));
        mrows(end + 1, :) = {v{1}, targets(t), nnz(okp), mean(a(okp, 1, 1)), mean(b(okp, 1, 1)), ...
            mean(a(okp, 1, 2)), mean(b(okp, 1, 2))}; %#ok<AGROW>
    end
end
if hasJxl
    write_csv(fullfile(tdir, 'exp01_matched_bitrate.csv'), {'variant', 'bpp', 'nImages', 'psnr_JPEG', 'psnr_JXL', 'ssim_JPEG', 'ssim_JXL'}, mrows);
    bdr = {};
    for v = {'native', 'shift4'}
        b = R.bd.(v{1});
        bdr(end + 1, :) = {v{1}, b.n, b.psnr_mean, b.psnr_std, b.ssim_mean, b.ssim_std}; %#ok<AGROW>
    end
    write_csv(fullfile(tdir, 'exp01_bdrate.csv'), {'variant', 'nImages', 'BDrate_PSNR_pct', 'std', 'BDrate_SSIM_pct', 'std'}, bdr);
end
R.rows = rows; R.summary = srows; R.matched = mrows; R.hasLearned = hasLearned;

% ---- figures
fdir = fullfile(cfg.out.resultsDir, 'figures');
mk = {'JPEG', 'o-'; 'JPEG XL', 's-'};
for metric = {'psnr', 'ssim'}
    f = prepare_figure(760, 480); hold on;
    leg = {};
    for v = {'native', 'shift4'}
        for k = 1:size(mk, 1)
            m = strcmp(srows(:, 1), v{1}) & strcmp(srows(:, 2), mk{k, 1});
            if ~any(m), continue; end
            x = cell2mat(srows(m, 6)); y = cell2mat(srows(m, ternary(strcmp(metric{1}, 'psnr'), 8, 10)));
            [x, o] = sort(x); y = y(o);
            st = mk{k, 2}; if strcmp(v{1}, 'shift4'), st = strrep(st, '-', '--'); end
            plot(x, y, st, 'LineWidth', 1.5);
            leg{end + 1} = sprintf('%s (%s)', mk{k, 1}, v{1}); %#ok<AGROW>
        end
    end
    grid on; xlabel('bit rate (bits per pixel)');
    if strcmp(metric{1}, 'psnr'), ylabel('PSNR(I, I_c) (dB)'); else, ylabel('SSIM(I, I_c) (luma)'); end
    title(sprintf('Exp 1: %s vs bit rate, mean of %d underwater images', upper(metric{1}), numel(files)));
    legend(leg, 'Location', 'southeast');
    save_figure(f, fullfile(fdir, sprintf('exp01_%s_vs_bpp.png', metric{1})));
end
% compression ratio at matched quality (PSNR targets) and runtimes
if hasJxl
    tq = [30 32 34 36];
    crJ = zeros(size(tq)); crX = crJ;
    for i = 1:numel(tq)
        crJ(i) = cr_at_quality(srows, 'native', 'JPEG', tq(i));
        crX(i) = cr_at_quality(srows, 'native', 'JPEG XL', tq(i));
    end
    f = prepare_figure(700, 420);
    bar([crJ(:), crX(:)]); set(gca, 'XTickLabel', arrayfun(@(x) sprintf('%d dB', x), tq, 'UniformOutput', false));
    grid on; ylabel('compression ratio (raw bits / compressed bits)'); xlabel('PSNR(I, I_c) target (mean curve)');
    legend({'JPEG', 'JPEG XL'}, 'Location', 'northeast'); title('Exp 1: compression ratio at matched PSNR (native)');
    save_figure(f, fullfile(fdir, 'exp01_cr_matched_quality.png'));
    R.crMatched = [tq; crJ; crX];
end
f = prepare_figure(700, 420);
m1 = strcmp(srows(:, 1), 'native') & strcmp(srows(:, 2), 'JPEG');
m2 = strcmp(srows(:, 1), 'native') & strcmp(srows(:, 2), 'JPEG XL');
tt = [mean(cell2mat(srows(m1, 12))), mean(cell2mat(srows(m1, 13))); ...
      ternary(any(m2), mean(cell2mat(srows(m2, 12))), NaN), ternary(any(m2), mean(cell2mat(srows(m2, 13))), NaN)];
bar(1000 * tt); set(gca, 'XTickLabel', {'JPEG', 'JPEG XL'}); grid on;
ylabel('wall-clock time per 256x256 image (ms)'); legend({'encode', 'decode'}, 'Location', 'northwest');
title('Exp 1: codec runtime (host, incl. file I/O; JXL via external process)');
save_figure(f, fullfile(fdir, 'exp01_runtime.png'));
R.runtime_ms = 1000 * tt;
end

function out = interp_at(bpp, Q, targets)
% quality at target bit rates by linear interpolation in log(bpp); NaN outside range
[b, o] = sort(bpp); Q = Q(o, :);
out = NaN(1, numel(targets), 2);
for j = 1:2
    out(1, :, j) = interp1(log(b), Q(:, j), log(targets), 'linear', NaN);
end
end

function cr = cr_at_quality(srows, variant, codec, q)
m = strcmp(srows(:, 1), variant) & strcmp(srows(:, 2), codec);
p = cell2mat(srows(m, 8)); c = cell2mat(srows(m, 7));
[p, o] = sort(p); c = c(o);
cr = exp(interp1(p, log(c), q, 'linear', NaN));
end
