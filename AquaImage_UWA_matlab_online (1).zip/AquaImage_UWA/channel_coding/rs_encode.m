function cw = rs_encode(msg, t)
%RS_ENCODE Systematic (shortened) Reed-Solomon encoder over GF(256).
%   cw = RS_ENCODE(msg, t): msg = k bytes (k <= 255-2t), returns [msg; parity]
%   with 2t parity bytes. Generator g(x) = prod_{i=1..2t} (x - alpha^i)
%   (first consecutive root 1). RS(255,223) <-> t = 16. Shortening: the code
%   is RS(255,255-2t) with leading zeros that are not transmitted.
G = rs_gf();
msg = double(msg(:));
np = 2 * t;
if numel(msg) > 255 - np, error('rs_encode:len', 'Message too long for t = %d.', t); end
g = rs_generator(t);
par = zeros(1, np);                       % LFSR division remainder
for i = 1:numel(msg)
    fb = bitxor(msg(i), par(1));
    par = [par(2:end), 0];
    if fb ~= 0
        lf = G.log(fb + 1);
        for j = 1:np
            if g(j + 1) ~= 0
                par(j) = bitxor(par(j), G.exp(mod(lf + G.log(g(j + 1) + 1), 255) + 1));
            end
        end
    end
end
cw = uint8([msg; par(:)]);
end

function g = rs_generator(t)
persistent cache
if isempty(cache), cache = {}; end
if numel(cache) >= t && ~isempty(cache{t}), g = cache{t}; return; end
G = rs_gf();
g = 1;                                    % coefficients, highest degree first
for i = 1:2 * t
    r = G.exp(i + 1);                     % alpha^i
    ng = [g, 0];
    for j = 1:numel(g)
        if g(j) ~= 0
            ng(j + 1) = bitxor(ng(j + 1), G.exp(mod(G.log(g(j) + 1) + G.log(r + 1), 255) + 1));
        end
    end
    g = ng;
end
cache{t} = g;
end
