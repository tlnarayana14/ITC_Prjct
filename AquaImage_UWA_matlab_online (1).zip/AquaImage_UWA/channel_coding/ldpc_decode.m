function [uhat, info] = ldpc_decode(code, llr, maxIter, alpha)
%LDPC_DECODE Normalised min-sum belief-propagation decoder (flooding schedule).
%
%   [uhat, info] = LDPC_DECODE(code, llr, maxIter, alpha)
%     llr     : N x B channel LLRs, convention L = log(P(b=0)/P(b=1))
%               (positive -> bit 0). Clipped to +-50.
%     maxIter : iteration limit (early stop per codeword on zero syndrome)
%     alpha   : min-sum normalisation factor (0.75 default in config)
%   Returns uhat (K x B hard information bits) and info struct with
%     .iterations (1 x B), .converged (1 x B, syndrome == 0 at exit),
%     .cwHat (N x B hard codeword decisions).
%   Vectorised over codewords; converged columns are removed from the
%   active set so the cost tracks the hardest codeword.

[N, Bt] = size(llr);
if N ~= code.N
    error('ldpc_decode:size', 'LLR length %d ~= N=%d', N, code.N);
end
llr = max(min(llr, 50), -50);
E = code.E; M = code.M; dmax = code.dcmax;
CNi = code.CN(:);
valid = CNi <= E;
ec = code.edgeCol;
colIdx = reshape(1:dmax, 1, dmax);       % for argmin masks (1 x dmax)

cwHat = double(llr < 0);
iters = zeros(1, Bt);
conv = false(1, Bt);

synd0 = mod(code.H * cwHat, 2);
done0 = all(synd0 == 0, 1);
conv(done0) = true;
active = find(~done0);
Lch = llr(:, active);
C2V = zeros(E, numel(active));
Lpost = Lch;

for it = 1:maxIter
    if isempty(active), break; end
    nb = numel(active);
    V2C = Lpost(ec, :) - C2V;                       % E x nb
    V2Cp = [V2C; 1e30 * ones(1, nb)];               % dummy edge for padding
    X = reshape(V2Cp(CNi, :), M, dmax, nb);
    S = sign(X); S(S == 0) = 1;
    A = abs(X);
    [m1, i1] = min(A, [], 2);                       % M x 1 x nb
    isMin = (colIdx == i1);                         % implicit expansion -> M x dmax x nb
    A(isMin) = Inf;
    m2 = min(A, [], 2);
    Mag = m1 .* ~isMin + m2 .* isMin;               % exclude own edge
    sp = prod(S, 2);
    Out = alpha * (sp .* S) .* Mag;                 % extrinsic sign: product of others
    Out = reshape(Out, M * dmax, nb);
    C2V(CNi(valid), :) = Out(valid, :);
    Lpost = Lch + code.Avar * C2V;
    hard = double(Lpost < 0);
    synd = mod(code.H * hard, 2);
    ok = all(synd == 0, 1);
    iters(active) = it;
    cwHat(:, active) = hard;
    if any(ok)
        conv(active(ok)) = true;
        keep = ~ok;
        active = active(keep);
        Lch = Lch(:, keep); C2V = C2V(:, keep); Lpost = Lpost(:, keep);
    end
end
uhat = cwHat(1:code.K, :);
info = struct('iterations', iters, 'converged', conv, 'cwHat', cwHat);
end
