function R = exp11_roi_uep()
%EXP11_ROI_UEP Experiment 11: ROI-aware coding, unequal error protection and
%   image-quality-aware retransmission (Phase 18 items).
%
%   ROI: spectral-residual saliency box (ROI_DETECT). Two-layer coding:
%   base = whole image JPEG q15, ROI = crop JPEG q70. Reference: one JPEG of
%   the whole image whose quality q* gives (nearly) the same total bytes.
%   Schemes (multipath, OFDM/QPSK, no ARQ unless stated):
%     A single layer q*, LDPC R=2/3
%     B two-layer, EEP: both layers R=2/3
%     C two-layer, UEP: ROI R=1/2, base R=3/4
%     D as C + quality-aware ARQ: only the ROI layer is retransmitted (<= 3)
%     E two-layer, EEP at R=1/2 (same ROI protection as C, more coded bits)
%     F single layer q*, R=1/2
%   Coded bits differ between schemes; they are reported so that equal-budget
%   comparisons (C vs B, C vs E) can be made explicitly.
%   Per-point results are cached in results/cache (resumable).
%   Images euvp_01..08, SNR {4,5,6,7,8,10} dB, same seed per (SNR, image).
%   Displayed image: whatever was decoded; a layer that did not arrive is
%   shown as flat gray (no data is invented). Metrics vs the original I:
%   ROI-PSNR/SSIM (inside the box), full-image PSNR, ROI and full delivery,
%   coded bits and link occupation.
base = experiment_base();
base.codec.name = 'jpeg';
snrs = [4 5 6 7 8 10];
imgs = 1:8;
rows = {}; per = {};
for s = snrs
    for k = imgs
        r = load_image_record(fullfile(base.root, 'data', 'underwater_samples', sprintf('euvp_%02d.jpg', k)), k);
        I = r.pixels; bb = roi_detect(I, base);
        c = base; c.chan.snrDb = s;
        % reference single-layer quality matching the two-layer byte budget
        tmp = c; tmp.codec.jpegQuality = 15; nb = numel(source_encode(I, tmp).bytes);
        rr = bb(1):bb(1) + bb(3) - 1; cc = bb(2):bb(2) + bb(4) - 1;
        tmp.codec.jpegQuality = 70; nr = numel(source_encode(I(rr, cc, :), tmp).bytes);
        qStar = match_quality(I, c, nb + nr);
        schemes = {'A single q*, R2/3', 'B 2-layer EEP R2/3', 'C 2-layer UEP 1/2+3/4', 'D UEP + ROI-only ARQ', ...
            'E 2-layer EEP R1/2', 'F single q*, R1/2'};
        for m = 1:numel(schemes)
            cf = fullfile(base.out.resultsDir, 'cache', sprintf('exp11_s%d_k%d_m%d.mat', s, k, m));
            if exist(cf, 'file') == 2
                L = load(cf); rows(end + 1, :) = L.row; %#ok<AGROW>
                if s == 6 && k == 5 && isfield(L, 'Iout'), per{m} = L.Iout; end %#ok<AGROW>
                continue;
            end
            set_seed(base.seed + 11000 + 100 * s + k);
            fk = 0;
            switch m
                case {1, 6}
                    ca = c; ca.codec.jpegQuality = qStar; ca.fec.rate = ternary(m == 1, 2/3, 1/2); ca.arq.enabled = false;
                    enc = source_encode(I, ca);
                    [res, ~] = transmit_image(enc, k, ca, fec_setup(ca), fk);
                    Iout = uint8(128 * ones(size(I))); if res.success, Iout = res.Ir; end
                    roiOk = res.success; fullOk = res.success; coded = res.bits.coded;
                    occ = sum(res.segments(:, 2)); bytes = numel(enc.bytes); Iref = enc.Ic;
                otherwise
                    o = struct('qBase', 15, 'qRoi', 70, 'rBase', 2/3, 'rRoi', 2/3, 'arqBase', 0, 'arqRoi', 0);
                    if m == 3 || m == 4, o.rRoi = 1/2; o.rBase = 3/4; end
                    if m == 4, o.arqRoi = 3; end
                    if m == 5, o.rRoi = 1/2; o.rBase = 1/2; end
                    [out, ~] = transmit_roi_uep(I, bb, k, c, o, fk);
                    Iout = out.Iout; roiOk = out.roiOk; fullOk = out.baseOk && out.roiOk;
                    coded = out.coded; occ = out.airtime; bytes = out.bytes; Iref = out.Ic;
            end
            [pr, sr] = roi_metrics(I, Iout, bb);
            [prc, ~] = roi_metrics(I, Iref, bb);
            row = {schemes{m}, s, k, qStar, bytes, coded, occ, roiOk, fullOk, pr, sr, psnr_u8(I, Iout), prc};
            rows(end + 1, :) = row; %#ok<AGROW>
            if exist(fileparts(cf), 'dir') ~= 7, mkdir(fileparts(cf)); end
            save(cf, 'row', 'Iout', '-v7');
            if s == 6 && k == 5, per{m} = Iout; end %#ok<AGROW>
        end
    end
    fprintf('[exp11] SNR %d dB done\n', s);
end
hdr = {'scheme', 'snrDb', 'image', 'qStar', 'bytes', 'codedBits', 'linkOccupation_s', 'roiDelivered', 'fullDelivered', ...
    'roiPsnr', 'roiSsim', 'fullPsnr', 'roiPsnrErrorFree'};
td = fullfile(base.out.resultsDir, 'tables');
write_csv(fullfile(td, 'exp11_roi_uep_points.csv'), hdr, rows);
% summary per scheme and SNR
names = unique(rows(:, 1), 'stable');
S = {};
for m = 1:numel(names)
    for s = snrs
        x = rows(strcmp(rows(:, 1), names{m}) & cell2mat(rows(:, 2)) == s, :);
        S(end + 1, :) = {names{m}, s, mean(cell2mat(x(:, 8))), mean(cell2mat(x(:, 9))), mean(cell2mat(x(:, 10))), ...
            mean(cell2mat(x(:, 11))), mean(cell2mat(x(:, 12))), mean(cell2mat(x(:, 6))), mean(cell2mat(x(:, 7))), mean(cell2mat(x(:, 13)))}; %#ok<AGROW>
    end
end
write_csv(fullfile(td, 'exp11_roi_uep_summary.csv'), {'scheme', 'snrDb', 'roiDeliveryRate', 'fullDeliveryRate', 'roiPsnr', ...
    'roiSsim', 'fullPsnr', 'meanCodedBits', 'meanLinkOccupation_s', 'roiPsnrErrorFree'}, S);
fd = fullfile(base.out.resultsDir, 'figures');
f = prepare_figure(1100, 420);
for pnl = 1:2
    subplot(1, 2, pnl); hold on;
    for m = 1:numel(names)
        x = S(strcmp(S(:, 1), names{m}), :);
        col = [5 3]; plot(cell2mat(x(:, 2)), cell2mat(x(:, col(pnl))), 'o-', 'LineWidth', 1.4);
    end
    grid on; xlabel('in-band SNR (dB)');
    if pnl == 1, ylabel('mean ROI PSNR of the displayed image (dB)'); title('Exp 11: ROI quality');
    else, ylabel('ROI delivery rate'); title('Exp 11: ROI layer delivered'); end
    legend(names, 'Location', 'southeast');
end
save_figure(f, fullfile(fd, 'exp11_roi_quality.png'));
if numel(per) >= 4
    f = prepare_figure(1500, 330);
    for m = 1:numel(per)
        subplot(1, numel(per), m); image(per{m}); axis image off; title(sprintf('%s', names{m}));
    end
    save_figure(f, fullfile(fd, 'exp11_example_6dB.png'));
end
R.rows = rows; R.summary = S;
end

function q = match_quality(I, c, target)
best = Inf; q = 50;
for qq = 5:5:95
    c.codec.jpegQuality = qq;
    d = abs(numel(source_encode(I, c).bytes) - target);
    if d < best, best = d; q = qq; end
end
end
