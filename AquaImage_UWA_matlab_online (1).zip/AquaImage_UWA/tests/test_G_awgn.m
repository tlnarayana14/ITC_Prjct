function test_G_awgn()
%TEST_G_AWGN Uncoded QPSK BER vs SNR follows theory; SNR scaling is consistent.
%   SC PHY (fs = B): Es/N0 = SNR, theory Pb = Q(sqrt(Es/N0)) for Gray QPSK.
%   OFDM PHY: per used subcarrier Es/N0 = SNR*K/Nused; channel estimation
%   from noisy pilots costs a small additional loss, so a looser tolerance.
cfg = test_config();
cfg.chan.model = 'awgn';
set_seed(13);
b = randi([0 1], 2e5, 1);
snrs = [2 5 8];
Qf = @(x) 0.5 * erfc(x / sqrt(2));
for phy = {'sc', 'ofdm'}
    c = cfg; c.phy.type = phy{1};
    ber = zeros(size(snrs)); th = ber;
    p = ofdm_params(c);
    for i = 1:numel(snrs)
        c.chan.snrDb = snrs(i);
        tx = phy_tx(b, c);
        r = uwa_channel(tx, c);
        llr = phy_rx(r, tx.meta, c);
        ber(i) = mean(double(llr < 0) ~= b);
        esn0 = 10^(snrs(i) / 10);
        if strcmp(phy{1}, 'ofdm'), esn0 = esn0 * p.K / p.nUsed; end
        th(i) = Qf(sqrt(esn0));
        fprintf('    %s SNR %g dB: BER %.4e, theory %.4e (ratio %.2f)\n', phy{1}, snrs(i), ber(i), th(i), ber(i) / th(i));
    end
    check(all(diff(ber) < 0), '%s: BER decreases monotonically with SNR', phy{1});
    if strcmp(phy{1}, 'sc')
        check(all(abs(ber ./ th - 1) < 0.15), 'SC: measured BER within 15%% of Q(sqrt(SNR)) at every point');
    else
        check(all(ber ./ th > 0.8 & ber ./ th < 1.5), 'OFDM: BER within [0.8, 1.5] x ideal-CSI theory (pilot-based estimation loss)');
    end
end
end
