function tx = phy_ofdm_tx(bits, cfg)
%PHY_OFDM_TX CP-OFDM frame for the acoustic channel (complex baseband).
%
%   tx = PHY_OFDM_TX(bits, cfg)
%     bits : coded (and interleaved) bits of one frame
%   Frame layout (fs = osf*B):
%     [LFM chirp | guard | N_ofdm x (CP + OFDM symbol) | guard | LFM chirp | guard]
%   The second chirp (postamble) lets the receiver estimate the Doppler
%   time-scaling factor from the measured preamble-postamble distance.
%   Output tx: .x (column), .fs, .meta (everything the receiver needs to
%   know about the frame format: numbers of symbols/bits/padding, offsets),
%   .duration_s, .nDataSym (constellation symbols carrying bits).
p = ofdm_params(cfg);
if strcmpi(cfg.mod.scheme, 'analog')
    % Deep-JSCC mode: 'bits' already holds unit-power complex channel symbols
    sym = bits(:); nPad = 0;
else
    [sym, nPad] = mod_map(bits, cfg.mod.scheme);
end
nd = numel(p.dataIdx);
nOfdm = ceil(numel(sym) / nd);
nFill = nOfdm * nd - numel(sym);
% fill unused data cells with known QPSK symbols (not counted as payload)
fillSym = det_qpsk_seq(max(nFill, 1), 5);
sym = [sym; fillSym(1:nFill)];
S = reshape(sym, nd, nOfdm);
body = zeros(p.Nsym * nOfdm, 1);
for m = 1:nOfdm
    X = zeros(p.Nfft, 1);
    X(p.bin(p.dataIdx)) = S(:, m);
    X(p.bin(p.pilotIdx)) = p.pilotSym;
    xt = ifft(X) * p.scale;
    body((m - 1) * p.Nsym + (1:p.Nsym)) = [xt(end - p.Ncp + 1:end); xt];
end
g = zeros(p.Nguard, 1);
x = [p.chirp; g; body; g; p.chirp; g];
tx.x = x;
tx.fs = p.fs;
tx.duration_s = numel(x) / p.fs;
tx.nDataSym = numel(sym) - nFill;
tx.meta = struct('type', 'ofdm', 'nBits', numel(bits), 'nPad', nPad, 'nOfdm', nOfdm, ...
    'nFill', nFill, 'bodyStart', p.Nchirp + p.Nguard + 1, 'postStart', p.Nchirp + 2 * p.Nguard + numel(body) + 1, ...
    'len', numel(x));
tx.activeMask = abs(x) > 0;
end
