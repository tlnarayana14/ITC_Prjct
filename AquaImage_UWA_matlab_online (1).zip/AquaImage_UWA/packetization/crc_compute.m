function c = crc_compute(bytes, s)
%CRC_COMPUTE Table-driven CRC over a uint8 vector.
%   c = CRC_COMPUTE(bytes, spec) returns the CRC as uint32 (low 'width' bits).
%   spec comes from CRC_SPEC. The same function is used by transmitter and
%   receiver, guaranteeing an identical convention at both ends.
%   NOTE: a CRC only DETECTS errors; it never corrects them, and a corrupted
%   packet can (with probability ~2^-width for random errors) still pass.
bytes = uint32(bytes(:));
T = s.table;
crc = s.init;
if s.refin
    for k = 1:numel(bytes)
        crc = bitxor(T(bitand(bitxor(crc, bytes(k)), 255) + 1), bitshift(crc, -8));
    end
else
    sh = s.width - 8;
    for k = 1:numel(bytes)
        idx = bitand(bitxor(bitshift(crc, -sh), bytes(k)), 255);
        crc = bitand(bitxor(T(idx + 1), bitshift(crc, 8)), s.mask);
    end
end
c = bitand(bitxor(crc, s.xorout), s.mask);
end
