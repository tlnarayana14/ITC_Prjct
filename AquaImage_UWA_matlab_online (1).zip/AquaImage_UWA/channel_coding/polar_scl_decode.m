function [uhat, ok] = polar_scl_decode(pc, llr, Lmax, crcBits)
%POLAR_SCL_DECODE CRC-aided successive-cancellation LIST decoding (CA-SCL).
%
%   [uhat, ok] = POLAR_SCL_DECODE(pc, llr, Lmax, crcBits)
%     llr     : N x 1 channel LLRs of ONE codeword (L = log P0/P1)
%     Lmax    : list size (e.g. 8)
%     crcBits : number of CRC-16 bits at the end of the information vector
%               (0 = plain SCL, choose the best path metric)
%   Returns the K information bits of the selected path and ok = CRC passed.
%   Recursive formulation vectorised over the list: every node receives the
%   LLRs of all surviving paths (columns), recurses left, re-indexes the
%   right-child inputs by the surviving-path permutation, recurses right.
%   Path metric (LLR-domain, Balatsoukas-Stimming et al. 2015):
%     PM += ln(1 + exp(-(1 - 2u) L)) at every decided bit (frozen or not).
%   Reference algorithm: Tal & Vardy, "List decoding of polar codes", IEEE
%   Trans. IT 2015 (CRC-aided selection).
frozen = ~pc.info;
[u, ~, PM] = node(llr(:), frozen, 0, Lmax);
U = u(pc.info, :);                       % K x Lcur, sorted later by PM
[~, ord] = sort(PM, 'ascend');
ok = false; uhat = U(:, ord(1));
if crcBits > 0
    for j = ord(:).'
        if crc_bits_ok(U(:, j), crcBits)
            uhat = U(:, j); ok = true; return;
        end
    end
end
end

function [u, x, PM, perm] = node(Lm, frozen, PM, Lmax)
% Lm: n x Lc LLRs; returns u (n x Lc'), x (n x Lc'), new PM, and perm: for each
% surviving path, the index of the incoming path it descends from.
n = size(Lm, 1);
if n == 1
    Lc = size(Lm, 2);
    if frozen
        PM = PM + softpen(Lm, 0);                      % frozen bit decided 0, no fork
        u = zeros(1, Lc); x = u; perm = 1:Lc;
        return;
    end
    pm0 = PM + softpen(Lm, 0); pm1 = PM + softpen(Lm, 1);
    allpm = [pm0, pm1];
    [s, o] = sort(allpm, 'ascend');
    keep = o(1:min(Lmax, numel(o)));
    perm = mod(keep - 1, Lc) + 1;
    u = double(keep > Lc);
    x = u; PM = s(1:numel(keep));
    return;
end
h = n / 2;
La = Lm(1:h, :); Lb = Lm(h + 1:end, :);
Lf = sign(La) .* sign(Lb) .* min(abs(La), abs(Lb));
[u1, v1, PM, p1] = node(Lf, frozen(1:h), PM, Lmax);
Lg = Lb(:, p1) + (1 - 2 * v1) .* La(:, p1);
[u2, v2, PM, p2] = node(Lg, frozen(h + 1:end), PM, Lmax);
u = [u1(:, p2); u2];
x = [mod(v1(:, p2) + v2, 2); v2];
perm = p1(p2);
end

function p = softpen(L, b)
% ln(1 + exp(-(1-2b) L)), numerically stable
z = -(1 - 2 * b) * L;
p = max(z, 0) + log1p(exp(-abs(z)));
end

function ok = crc_bits_ok(bits, nc)
% CRC-16/CCITT-FALSE over the leading bits (multiple of 8), compared with
% the trailing nc = 16 bits.
data = bits(1:end - nc);
c = crc_compute(bits_to_bytes(data), crc_spec('CRC-16/CCITT-FALSE'));
ok = isequal(bits(end - nc + 1:end), double(bitand(bitshift(c, -(15:-1:0)), 1)).');
end
