function R = exp05b_amc()
%EXP05B_AMC Experiment 5b: adaptive modulation and coding with an improved,
%   variability-aware controller (follow-up to the Exp-5 negative result).
%
%   Step 1: 16QAM first-attempt PER vs SNR on the multipath channel for LDPC
%   R = 1/2 and 3/4 (ARQ <= 3, same images/settings as Exp 3) -> thresholds.
%   Step 2: same 5 SNR traces x 16 images as Exp 5 (paired), policies:
%     fixed QPSK R=1/2 | Exp-5 rule (v1) | v2 rate-only | v2 rate + modulation
%   v2 = AMC_CONTROLLER (pessimistic trend, margin 0.5 dB + 1.5 sigma).
%   Requires Exp 3 results (QPSK thresholds).
base = experiment_base();
td = fullfile(base.out.resultsDir, 'tables'); fd = fullfile(base.out.resultsDir, 'figures');
f16 = fullfile(td, 'exp05b_16qam_sweep.csv');
if exist(f16, 'file') ~= 2
    b = base; b.arq.enabled = true; b.arq.maxRetries = 3; b.mod.scheme = '16qam';
    v = struct('name', {}, 'apply', {});
    for Rc = [1/2 3/4]
        v(end + 1) = struct('name', sprintf('LDPC R=%s', rate_str(Rc)), 'apply', @(c) setfield(c, 'fec', setfield(c.fec, 'rate', Rc))); %#ok<AGROW,SFLD>
    end
    T16 = link_sweep(b, v, 8:2:22, 'exp05b');
    save_sweep(T16, f16);
    plot_sweep(T16, 'PER_initial', 'first-attempt PER', 'Exp 5b: 16QAM PER vs SNR (multipath)', fullfile(fd, 'exp05b_16qam_per.png'), true, 1e-4);
end
T16 = read_csv_struct(f16);
T3 = read_csv_struct(fullfile(td, 'exp03_snr_sweep_multipath_arq.csv'));
qr = [1/2 2/3 3/4 5/6]; thrQ = per_thresholds(T3, qr, 0.10);
thr16 = per_thresholds(T16, [1/2 3/4], 0.10);
modes = struct('scheme', {}, 'rate', {}, 'eff', {}); thr = [];
for i = 1:numel(qr), if ~isnan(thrQ(i)), modes(end + 1) = struct('scheme', 'qpsk', 'rate', qr(i), 'eff', 2 * qr(i)); thr(end + 1) = thrQ(i); end, end %#ok<AGROW>
for i = 1:2, if ~isnan(thr16(i)), modes(end + 1) = struct('scheme', '16qam', 'rate', 0.5 + 0.25 * (i - 1), 'eff', 4 * (0.5 + 0.25 * (i - 1))); thr(end + 1) = thr16(i); end, end %#ok<AGROW>
[~, o] = sort([modes.eff]); modes = modes(o); thr = thr(o);
write_csv(fullfile(td, 'exp05b_thresholds.csv'), {'modulation', 'rate', 'bitsPerSymbolTimesRate', 'estSnrThresholdDb_PER10'}, ...
    [{modes.scheme}', num2cell([modes.rate]'), num2cell([modes.eff]'), num2cell(thr(:))]);
opt = struct('m0', 0.5, 'kSigma', 1.5, 'sigma0', 2.0, 'allowModulation', false);
optM = opt; optM.allowModulation = true;
qOk = ~isnan(thrQ);
pol = struct('name', {'fixed QPSK R=1/2', 'Exp-5 rule (v1)', 'v2 rate-only', 'v2 rate+modulation'}, ...
    'ctrl', {@(s) struct('rate', 1/2), @(s) rate_controller(s, qr(qOk), thrQ(qOk), 1.0), ...
    @(s) wrap(s, modes, thr, opt), @(s) wrap(s, modes, thr, optM)});
b = base; b.arq.enabled = true; b.arq.maxRetries = 3; b.source.numImages = 16; b.source.interval_s = 30;
nP = numel(pol); acc = repmat(struct('deliv', false(1, 0), 'useful', 0, 'occ', 0, 'rate', [], 'qam', 0, 'n', 0), 1, nP);
for ts = 7:11
    trace = snr_trace(16, ts);
    for p = 1:nP
        set_seed(base.seed + 500 + ts);
        S = run_link_simulation(b, struct('tag', 'exp05b', 'saveArtifacts', false, 'snrTrace', trace, 'controller', pol(p).ctrl));
        P = S.perImage;
        acc(p).deliv = logical([acc(p).deliv, [P.success]]);
        acc(p).useful = acc(p).useful + S.summary.usefulBits;
        acc(p).occ = acc(p).occ + S.summary.airtime_s + S.summary.turnaround_s;
        acc(p).rate = [acc(p).rate, [P.rate]];
        acc(p).qam = acc(p).qam + nnz(strcmp({P.modScheme}, '16qam')); acc(p).n = acc(p).n + numel(P);
        fprintf('[exp05b] trace %d %-20s delivered %d/16\n', ts, pol(p).name, nnz([P.success]));
    end
end
rows = {}; pw = {};
for p = 1:nP
    k = nnz(acc(p).deliv); n = numel(acc(p).deliv); [lo, hi] = wilson_ci(k, n);
    rows(end + 1, :) = {pol(p).name, k, n, k / n, lo, hi, acc(p).useful / acc(p).occ, mean(acc(p).rate), acc(p).qam / acc(p).n}; %#ok<AGROW>
    if p > 1
        pw(end + 1, :) = {[pol(p).name ' vs fixed QPSK R=1/2'], nnz(acc(p).deliv & ~acc(1).deliv), nnz(~acc(p).deliv & acc(1).deliv)}; %#ok<AGROW>
    end
end
write_csv(fullfile(td, 'exp05b_amc.csv'), {'policy', 'delivered', 'images', 'deliveryRate', 'lo95', 'hi95', 'busyGoodput_bps', 'meanRate', 'fraction16QAM'}, rows);
write_csv(fullfile(td, 'exp05b_paired.csv'), {'comparison', 'onlyPolicyDelivered', 'onlyFixedDelivered'}, pw);
f = prepare_figure(860, 420);
bar([cell2mat(rows(:, 4)), cell2mat(rows(:, 7)) / 5000]); set(gca, 'XTickLabel', rows(:, 1)); grid on;
legend({'image delivery rate', 'goodput incl. turnarounds / 5000 bit/s'}, 'Location', 'northwest');
title('Exp 5b: adaptive modulation and coding, 5 traces x 16 images');
save_figure(f, fullfile(fd, 'exp05b_amc.png'));
R.rows = rows; R.paired = pw;
end

function dec = wrap(s, modes, thr, opt)
[dec, ~] = amc_controller(s, modes, thr, opt);
end
