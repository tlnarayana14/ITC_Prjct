function plot_sweep(T, field, ylab, ttl, fname, logy, floorVal)
%PLOT_SWEEP Plot one metric of a LINK_SWEEP result versus SNR, one line per variant.
%   Values of exactly 0 on a log axis are drawn at floorVal (marked in the
%   legend title) so that error-free points remain visible; this is noted in
%   the axis label rather than hidden.
if nargin < 6, logy = false; end
if nargin < 7, floorVal = []; end
names = unique({T.variant}, 'stable');
f = prepare_figure(780, 500); hold on;
st = {'o-', 's-', '^-', 'd-', 'v-', 'x-', '*-', '+-'};
for k = 1:numel(names)
    m = strcmp({T.variant}, names{k});
    x = [T(m).snrDb]; y = [T(m).(field)];
    if logy && ~isempty(floorVal)
        y(y == 0) = floorVal;
    end
    plot(x, y, st{mod(k - 1, numel(st)) + 1}, 'LineWidth', 1.5);
end
if logy, set(gca, 'YScale', 'log'); end
grid on; xlabel('in-band SNR at receiver (dB)');
if logy && ~isempty(floorVal)
    ylab = sprintf('%s  (0 plotted at %.0e)', ylab, floorVal);
end
ylabel(ylab); title(ttl);
legend(names, 'Location', 'best');
save_figure(f, fname);
end
