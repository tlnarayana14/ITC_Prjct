function s = crc_spec(name)
%CRC_SPEC Parameters and lookup table of a supported CRC (Rocksoft model).
%
%   s = CRC_SPEC(name)
%   'CRC-32'             width 32, poly 0x04C11DB7, init 0xFFFFFFFF,
%                        refin = refout = true, xorout 0xFFFFFFFF,
%                        check("123456789") = 0xCBF43926 (IEEE 802.3 / zlib)
%   'CRC-16/CCITT-FALSE' width 16, poly 0x1021, init 0xFFFF, refin = refout =
%                        false, xorout 0x0000, check = 0x29B1
%
%   Fields: name, width, poly, init, refin, refout, xorout, check, table
%   (uint32 256x1). The CRC value is serialized MSB-first (big-endian) after
%   the protected bytes; see packetize.m.
persistent cache
if isempty(cache), cache = struct('key', {}, 'spec', {}); end
for k = 1:numel(cache)
    if strcmpi(cache(k).key, name), s = cache(k).spec; return; end
end
switch upper(name)
    case 'CRC-32'
        s = struct('name', 'CRC-32', 'width', 32, 'poly', uint32(hex2dec('04C11DB7')), ...
            'init', uint32(hex2dec('FFFFFFFF')), 'refin', true, 'refout', true, ...
            'xorout', uint32(hex2dec('FFFFFFFF')), 'check', uint32(hex2dec('CBF43926')));
    case 'CRC-16/CCITT-FALSE'
        s = struct('name', 'CRC-16/CCITT-FALSE', 'width', 16, 'poly', uint32(hex2dec('1021')), ...
            'init', uint32(hex2dec('FFFF')), 'refin', false, 'refout', false, ...
            'xorout', uint32(0), 'check', uint32(hex2dec('29B1')));
    otherwise
        error('crc_spec:unknown', 'Unsupported CRC "%s" (use CRC-32 or CRC-16/CCITT-FALSE).', name);
end
w = s.width;
mask = uint32(2^w - 1);
T = zeros(256, 1, 'uint32');
if s.refin
    rp = reflect_bits(s.poly, w);
    for i = 0:255
        c = uint32(i);
        for b = 1:8
            if bitand(c, 1)
                c = bitxor(bitshift(c, -1), rp);
            else
                c = bitshift(c, -1);
            end
        end
        T(i + 1) = c;
    end
else
    top = uint32(2^(w - 1));
    for i = 0:255
        c = bitshift(uint32(i), w - 8);
        for b = 1:8
            if bitand(c, top)
                c = bitand(bitxor(bitshift(c, 1), s.poly), mask);
            else
                c = bitand(bitshift(c, 1), mask);
            end
        end
        T(i + 1) = c;
    end
end
s.table = T;
s.mask = mask;
cache(end + 1).key = name;
cache(end).spec = s;
end

function r = reflect_bits(v, w)
r = uint32(0);
for k = 0:w - 1
    if bitand(v, bitshift(uint32(1), k))
        r = bitor(r, bitshift(uint32(1), w - 1 - k));
    end
end
end
