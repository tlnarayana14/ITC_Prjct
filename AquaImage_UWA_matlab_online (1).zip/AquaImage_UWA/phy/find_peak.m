function [pos, val] = find_peak(c, lo, hi)
%FIND_PEAK Largest |c| in samples lo..hi (1-based) with parabolic refinement.
%   pos is fractional (1-based sample index), val the peak magnitude.
lo = max(1, round(lo)); hi = min(numel(c), round(hi));
if hi < lo
    pos = NaN; val = 0; return;
end
a = abs(c(lo:hi));
[val, k] = max(a);
pos = lo + k - 1;
if k > 1 && k < numel(a)
    den = a(k - 1) - 2 * a(k) + a(k + 1);
    if den ~= 0
        pos = pos + 0.5 * (a(k - 1) - a(k + 1)) / den;
    end
end
end
