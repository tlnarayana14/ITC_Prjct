# Which run produced which result

All final tables/figures come from the final code (receiver with profile-based
Doppler estimation, +-3 subcarrier CFO search and the sync edge-case fix).

| Experiment | Final run | Superseded logs (kept for transparency) |
|---|---|---|
| 1 | standalone run, 76 s (before the runtime logger existed); codec-only, unaffected by receiver changes | — |
| 2, 4, 6, 8 | chainA/chainB_console.txt | an earlier Exp 2/4 run with the old receiver was deleted and rerun |
| 3, 7 | chainB_console.txt | — |
| 5 | exp05_rerun_console.txt (5 traces x 16 images) | single-trace result in chainB_console.txt |
| 9 | exp09_rerun_console.txt (runs A, B, C) | first run (A, B only) in chainA_console.txt |
| 10 | exp10_partA/partB + final aggregation (5 traces, cache) | exp10_rerun_console.txt crashed at aggregation (logical-index bug, fixed); single-trace result in chainB_console.txt |
| main.m | main_summary.json / main_per_image.csv (rerun after final receiver) | — |
| tests | tests_final_console.txt, test_report.txt: 15/15 PASS | — |

## Second iteration (added experiments and features)

| Item | Final run |
|---|---|
| Deep JSCC training | `djscc_train.txt` (3000 steps, ~93 min on 2 shared cores) -> `tools/deepjscc/djscc_uwa.pt` |
| Exp 11 (ROI/UEP) | `exp11_console.txt` (schemes A-D) + `exp11b_console.txt` (E, F added; A-D reused from cache, (6 dB, image 5) recomputed for the example figure) |
| Exp 12 (Deep JSCC) | `exp12a/b_console.txt` (one channel per process, cached), aggregated afterwards |
| Exp 13 (codes, fountain) | `exp13_console.txt` |
| Exp 5b (AMC) | `exp05b_console.txt` |
| tests | `tests_final_console.txt`, `test_report.txt`: 19/19 PASS |

## MATLAB Online verification (user run, 2026-10-15)

18/19 test groups passed in MATLAB Online on first run (JPEG XL and Python
cross-checks skipped: tools not available there). Fixes made after that run:
1. Test O failure -> real bug: fountain coefficient generator (linearly seeded
   LCG) gave correlated rows for some K. Replaced by a hashed xorshift32
   generator; Test O now checks K = 10..60. Exp 13 Part B re-run
   (`exp13B_rerun_console.txt`).
2. `OCTAVE_VERSION` referenced in MATLAB -> `common/platform_str.m`.
3. `print` failed on a zero-size invisible figure in MATLAB Online ->
   `common/save_figure.m` sets the size explicitly and falls back to
   `exportgraphics`.
