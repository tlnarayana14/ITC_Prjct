function f = prepare_figure(w, h)
%PREPARE_FIGURE Create an invisible figure; selects a headless toolkit in Octave.
if nargin < 1, w = 800; end
if nargin < 2, h = 500; end
if is_octave()
    tk = available_graphics_toolkits();
    if isempty(getenv('DISPLAY')) && any(strcmp(tk, 'gnuplot'))
        ws = warning('off', 'all');
        graphics_toolkit('gnuplot');
        warning(ws);
    end
end
f = figure('Visible', 'off', 'Position', [100 100 w h]);
end
