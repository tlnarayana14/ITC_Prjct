function test_X_crossval()
%TEST_X_CROSSVAL Cross-validate PSNR/SSIM and the JPEG XL path against
%   independent Python implementations (scikit-image, imagecodecs/libjxl).
%   Skipped (with a message) when python3/scikit-image are unavailable.
cfg = test_config();
py = fullfile(cfg.root, 'tools', 'crosscheck_metrics.py');
[st, ~] = system('python3 -c "import skimage, PIL"');
if st ~= 0
    fprintf('    SKIP: python3 + scikit-image not available\n');
    return;
end
tmp = cfg.codec.tmpDir;
r = load_image_record(fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_09.jpg'), 0);
I = r.pixels;
for q = [20 60 90]
    c = cfg; c.codec.jpegQuality = q;
    e = source_encode(I, c);
    fa = fullfile(tmp, 'xa.png'); fb = fullfile(tmp, 'xb.png');
    imwrite(I, fa); imwrite(e.Ic, fb);
    [~, out] = system(sprintf('python3 "%s" metrics "%s" "%s"', py, fa, fb));
    v = sscanf(out, '%f');
    pm = psnr_u8(I, e.Ic); sm = ssim_luma(I, e.Ic);
    check(abs(pm - v(1)) < 1e-6 && abs(sm - v(2)) < 1e-6, 'JPEG q%d: PSNR %.6f vs skimage %.6f, SSIM %.6f vs skimage %.6f', q, pm, v(1), sm, v(2));
end
if codec_available('jpegxl', cfg)
    c = cfg; c.codec.name = 'jpegxl'; c.codec.jxlDistance = 1.5;
    e = source_encode(I, c);
    fj = fullfile(tmp, 'x.jxl'); fr = fullfile(tmp, 'xr.png');
    write_bytes(fj, e.bytes); imwrite(e.Ic, fr);
    [st, out] = system(sprintf('python3 "%s" jxl "%s" "%s"', py, fj, fr));
    if st == 0
        v = sscanf(out, '%f');
        % Lossy JPEG XL decoding is specified up to a conformance tolerance;
        % libjxl 0.7 (djxl) and 0.12 (imagecodecs) round differently by 1 LSB.
        check(v(1) <= 1, 'JPEG XL stream (cjxl 0.7) decoded by an independent libjxl 0.12: max |diff| = %d LSB vs djxl (%.1f%% of samples differ)', v(1), 100 * v(2));
    else
        fprintf('    SKIP: imagecodecs JPEG XL decoder unavailable (%s)\n', strtrim(out));
    end
end
end
