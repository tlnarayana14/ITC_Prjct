function enc = source_encode(img, cfg)
%SOURCE_ENCODE Common source-coding interface (Phase 2/3).
%
%   enc = SOURCE_ENCODE(img, cfg)
%     img : uint8 H x W x C working image (C = 1 or 3)
%     cfg.codec.name : 'jpeg' | 'jpegxl' | 'png' | 'learned'
%   Returns struct enc:
%     .codec, .codecId     codec name and 8-bit header id
%     .params              text description of encoder settings
%     .bytes               uint8 column: the EXACT compressed file produced
%                          by the real encoder (this is what is transmitted)
%     .width,.height,.channels
%     .rawBits             uncompressed size = H*W*C*8 bits
%     .compBits            numel(bytes)*8
%     .CR                  rawBits / compBits   (same unit: bits)
%     .bpp                 compBits / (H*W)     (bits per pixel)
%     .encTime_s           wall-clock encoder time (includes file I/O)
%     .Ic                  locally decoded image (reference for channel distortion)
%     .decTime_s           wall-clock local decode time
%     .lossless            true if the codec setting is mathematically lossless
%     .streamCrc32         CRC-32 of the whole compressed stream (integrity record)
%
%   Encoders used: imwrite (JPEG baseline via libjpeg in MATLAB, via
%   GraphicsMagick/libjpeg in Octave), imwrite PNG (lossless), libjxl
%   cjxl/djxl (JPEG XL reference implementation), tools/learned_codec.py.

if ~isa(img, 'uint8')
    error('source_encode:class', 'img must be uint8.');
end
name = lower(cfg.codec.name);
tmp = cfg.codec.tmpDir;
if exist(tmp, 'dir') ~= 7, mkdir(tmp); end
base = tempname(tmp);

enc.codec = name;
enc.codecId = codec_id(name);
enc.width = size(img, 2);
enc.height = size(img, 1);
enc.channels = size(img, 3);
enc.lossless = false;

t0 = tic;
switch name
    case 'jpeg'
        f = [base '.jpg'];
        imwrite(img, f, 'Quality', cfg.codec.jpegQuality);
        enc.params = sprintf('JPEG baseline, Quality=%d', cfg.codec.jpegQuality);
    case 'png'
        f = [base '.png'];
        imwrite(img, f);
        enc.params = 'PNG (lossless)';
        enc.lossless = true;
    case 'jpegxl'
        fin = [base '_in.png'];
        f = [base '.jxl'];
        imwrite(img, fin);
        t0 = tic;   % time the encoder itself, not the PNG staging write
        cmd = sprintf('"%s" "%s" "%s" -d %g -e %d --quiet 2>&1', cfg.codec.cjxl, fin, f, ...
            cfg.codec.jxlDistance, cfg.codec.jxlEffort);
        [st, out] = system(cmd);
        if st ~= 0
            error('source_encode:cjxl', 'cjxl failed (%d): %s', st, out);
        end
        delete(fin);
        enc.params = sprintf('JPEG XL (libjxl cjxl), distance=%g, effort=%d', cfg.codec.jxlDistance, cfg.codec.jxlEffort);
        enc.lossless = (cfg.codec.jxlDistance == 0);
    case 'learned'
        fin = [base '_in.png'];
        f = [base '.lic'];
        imwrite(img, fin);
        t0 = tic;
        script = fullfile(cfg.root, 'tools', 'learned_codec.py');
        cmd = sprintf('%s "%s" encode "%s" "%s" --model %s --quality %d', cfg.codec.python, script, ...
            fin, f, cfg.codec.learnedModel, cfg.codec.learnedQuality);
        [st, out] = system(cmd);
        if st ~= 0
            error('source_encode:learned', 'learned codec failed (%d): %s', st, out);
        end
        delete(fin);
        enc.params = sprintf('Learned (%s, q=%d)', cfg.codec.learnedModel, cfg.codec.learnedQuality);
    otherwise
        error('source_encode:codec', 'Unknown codec %s', name);
end
enc.encTime_s = toc(t0);
enc.bytes = read_bytes(f);
delete(f);

enc.rawBits  = enc.width * enc.height * enc.channels * 8;
enc.compBits = numel(enc.bytes) * 8;
enc.CR       = enc.rawBits / enc.compBits;
enc.bpp      = enc.compBits / (enc.width * enc.height);
% whole-stream integrity record (Phase 3): CRC-32 of the exact compressed file.
% In a deployed system this 4-byte value travels in the image descriptor
% (e.g. the first packet's header extension); here it is metadata that the
% receiver checks after reassembly (res.streamCrcOk).
enc.streamCrc32 = crc_compute(enc.bytes, crc_spec('CRC-32'));

% Local decode = reference I_c for separating source and channel distortion.
[enc.Ic, ok, msg, enc.decTime_s] = source_decode(enc.bytes, name, cfg);
if ~ok
    error('source_encode:localdecode', 'Local decode of fresh bitstream failed: %s', msg);
end
if enc.lossless && ~isequal(enc.Ic, img)
    error('source_encode:lossless', 'Codec flagged lossless but decoded pixels differ from input.');
end
end
