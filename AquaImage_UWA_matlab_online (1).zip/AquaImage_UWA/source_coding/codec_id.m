function out = codec_id(in)
%CODEC_ID Map codec name <-> 8-bit identifier carried in every packet header.
%   id = CODEC_ID('jpeg') -> 1 ;  name = CODEC_ID(2) -> 'jpegxl'
names = {'jpeg', 'jpegxl', 'png', 'learned'};
if ischar(in)
    out = find(strcmpi(names, in));
    if isempty(out)
        error('codec_id:unknown', 'Unknown codec %s', in);
    end
else
    if in < 1 || in > numel(names)
        error('codec_id:unknown', 'Unknown codec id %d', in);
    end
    out = names{in};
end
end
