function save_figure(f, fname)
%SAVE_FIGURE Save a figure as PNG (150 dpi) and close it.
[d, ~] = fileparts(fname);
if ~isempty(d) && exist(d, 'dir') ~= 7, mkdir(d); end
print(f, fname, '-dpng', '-r150');
close(f);
end
