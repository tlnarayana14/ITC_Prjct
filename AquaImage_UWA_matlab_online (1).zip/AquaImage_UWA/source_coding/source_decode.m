function [img, ok, msg, t] = source_decode(bytes, codecName, cfg)
%SOURCE_DECODE Decode a compressed byte stream with the matching real decoder.
%
%   [img, ok, msg, t] = SOURCE_DECODE(bytes, codecName, cfg)
%     bytes     : uint8 vector (complete compressed file)
%     codecName : 'jpeg' | 'jpegxl' | 'png' | 'learned'
%   Returns the uint8 image, ok=false (and msg) if the decoder rejects the
%   stream, and the decoder wall-clock time t (s). Never throws on a corrupt
%   stream: the caller decides how to report it. Must only be called on a
%   stream whose packets passed CRC (see link/receive_image.m).

img = []; ok = false; msg = ''; t = NaN;
name = lower(codecName);
tmp = cfg.codec.tmpDir;
if exist(tmp, 'dir') ~= 7, mkdir(tmp); end
base = tempname(tmp);
switch name
    case 'jpeg',    f = [base '.jpg'];
    case 'png',     f = [base '.png'];
    case 'jpegxl',  f = [base '.jxl'];
    case 'learned', f = [base '.lic'];
    otherwise
        msg = sprintf('unknown codec %s', name);
        return;
end
write_bytes(f, bytes);
t0 = tic;
try
    switch name
        case {'jpeg', 'png'}
            img = imread(f);
        case 'jpegxl'
            fo = [base '_out.png'];
            [st, out] = system(sprintf('"%s" "%s" "%s" --quiet 2>&1', cfg.codec.djxl, f, fo));
            if st ~= 0
                error('djxl failed: %s', out);
            end
            img = imread(fo);
            delete(fo);
        case 'learned'
            fo = [base '_out.png'];
            script = fullfile(cfg.root, 'tools', 'learned_codec.py');
            [st, out] = system(sprintf('%s "%s" decode "%s" "%s"', cfg.codec.python, script, f, fo));
            if st ~= 0
                error('learned decode failed: %s', out);
            end
            img = imread(fo);
            delete(fo);
    end
    t = toc(t0);
    if isa(img, 'uint16')
        img = uint8(round(double(img) / 257));
    end
    if ~isa(img, 'uint8')
        error('decoder returned class %s', class(img));
    end
    ok = true;
catch err
    t = toc(t0);
    msg = err.message;
    img = [];
end
if exist(f, 'file') == 2, delete(f); end
end
