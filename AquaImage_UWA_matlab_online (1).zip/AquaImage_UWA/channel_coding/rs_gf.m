function G = rs_gf()
%RS_GF GF(256) tables for Reed-Solomon (primitive polynomial x^8+x^4+x^3+x^2+1, 0x11D).
%   G.exp(i+1) = alpha^i for i = 0..509 (doubled to avoid modulo),
%   G.log(v+1) = log_alpha(v) for v = 1..255 (G.log(1) unused).
persistent T
if ~isempty(T), G = T; return; end
ex = zeros(1, 510); lg = zeros(1, 256);
x = 1;
for i = 0:254
    ex(i + 1) = x; lg(x + 1) = i;
    x = x * 2;
    if x >= 256, x = bitxor(x, 285); end
end
ex(256:510) = ex(1:255);
T = struct('exp', ex, 'log', lg);
G = T;
end
