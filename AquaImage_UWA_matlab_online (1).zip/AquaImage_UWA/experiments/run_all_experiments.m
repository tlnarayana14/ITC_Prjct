function run_all_experiments(which)
%RUN_ALL_EXPERIMENTS Run Experiments 1-10 (or a subset) and log timings.
%   RUN_ALL_EXPERIMENTS()          all, in dependency order
%   RUN_ALL_EXPERIMENTS([2 6 8])   a subset
%   Indices 11-14 = Exp 11 (ROI/UEP), Exp 12 (Deep JSCC; train the model first:
%   python3 tools/deepjscc/train.py <root> 3000), Exp 13 (codes, fountain), Exp 5b (AMC).
%   Dependencies: Exp 5/5b need Exp 3; Exp 10 needs Exp 3 and Exp 7.
%   Measured runtimes (GNU Octave 8.4, 2-core container, two experiments in
%   parallel): Exp1 76 s, Exp2 1028 s, Exp3 863 s, Exp4 551 s, Exp5 936 s
%   (5 traces), Exp6 259 s, Exp7 926 s, Exp8 82 s, Exp9 225 s, Exp10 ~45 min
%   (5 traces; runs are cached in results/cache and resumable). Second iteration:
%   Exp11 ~45 min, Exp12 ~17 min (2 processes), Exp13 28 min, Exp5b ~50 min,
%   Deep JSCC training ~90 min on 2 shared CPU cores.
root = setup_paths();
if nargin < 1, which = 1:14; end
fns = {@exp01_codec_comparison, @exp02_channel_coding, @exp03_snr_sweep, @exp04_channel_models, ...
    @exp05_adaptive_ldpc, @exp06_retransmission, @exp07_source_channel_tradeoff, @exp08_queue_stability, ...
    @exp09_end_to_end, @exp10_jscc_adaptation, @exp11_roi_uep, @exp12_deep_jscc, @exp13_codes_recovery, @exp05b_amc};
logf = fullfile(root, 'results', 'logs', 'experiment_runtimes.txt');
for k = which
    t0 = tic;
    fprintf('\n######## Experiment %d ########\n', k);
    fns{k}();
    fid = fopen(logf, 'a');
    fprintf(fid, '%s  exp%02d  %.1f s  (%s)\n', datestr(now), k, toc(t0), platform_str());
    fclose(fid);
end
end
