function test_L_error_injection()
%TEST_L_ERROR_INJECTION Known injected errors must be reflected consistently in
%   BER_post, CRC outcome, PER, erasures and the reconstruction outcome.
cfg = test_config();
cfg.chan.model = 'ideal';
cfg.arq.enabled = false;
cfg.debug.inject = struct('round', {1, 1}, 'seq', {0, 6}, 'nFlips', {4, 9});
set_seed(17);
S = run_link_simulation(cfg, struct('tag', 'test_L', 'saveArtifacts', false));
e = S.perImage(1); s = S.summary;
check(e.postErr == 13, 'BER_post numerator equals the 13 injected bit flips (%d)', e.postErr);
check(e.preErr == 0, 'BER_pre = 0 (errors were injected after decoding, not by the channel)');
check(e.firstFail == 2 && abs(s.PER_initial - 2 / e.nPkts) < 1e-12, 'CRC rejects exactly the 2 corrupted packets: PER = 2/%d', e.nPkts);
check(e.undetected == 0, 'no corrupted packet passed CRC');
check(e.e2eErased == 8 * 200 * 2 && e.e2eErr == 0, 'E2E: 3200 payload bits erased, 0 errors in delivered bits');
check(~e.complete && ~e.success && isnan(e.psnr_I_Ir), 'image reported incomplete, not decoded, no PSNR claimed');
check(abs(s.BER_E2E_total - 3200 / e.e2eN) < 1e-12, 'BER_E2E_total = erased / total payload bits = %.4f', s.BER_E2E_total);
end
