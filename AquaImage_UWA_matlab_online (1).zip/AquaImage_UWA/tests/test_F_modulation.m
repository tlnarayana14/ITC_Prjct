function test_F_modulation()
%TEST_F_MODULATION Mapping/demapping and full PHY recovery on an ideal channel.
cfg = test_config();
set_seed(12);
for sc = {'bpsk', 'qpsk', '16qam'}
    [pts, ~, m] = mod_constellation(sc{1});
    check(abs(mean(abs(pts).^2) - 1) < 1e-12, '%s constellation has unit average energy', sc{1});
    b = randi([0 1], 6000, 1);
    [s, np] = mod_map(b, sc{1});
    llr = mod_demap(s, 0.01, sc{1});
    check(isequal(double(llr(1:numel(b)) < 0), b) && np == mod(-6000, m), '%s noiseless map/demap exact', sc{1});
end
% QPSK max-log LLR equals the exact closed form 2*sqrt(2)*Re(y)/N0
y = [0.3 - 0.8j; -1.2 + 0.1j]; N0 = 0.37;
L = mod_demap(y, N0, 'qpsk');
ex = reshape([2 * sqrt(2) * real(y).'; 2 * sqrt(2) * imag(y).'] / N0, [], 1);
check(max(abs(L - ex)) < 1e-12, 'QPSK LLR sign/scale convention: L = 2*sqrt(2)*Re(y)/N0 (positive -> bit 0)');
% complete PHY on the ideal channel (sync, Doppler/CFO estimation, channel estimation)
b = randi([0 1], 30000, 1);
for phy = {'sc', 'ofdm'}
    c = cfg; c.phy.type = phy{1}; c.chan.model = 'ideal';
    tx = phy_tx(b, c);
    r = uwa_channel(tx, c);
    [llr, d] = phy_rx(r, tx.meta, c);
    check(isequal(double(llr < 0), b), '%s PHY: 30000 bits recovered exactly on the ideal channel (random start offset, est. SNR %.0f dB)', phy{1}, d.snrEstDb);
    c.phy.startOffsetMax_s = 0;                         % frame starts at the first sample
    tx = phy_tx(b, c); r = uwa_channel(tx, c);
    llr = phy_rx(r, tx.meta, c);
    check(isequal(double(llr < 0), b), '%s PHY: exact recovery when the frame starts at sample 1 (sync edge case)', phy{1});
end
end
