# AquaImage_UWA — end-to-end underwater acoustic still-image transmission simulator

A modular MATLAB-language simulator that moves **real compressed underwater
images** through a complete acoustic link and back:

```
camera schedule → load/preprocess → JPEG / JPEG XL / PNG encoder (real codecs)
→ exact compressed bytes → packets (10-byte header + CRC-32)
→ QC-LDPC or polar encoding (with shortening) → interleaver → Gray QPSK
→ CP-OFDM acoustic frame (or single-carrier baseline)
→ channel: AWGN | image-method multipath | + wideband Doppler | + Rician fading
→ LFM sync → Doppler-scale resampling → CFO search → sparse LS channel estimate
→ equalisation → soft demapping → deinterleaver → LDPC/polar decoding
→ CRC check → selective-repeat ARQ → reassembly → real decoder
→ I / I_c / I_r comparison → BER, PER, PSNR, SSIM, goodput, delay, queue
```

> **Execution status.** The code is written in the MATLAB/GNU Octave common
> subset and **was executed and tested with GNU Octave 8.4.0** (Ubuntu 24.04).
> It has **not been run in MATLAB** in this project — MATLAB was not available.
> No toolbox is used, so it is expected to run in MATLAB R2019b+, but treat
> MATLAB execution as untested until you run `run_all_tests` there. All numbers
> in `results/` and `docs/TECHNICAL_REPORT.md` come from the Octave runs.

## Requirements

| Item | Needed for | Notes |
|---|---|---|
| MATLAB R2019b+ **or** GNU Octave ≥ 7 | everything | tested: Octave 8.4.0; no toolboxes / Octave packages required |
| libjxl command-line tools `cjxl`, `djxl` | JPEG XL codec | tested: libjxl 0.7.0 (`apt install libjxl-tools`); set `cfg.codec.cjxl/djxl` to full paths if not on PATH |
| Python 3 + numpy, Pillow, scikit-image, imagecodecs, tifffile | optional cross-checks, format-test generator | `tools/crosscheck_metrics.py`, `tools/make_format_test.py` |
| torch (CPU is enough), Pillow, scikit-image | Deep JSCC training/evaluation (Exp 12) | tested: torch 2.14.1 CPU; `python3 tools/deepjscc/train.py . 3000` (~90 min on 2 shared cores) |
| compressai + pretrained weights | optional pretrained learned codec | **not executed here** (weights unreachable from the sandbox) — `tools/learned_codec.py` |
| Octave only: `gnuplot`, `ghostscript`, `fonts-freefont-otf` | headless figure export | Octave 8.4 expects `/usr/share/fonts/opentype/freefont/FreeSans.otf` |

## Quick start

```matlab
cd AquaImage_UWA
main                      % 3 images, JPEG q50, LDPC 1/2, OFDM, multipath @ 8 dB
setup_paths; run_all_tests          % 19 test groups -> results/logs/test_report.txt
setup_paths; run_all_experiments    % Experiments 1-13 + 5b (several hours on 2 cores; cached and resumable)
```

From a shell with Octave: `octave --no-gui --eval "main"`.

Change the scenario in the override block at the top of `main.m`, or start
from `default_config()` (every assumption is documented there) and call
`run_link_simulation(cfg)`. `validate_config` checks the configuration and the
codec dependencies before a long run and fails with a specific message.

## Project layout

| Folder | Contents |
|---|---|
| `config/` | `default_config.m` (all assumptions, SI units), `validate_config.m` |
| `source/` | multi-format loader with metadata, preprocessing, camera schedule |
| `source_coding/` | common codec interface `source_encode` / `source_decode` (JPEG, JPEG XL, PNG, learned) |
| `packetization/` | `packetize`, `parse_packet`, `reassemble_packets`, CRC (`crc_spec`, `crc_compute`) |
| `channel_coding/` | QC-LDPC build/encode/decode, polar construct/encode/SC decode, `fec_encode/decode` framing, interleaver |
| `modulation/` | Gray BPSK/QPSK/16QAM mapper and max-log demapper |
| `phy/` | CP-OFDM and single-carrier transmitters/receivers, sync helpers |
| `channel/` | `uwa_channel` (models A–D), image-method multipath geometry, Thorp absorption |
| `link/` | `transmit_frame`, `transmit_image` (ARQ), `simulate_queue`, `run_link_simulation` |
| `adaptation/` | rule-based rate controller, PER thresholds, JSCC utility/controller |
| `metrics/` | PSNR, SSIM (luma), three-way comparison, run summary, Wilson CI, BD-rate, plots |
| `experiments/` | Experiments 1–10 and helpers |
| `tests/` | test suite P1, A–M, X (`run_all_tests`) |
| `tools/` | Python helpers (format-test generator, cross-checks, learned-codec adapter), `tools/deepjscc/` (Deep JSCC model, training, CLI), `make_replay_example.m` |
| `data/underwater_samples/` | 23 real underwater images (EUVP samples, 256×256 JPEG) |
| `data/format_test/` | the same imagery as PNG/BMP/TIFF/16-bit TIFF/grayscale/non-square |
| `results/` | `tables/` (CSV), `figures/` (PNG), `reconstructed_images/`, `logs/` |
| `docs/` | `TECHNICAL_REPORT.md`, `LITERATURE_REVIEW.md`, `PROJECT_STATUS.md` |

## Data

`data/underwater_samples/euvp_XX.jpg` are the 23 test images shipped in the
FUnIE-GAN repository (`data/test/A`, Islam, Xia & Sattar, IEEE RA-L 2020), a
sample of the EUVP dataset. The repository code is MIT-licensed; the EUVP
images are distributed by the authors for research use — check the EUVP
terms before redistributing them. UIEB and RUIE were not downloaded (hosted
outside the sandbox's network allow-list); any folder of JPEG/PNG/BMP/TIFF
images works via `cfg.source.datasetPath`.

## Reproducibility

`cfg.seed` seeds `rng`; every experiment derives its own documented seed.
MATLAB and Octave use different generators, so identical numbers are only
expected on the same platform. Random interleaver permutations, preambles,
pilots and the LDPC construction are generated by deterministic hash/LCG
routines that do not depend on `rng`, so code construction is identical on
both platforms.

## What's in the box (feature summary)

Codecs: JPEG, JPEG XL, PNG, learned Deep JSCC · Channel codes: QC-LDPC (1/2–5/6),
polar SC and CA-SCL, Reed–Solomon, uncoded · Erasure/recovery: selective-repeat
ARQ, packet-level fountain code, ROI-only retransmission · Modulation: BPSK,
QPSK, 16QAM, analog (Deep JSCC) · PHY: CP-OFDM with Doppler compensation,
single-carrier baseline · Channels: AWGN, image-method multipath, Doppler,
Rician time-varying, impulse-response replay · Adaptation: rate controller,
AMC controller, deadline-aware joint source/channel controller · ROI-aware
two-layer coding with unequal error protection.

## Key limitations (see the report for the full list)

* The LDPC matrices are a reproducible QC family with the 802.11n encoder
  structure, **not** the standard's tables.
* The channel uses rounded sample delays, a geometric (not ray-traced or
  measured) multipath model, and a common Doppler scale; feedback is
  error-free; the frame-format side information is assumed known at the receiver.
* The single-carrier baseline has no multipath equaliser (it fails on
  multipath by design, documented in Exp 4).
* The learned codec was not executed; JPEG XL results come from libjxl 0.7.
