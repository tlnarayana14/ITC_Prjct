#!/usr/bin/env python3
"""Optional learned-image-codec adapter for AquaImage_UWA (CompressAI).

STATUS: NOT EXECUTED in the development sandbox. torch/compressai could be
installed from PyPI, but the pretrained weights are hosted outside the
sandbox's network allow-list, so no learned-codec result in this project was
produced by this script. It is provided so the codec can be enabled on a
machine with internet access. Treat it as untested until you run
`python3 tools/learned_codec.py selftest <image.png>` successfully.

Container format written by `encode` (all integers big-endian):
    magic  b'LIC1'
    u8     model-name length, then model name (ascii)
    u8     quality
    u16    height, u16 width (original image size)
    u16    latent shape h, u16 latent shape w
    u8     number of strings lists (n)
    for each list: u32 byte length, then bytes
The decoder needs nothing else, so the container can be packetized like any
other compressed file.

Usage:
    learned_codec.py encode in.png out.lic --model bmshj2018-factorized --quality 3
    learned_codec.py decode in.lic out.png
    learned_codec.py selftest in.png
"""
import argparse, struct, sys

def _load(model, quality):
    import torch
    from compressai.zoo import models
    if model not in models:
        raise SystemExit(f"unknown model {model}; available: {sorted(models)}")
    net = models[model](quality=quality, pretrained=True).eval()
    net.update()
    return net

def _pad(x, p=64):
    import torch.nn.functional as F
    h, w = x.shape[2:]
    H = (h + p - 1) // p * p
    W = (w + p - 1) // p * p
    return F.pad(x, (0, W - w, 0, H - h), mode="replicate"), h, w

def encode(src, dst, model, quality):
    import numpy as np, torch
    from PIL import Image
    img = Image.open(src).convert("RGB")
    x = torch.from_numpy(np.asarray(img)).permute(2, 0, 1).float().div(255).unsqueeze(0)
    xp, h, w = _pad(x)
    net = _load(model, quality)
    with torch.no_grad():
        out = net.compress(xp)
    strings, shape = out["strings"], out["shape"]
    with open(dst, "wb") as f:
        mb = model.encode("ascii")
        f.write(b"LIC1" + struct.pack(">B", len(mb)) + mb + struct.pack(">BHHHHB", quality, h, w, shape[0], shape[1], len(strings)))
        for s in strings:
            f.write(struct.pack(">I", len(s[0])) + s[0])

def decode(src, dst):
    import numpy as np, torch
    from PIL import Image
    with open(src, "rb") as f:
        data = f.read()
    if data[:4] != b"LIC1":
        raise SystemExit("bad magic")
    p = 4
    n = data[p]; p += 1
    model = data[p:p + n].decode("ascii"); p += n
    quality, h, w, sh, sw, ns = struct.unpack(">BHHHHB", data[p:p + 10]); p += 10
    strings = []
    for _ in range(ns):
        (L,) = struct.unpack(">I", data[p:p + 4]); p += 4
        strings.append([data[p:p + L]]); p += L
    net = _load(model, quality)
    with torch.no_grad():
        xh = net.decompress(strings, [sh, sw])["x_hat"].clamp(0, 1)
    arr = (xh[0, :, :h, :w].permute(1, 2, 0).numpy() * 255).round().astype(np.uint8)
    Image.fromarray(arr).save(dst)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["encode", "decode", "selftest"])
    ap.add_argument("src"); ap.add_argument("dst", nargs="?")
    ap.add_argument("--model", default="bmshj2018-factorized")
    ap.add_argument("--quality", type=int, default=3)
    a = ap.parse_args()
    if a.cmd == "encode":
        encode(a.src, a.dst, a.model, a.quality)
    elif a.cmd == "decode":
        decode(a.src, a.dst)
    else:
        import os, tempfile
        d = tempfile.mkdtemp()
        encode(a.src, os.path.join(d, "t.lic"), a.model, a.quality)
        decode(os.path.join(d, "t.lic"), os.path.join(d, "t.png"))
        print("selftest ok, bytes =", os.path.getsize(os.path.join(d, "t.lic")))

if __name__ == "__main__":
    main()
