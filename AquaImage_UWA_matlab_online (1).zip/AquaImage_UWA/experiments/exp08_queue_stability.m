function R = exp08_queue_stability()
%EXP08_QUEUE_STABILITY Experiment 8: continuous-source stability vs camera rate.
%
%   20 images are transmitted ONCE per source setting (multipath, 10 dB,
%   LDPC 1/2, SR-ARQ max 3). Because in this model the physical-layer outcome
%   of an image does not depend on when it is sent, the queue timeline is then
%   re-evaluated for camera intervals {1, 5, 10, 15, 20, 30, 60} s with
%   SIMULATE_QUEUE (FIFO), plus a deadline policy (drop if waiting > 60 s).
%   Source settings: JPEG q50 (~1 bpp) and JPEG q20 (~0.5 bpp).
%   Utilisation rho = mean service time / interval; rho >= 1 => unstable.
base = experiment_base();
base.arq.enabled = true; base.arq.maxRetries = 3;
base.source.numImages = 20;
base.chan.snrDb = 10;
intervals = [1 5 10 15 20 30 60];
rows = {}; R.queue = struct();
for q = [50 20]
    c = base; c.codec.jpegQuality = q;
    set_seed(base.seed + 800 + q);
    S = run_link_simulation(c, struct('tag', 'exp08', 'saveArtifacts', false));
    P = S.perImage;
    svc = arrayfun(@(e) sum(e.segments(:, 2)), P);
    Tprop = c.chan.range_m / c.chan.c;
    for pol = {'fifo', 'deadline'}
        for T = intervals
            cq = c; cq.queue.policy = pol{1}; cq.queue.deadline_s = 60;
            tGen = (0:numel(P) - 1) * T;
            tl = simulate_queue(tGen, [P.encTime_s], [P.decTime_s], {P.segments}, [P.deliveredSeg], [P.success], Tprop, cq);
            d = tl.delay(~isnan(tl.delay));
            delivered = nnz(~isnan(tl.tDelivered));
            rows(end + 1, :) = {q, pol{1}, T, mean(svc), mean(svc) / T, delivered, numel(P), nnz(tl.dropped), ...
                mean(d), max(d), max(tl.Q), tl.Q(end), sum(8 * [P(~isnan(tl.tDelivered)).compBytes]) / tl.horizon}; %#ok<AGROW>
            if strcmp(pol{1}, 'fifo') && any(T == [1 30])
                R.queue.(sprintf('q%d_T%d', q, T)) = tl;
            end
        end
    end
    fprintf('[exp08] q%d: mean service %.1f s, delivered %d/%d\n', q, mean(svc), nnz([P.success]), numel(P));
end
hdr = {'jpegQuality', 'policy', 'interval_s', 'meanService_s', 'rho', 'delivered', 'images', 'dropped', ...
    'meanDelay_s', 'maxDelay_s', 'maxQueue', 'finalQueue', 'goodput_bps'};
write_csv(fullfile(base.out.resultsDir, 'tables', 'exp08_queue.csv'), hdr, rows);
R.rows = rows;
fd = fullfile(base.out.resultsDir, 'figures');
f = prepare_figure(800, 460); hold on;
k = fieldnames(R.queue); st = {'-', '--', '-.', ':'};
for i = 1:numel(k)
    tl = R.queue.(k{i});
    stairs(tl.tQ, tl.Q, st{mod(i - 1, 4) + 1}, 'LineWidth', 1.5);
end
grid on; xlabel('time (s)'); ylabel('images waiting in the queue');
legend(strrep(k, '_', ' '), 'Location', 'northwest');
title('Exp 8: queue length over time (FIFO), multipath 10 dB, LDPC 1/2 + ARQ');
save_figure(f, fullfile(fd, 'exp08_queue_length.png'));
f = prepare_figure(800, 460); hold on;
leg = {};
for q = [50 20]
    m = cell2mat(rows(:, 1)) == q & strcmp(rows(:, 2), 'fifo');
    plot(cell2mat(rows(m, 3)), cell2mat(rows(m, 9)), 'o-', 'LineWidth', 1.5);
    leg{end + 1} = sprintf('JPEG q%d (mean service %.1f s)', q, rows{find(m, 1), 4}); %#ok<AGROW>
end
set(gca, 'YScale', 'log'); grid on; xlabel('camera interval (s)'); ylabel('mean image delay (s)');
legend(leg, 'Location', 'northeast'); title('Exp 8: delay vs camera interval (FIFO)');
save_figure(f, fullfile(fd, 'exp08_delay_vs_interval.png'));
end
