function s = det_qpsk_seq(n, key)
%DET_QPSK_SEQ Deterministic unit-energy QPSK sequence (known to Tx and Rx).
%   s = DET_QPSK_SEQ(n, key) uses a Park-Miller LCG seeded by key, so the
%   sequence does not depend on (or disturb) the global random generator.
st = mod(key * 48271 + 1, 2147483647);
b = zeros(2 * n, 1);
for k = 1:2 * n
    st = mod(st * 16807, 2147483647);
    b(k) = st > 1073741823;
end
s = mod_map(b, 'qpsk');
end
