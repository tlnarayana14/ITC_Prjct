function cfg = validate_config(cfg)
%VALIDATE_CONFIG Check a configuration before a (possibly long) simulation.
%   cfg = VALIDATE_CONFIG(cfg) throws an error with a specific message if a
%   field is missing/invalid or a required dependency (e.g. cjxl) is absent.
%   Returns cfg with derived fields filled in (cfg.derived.*).

req = {'seed','source','codec','pkt','crc','fec','mod','phy','chan','arq','queue','out'};
for k = 1:numel(req)
    if ~isfield(cfg, req{k})
        error('validate_config:missing', 'cfg.%s is missing (start from default_config()).', req{k});
    end
end

% --- source
if ~(isscalar(cfg.source.interval_s) && cfg.source.interval_s > 0)
    error('validate_config:interval', 'cfg.source.interval_s must be a positive scalar.');
end
if ~(isscalar(cfg.source.numImages) && cfg.source.numImages >= 1 && cfg.source.numImages == round(cfg.source.numImages))
    error('validate_config:numImages', 'cfg.source.numImages must be a positive integer.');
end
if exist(cfg.source.datasetPath, 'dir') ~= 7
    error('validate_config:dataset', 'Dataset folder not found: %s', cfg.source.datasetPath);
end

% --- codec
switch lower(cfg.codec.name)
    case 'jpeg'
        if cfg.codec.jpegQuality < 1 || cfg.codec.jpegQuality > 100
            error('validate_config:jpegq', 'cfg.codec.jpegQuality must be in 1..100.');
        end
    case 'jpegxl'
        if ~codec_available('jpegxl', cfg)
            error('validate_config:cjxl', ['JPEG XL selected but "%s"/"%s" were not found on the system path. ', ...
                'Install libjxl (e.g. apt install libjxl-tools) or set cfg.codec.cjxl/djxl to full paths.'], ...
                cfg.codec.cjxl, cfg.codec.djxl);
        end
    case 'png'
    case 'learned'
        if ~codec_available('learned', cfg)
            error('validate_config:learned', ['Learned codec selected but the Python adapter could not import ', ...
                'compressai/torch (see tools/learned_codec.py). Choose jpeg or jpegxl instead.']);
        end
    otherwise
        error('validate_config:codec', 'Unknown codec "%s".', cfg.codec.name);
end

% --- packet / crc
if cfg.pkt.payloadBytes < 1 || cfg.pkt.payloadBytes > 65535
    error('validate_config:payload', 'cfg.pkt.payloadBytes must be 1..65535.');
end
crc_spec(cfg.crc.name);   % errors if unknown

% --- fec
switch lower(cfg.fec.code)
    case 'ldpc'
        ok = any(abs(cfg.fec.rate - [1/2 2/3 3/4 5/6]) < 1e-9);
        if ~ok
            error('validate_config:rate', 'LDPC supports rates 1/2, 2/3, 3/4, 5/6 only (got %g).', cfg.fec.rate);
        end
    case {'polar', 'polar_scl'}
        n = log2(cfg.fec.polarN);
        if n ~= round(n)
            error('validate_config:polarN', 'cfg.fec.polarN must be a power of two.');
        end
        if cfg.fec.rate <= 0 || cfg.fec.rate >= 1
            error('validate_config:rate', 'Polar rate must be in (0,1).');
        end
    case {'none', 'rs'}
    otherwise
        error('validate_config:fec', 'Unknown channel code "%s".', cfg.fec.code);
end

% --- modulation / phy / channel
if ~any(strcmpi(cfg.mod.scheme, {'bpsk','qpsk','16qam','analog'}))
    error('validate_config:mod', 'Unknown modulation "%s".', cfg.mod.scheme);
end
if ~any(strcmpi(cfg.phy.type, {'sc','ofdm'}))
    error('validate_config:phy', 'cfg.phy.type must be ''sc'' or ''ofdm''.');
end
if strcmpi(cfg.chan.model, 'replay') && exist(cfg.chan.replayFile, 'file') ~= 2
    error('validate_config:replay', 'Channel replay file not found: %s (see channel/load_replay_channel.m for the format).', cfg.chan.replayFile);
end
if ~any(strcmpi(cfg.chan.model, {'ideal','awgn','multipath','doppler','timevarying','replay'}))
    error('validate_config:chan', 'Unknown channel model "%s".', cfg.chan.model);
end
if strcmpi(cfg.phy.type, 'ofdm')
    o = cfg.phy.ofdm;
    if mod(o.K, o.pilotSpacing) ~= 0
        error('validate_config:ofdm', 'K must be a multiple of pilotSpacing.');
    end
    Lh = round(o.chEstTaps_s * cfg.phy.B);
    if Lh > o.K / o.pilotSpacing
        error('validate_config:ofdm', 'Channel-estimate taps (%d) exceed number of pilots (%d).', Lh, o.K/o.pilotSpacing);
    end
end
if cfg.arq.maxRetries < 0
    error('validate_config:arq', 'cfg.arq.maxRetries must be >= 0.');
end

if ~isfield(cfg, 'debug') || ~isfield(cfg.debug, 'inject')
    cfg.debug.inject = struct('round', {}, 'seq', {}, 'nFlips', {});
end

% --- derived quantities
cfg.derived.packetBytes = cfg.pkt.headerBytes + cfg.pkt.payloadBytes + crc_spec(cfg.crc.name).width/8;
if exist(cfg.codec.tmpDir, 'dir') ~= 7
    mkdir(cfg.codec.tmpDir);
end
end
