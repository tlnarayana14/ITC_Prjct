function save_figure(f, fname)
%SAVE_FIGURE Save a figure as PNG (150 dpi) and close it (MATLAB and Octave).
%   MATLAB: paper size is set explicitly from the requested pixel size, then
%   print is tried; if it fails (MATLAB Online can report a 0x0 invisible
%   figure) exportgraphics (R2020a+) is used; as a last resort the figure is
%   made visible for the export. A figure that still cannot be saved produces
%   a warning, not an error, so a long experiment is never lost to a plot.
[d, ~] = fileparts(fname);
if ~isempty(d) && exist(d, 'dir') ~= 7, mkdir(d); end
if is_octave()
    print(f, fname, '-dpng', '-r150');
    close(f);
    return;
end
ud = get(f, 'UserData');
if isstruct(ud) && isfield(ud, 'w')
    w = ud.w; h = ud.h;
else
    p = get(f, 'Position'); w = max(p(3), 400); h = max(p(4), 300);
end
set(f, 'Units', 'pixels', 'Position', [100 100 w h]);
set(f, 'PaperUnits', 'inches', 'PaperPositionMode', 'manual', 'PaperPosition', [0 0 w h] / 100, 'PaperSize', [w h] / 100);
drawnow;
ok = false; msg = '';
try
    print(f, fname, '-dpng', '-r150'); ok = true;
catch err1
    msg = err1.message;
end
if ~ok && exist('exportgraphics', 'file')
    try
        exportgraphics(f, fname, 'Resolution', 150); ok = true;
    catch err2
        msg = err2.message;
    end
end
if ~ok
    try
        set(f, 'Visible', 'on'); drawnow;
        set(f, 'Position', [100 100 w h]); drawnow;
        print(f, fname, '-dpng', '-r150'); ok = true;
    catch err3
        msg = err3.message;
    end
end
if ~ok
    warning('save_figure:failed', 'Could not save %s (%s); results/tables are unaffected.', fname, msg);
end
close(f);
end
