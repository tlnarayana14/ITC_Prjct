function s = summarize_run(per, tl)
%SUMMARIZE_RUN Aggregate link, image and timing metrics of a run (Phase 14-16).
%
%   Definitions (all sums run over the images actually transmitted, i.e.
%   not dropped by the queue policy):
%   BER_pre   = sum coded-bit errors before decoding / sum transmitted coded bits
%   BER_post  = sum info-bit errors after decoding  / sum channel-encoder input bits
%               (info bits = packet header + payload + CRC, all transmissions)
%   BER_E2E_delivered = bit errors in delivered compressed payload bits /
%               delivered compressed payload bits  (only CRC-undetected
%               errors can contribute)
%   erasureRate = compressed payload bits in unrecovered packets / all payload bits
%   BER_E2E_total = (delivered-bit errors + erased bits) / all payload bits
%               (missing bits counted as errors: conservative upper bound)
%   PER_initial = packets failing their FIRST transmission / packets
%   PER_attempt = failed transmissions / all transmissions (incl. retries)
%   PER_final   = packets unrecovered after the retry policy / packets
%   deliveryRate = images completely recovered AND decoded / images generated
%   goodput_bps  = compressed-payload bits of successfully decoded images /
%                  simulation horizon (first generation to last link release or
%                  delivery). Headers, CRC, parity, padding, retransmissions,
%                  feedback and partial images are excluded from the numerator.
%   linkGoodput_bps = same numerator / total data-frame airtime of sent images
%   delay = tDelivered - tGen of delivered images (s)
sent = ~[per.dropped];
P = per(sent);
s.nImages = numel(per);
s.nSent = nnz(sent);
s.nDropped = nnz(~sent);
s.nDelivered = nnz([P.success]);
s.deliveryRate = s.nDelivered / max(s.nImages, 1);
s.BER_pre = sum([P.preErr]) / max(sum([P.preN]), 1);
s.BER_post = sum([P.postErr]) / max(sum([P.postN]), 1);
N = sum([P.e2eN]); er = sum([P.e2eErased]); ee = sum([P.e2eErr]);
s.BER_E2E_delivered = ee / max(N - er, 1);
s.erasureRate = er / max(N, 1);
s.BER_E2E_total = (ee + er) / max(N, 1);
np = sum([P.nPkts]);
s.packets = np;
s.transmissions = sum([P.nTransmissions]);
s.PER_initial = sum([P.firstFail]) / max(np, 1);
s.PER_attempt = sum(arrayfun(@(e) e.PER_attempt * e.nTransmissions, P)) / max(s.transmissions, 1);
s.PER_final = sum([P.lost]) / max(np, 1);
s.undetectedErrPkts = sum([P.undetected]);
s.meanCR = mean([P.CR]);
s.meanBpp = mean([P.bpp]);
s.meanCompBytes = mean([P.compBytes]);
s.psnr_I_Ic = mean([P.psnr_I_Ic]);
s.ssim_I_Ic = mean([P.ssim_I_Ic]);
okI = [P.success];
s.psnr_I_Ir_delivered = mean([P(okI).psnr_I_Ir]);
s.ssim_I_Ir_delivered = mean([P(okI).ssim_I_Ir]);
s.allDeliveredIcEqualsIr = all([P(okI).IcEqualsIr]);
s.airtime_s = sum([P.airtime_s]);
s.turnaround_s = sum([P.turnaround_s]);
useful = sum([P(okI).e2eN]);
s.usefulBits = useful;
s.horizon_s = tl.horizon;
s.goodput_bps = useful / max(tl.horizon, eps);
s.linkGoodput_bps = useful / max(s.airtime_s, eps);
d = [per.delay_s];
d = d(~isnan(d));
if isempty(d), d = NaN; end
s.meanDelay_s = mean(d);
s.maxDelay_s = max(d);
s.meanWait_s = mean([P.wait_s]);
s.maxQueue = max([tl.Q, 0]);
bits = [P.bits];
s.overhead = struct('payload', sum([bits.payload]), 'headerCrc', sum([bits.headerCrc]), ...
    'infoTx', sum([bits.info]), 'codedTx', sum([bits.coded]), 'pad', sum([bits.pad]), ...
    'retxInfo', sum([bits.retxInfo]), 'feedback', sum([bits.feedback]));
end
