function check(cond, fmt, varargin)
%CHECK Assertion used by the test suite: errors with a message when cond is false,
%   prints "  ok: <message>" otherwise, so every checked expectation is logged.
msg = sprintf(fmt, varargin{:});
if ~all(cond(:))
    error('check:failed', 'FAILED: %s', msg);
end
fprintf('    ok: %s\n', msg);
end
