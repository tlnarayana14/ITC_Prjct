#!/usr/bin/env python3
"""Train the Deep JSCC model on underwater images through the UWA OFDM channel.

Training data (no test leakage):
  data/underwater_samples/euvp_01..17.jpg   (EUVP raw frames)
  data/train_extra/euvp_gt/gt_01..17.jpg    (EUVP enhanced versions of the same 17 scenes)
  scikit-image sample photographs (astronaut, coffee, chelsea, rocket, cat, ...)
Held-out test images: euvp_18..23 (never seen in training).
Augmentation: random 128x128 crops, flips, small brightness/colour jitter.
Loss: MSE; SNR drawn uniformly from [-2, 16] dB per image.

Usage: python3 tools/deepjscc/train.py <project_root> [steps] [out.pt]
"""
import sys, os, time, json, math
import numpy as np
import torch
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from djscc import Encoder, Decoder, latent_to_symbols, symbols_to_latent, interleaver, UWAOFDMChannel

root = sys.argv[1]
steps = int(sys.argv[2]) if len(sys.argv) > 2 else 4000
out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(root, 'tools', 'deepjscc', 'djscc_uwa.pt')
torch.manual_seed(0); np.random.seed(0)
torch.set_num_threads(2)

imgs = []
for i in range(1, 18):
    imgs.append(np.asarray(Image.open(os.path.join(root, 'data', 'underwater_samples', f'euvp_{i:02d}.jpg')).convert('RGB')))
    imgs.append(np.asarray(Image.open(os.path.join(root, 'data', 'train_extra', 'euvp_gt', f'gt_{i:02d}.jpg')).convert('RGB')))
import skimage.data as skd
for n in ['astronaut', 'coffee', 'chelsea', 'rocket', 'cat']:
    a = getattr(skd, n)()
    if a.ndim == 3 and a.shape[2] == 3 and min(a.shape[:2]) >= 128:
        imgs.append(a)
print('training images:', len(imgs), flush=True)

def batch(bs=16, cs=128):
    xs = []
    for _ in range(bs):
        a = imgs[np.random.randint(len(imgs))]
        h, w = a.shape[:2]
        y0, x0 = np.random.randint(h - cs + 1), np.random.randint(w - cs + 1)
        c = a[y0:y0 + cs, x0:x0 + cs].astype(np.float32) / 255
        if np.random.rand() < 0.5: c = c[:, ::-1]
        if np.random.rand() < 0.5: c = c[::-1]
        c = np.clip(c * np.random.uniform(0.85, 1.15) + np.random.uniform(-0.05, 0.05, (1, 1, 3)), 0, 1)
        xs.append(c.transpose(2, 0, 1).astype(np.float32).copy())
    return torch.tensor(np.stack(xs))

ch = UWAOFDMChannel(os.path.join(root, 'data', 'channels', 'ofdm_training_channel.json'))
enc, dec = Encoder(), Decoder()
params = list(enc.parameters()) + list(dec.parameters())
print('parameters:', sum(p.numel() for p in params), flush=True)
opt = torch.optim.Adam(params, lr=1e-3)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps, eta_min=1e-4)
t0 = time.time(); log = []
for it in range(1, steps + 1):
    x = batch()
    snr = torch.empty(x.shape[0]).uniform_(-2, 16)
    z = enc(x, snr)
    shape = z.shape[1:]
    s = latent_to_symbols(z)
    perm = torch.tensor(interleaver(s.shape[1]))
    r = ch(s[:, perm], snr)
    rr = torch.empty_like(r); rr[:, perm] = r
    xh = dec(symbols_to_latent(rr, shape), snr)
    loss = ((xh - x) ** 2).mean()
    opt.zero_grad(); loss.backward(); opt.step(); sched.step()
    if it % 100 == 0:
        psnr = 10 * math.log10(1 / loss.item())
        log.append((it, loss.item(), psnr))
        print(f'step {it} mse {loss.item():.5f} psnr {psnr:.2f} dB  ({time.time() - t0:.0f} s)', flush=True)
torch.save({'enc': enc.state_dict(), 'dec': dec.state_dict(), 'steps': steps, 'log': log,
            'train_snr_db': [-2, 16], 'note': 'trained on euvp_01-17 (+GT) and skimage samples; test on euvp_18-23'}, out)
print('saved', out)
