function [msg, nerr, ok] = rs_decode(cw, t)
%RS_DECODE Hard-decision Reed-Solomon decoder (Berlekamp-Massey, Chien, Forney).
%   [msg, nerr, ok] = RS_DECODE(cw, t): cw = received shortened codeword
%   (k + 2t bytes). Corrects up to t byte errors. ok = false when the error
%   pattern is detected as uncorrectable (msg is then the uncorrected data
%   part, which the packet CRC will reject).
G = rs_gf();
r = double(cw(:)).';
n = numel(r); np = 2 * t; k = n - np;
% syndromes S_i = r(alpha^i), i = 1..2t  (r(1) is the highest-degree coeff)
nz = find(r ~= 0);
S = zeros(1, np);
if ~isempty(nz)
    lr = G.log(r(nz) + 1); pw = n - nz;
    E = G.exp(mod(lr(:) + pw(:) * (1:np), 255) + 1);   % |nz| x 2t terms
    bits = mod(floor(E(:) * 2.^-(0:7)), 2);            % XOR-reduce via bit parity
    bits = reshape(bits, numel(nz), np, 8);
    S = reshape(mod(sum(bits, 1), 2), np, 8) * (2.^(0:7)).';
    S = S(:).';
end
msg = uint8(r(1:k).'); nerr = 0; ok = true;
if all(S == 0), return; end
% Berlekamp-Massey: error locator Lambda(x) (lowest degree first)
L = 0; Lam = [1 zeros(1, np)]; Bp = [1 zeros(1, np)]; m = 1; b = 1;
for q = 1:np
    d = S(q);
    for i = 1:L
        if Lam(i + 1) ~= 0 && S(q - i) ~= 0
            d = bitxor(d, gmul(Lam(i + 1), S(q - i), G));
        end
    end
    if d == 0
        m = m + 1;
    else
        coef = gmul(d, ginv(b, G), G);
        T = Lam;
        for i = 1:numel(Bp) - m
            if Bp(i) ~= 0
                Lam(i + m) = bitxor(Lam(i + m), gmul(coef, Bp(i), G));
            end
        end
        if 2 * L <= q - 1
            L = q - L; Bp = T; b = d; m = 1;
        else
            m = m + 1;
        end
    end
end
Lam = Lam(1:L + 1);
% Chien search over the transmitted positions: position j (1-based) has
% power p = n - j; locator root is alpha^(-p)
pos = []; Xs = [];
for j = 1:n
    p = n - j;
    v = 0;
    for i = 0:L
        if Lam(i + 1) ~= 0
            v = bitxor(v, G.exp(mod(G.log(Lam(i + 1) + 1) - i * p, 255) + 1));
        end
    end
    if v == 0, pos(end + 1) = j; Xs(end + 1) = G.exp(mod(p, 255) + 1); end %#ok<AGROW>
end
if numel(pos) ~= L
    ok = false; nerr = -1; return;       % uncorrectable (roots outside the shortened block)
end
% Forney: Omega(x) = S(x) Lambda(x) mod x^2t, e_j = Omega(X_j^-1) / Lambda'(X_j^-1)  (fcr = 1)
Om = zeros(1, np);
for i = 0:np - 1
    v = 0;
    for j = 0:min(i, L)
        if Lam(j + 1) ~= 0 && S(i - j + 1) ~= 0
            v = bitxor(v, gmul(Lam(j + 1), S(i - j + 1), G));
        end
    end
    Om(i + 1) = v;
end
for e = 1:numel(pos)
    Xi = ginv(Xs(e), G);
    num = 0;
    for i = 0:np - 1
        if Om(i + 1) ~= 0, num = bitxor(num, gmul(Om(i + 1), gpow(Xi, i, G), G)); end
    end
    den = 0;
    for i = 1:2:L                          % formal derivative: odd terms
        if Lam(i + 1) ~= 0, den = bitxor(den, gmul(Lam(i + 1), gpow(Xi, i - 1, G), G)); end
    end
    if den == 0, ok = false; nerr = -1; return; end
    mag = gmul(num, ginv(den, G), G);         % fcr = 1: e = Omega(X^-1) / Lambda'(X^-1)
    r(pos(e)) = bitxor(r(pos(e)), mag);
end
msg = uint8(r(1:k).');
nerr = numel(pos);
end

function c = gmul(a, b, G)
if a == 0 || b == 0, c = 0; else, c = G.exp(mod(G.log(a + 1) + G.log(b + 1), 255) + 1); end
end
function c = ginv(a, G)
c = G.exp(mod(255 - G.log(a + 1), 255) + 1);
end
function c = gpow(a, e, G)
if e == 0, c = 1; elseif a == 0, c = 0; else, c = G.exp(mod(G.log(a + 1) * e, 255) + 1); end
end
