function test_Q_amc_controller()
%TEST_Q_AMC_CONTROLLER Rule checks of the adaptive modulation-and-coding controller.
modes = struct('scheme', {'qpsk', 'qpsk', '16qam'}, 'rate', {1/2, 3/4, 3/4}, 'eff', {1, 1.5, 3});
thr = [4 9 16];
opt = struct('m0', 0.5, 'kSigma', 1.5, 'sigma0', 2.0, 'allowModulation', true);
d = amc_controller(struct('k', 1, 'lastSnrEstDb', NaN), modes, thr, opt);
check(d.rate == 1/2 && strcmp(d.modScheme, 'qpsk'), 'no CSI yet -> most robust mode');
d = amc_controller(struct('k', 2, 'lastSnrEstDb', 20), modes, thr, opt);
check(strcmp(d.modScheme, '16qam'), 'high SNR (20 dB, margin 3.5 dB) -> 16QAM R=3/4');
d = amc_controller(struct('k', 3, 'lastSnrEstDb', 12), modes, thr, opt);
check(d.rate == 1/2 && strcmp(d.modScheme, 'qpsk'), 'falling estimate (20 -> 12 dB): pessimistic trend predicts 4 dB -> R=1/2');
opt.allowModulation = false;
d = amc_controller(struct('k', 1, 'lastSnrEstDb', NaN), modes, thr, opt);
d = amc_controller(struct('k', 2, 'lastSnrEstDb', 25), modes, thr, opt);
check(strcmp(d.modScheme, 'qpsk') && d.rate == 3/4, 'rate-only mode never selects 16QAM');
end
