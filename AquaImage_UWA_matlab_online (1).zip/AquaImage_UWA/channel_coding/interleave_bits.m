function y = interleave_bits(x, key, inverse)
%INTERLEAVE_BITS Frame-level pseudo-random bit (or LLR) interleaver.
%   y = INTERLEAVE_BITS(x, key)          y = x(perm)
%   y = INTERLEAVE_BITS(x, key, true)    inverse: y(perm) = x
%   perm = hash_perm(numel(x), key) is shared by transmitter and receiver
%   (the key is the frame counter), spreading each code block over the
%   whole frame so that a deep fade or an equalization error burst becomes
%   scattered errors at the decoder input.
if nargin < 3, inverse = false; end
x = x(:);
p = hash_perm(numel(x), key);
if inverse
    y = zeros(size(x));
    y(p) = x;
else
    y = x(p);
end
end
