#!/usr/bin/env python3
"""Build the small format-coverage test set in data/format_test/.

Derived ONLY from the EUVP sample images in data/underwater_samples/ so that
the PNG/BMP/TIFF loaders are exercised on real underwater content:
  fmt_png_rgb.png      euvp_05 re-saved losslessly as PNG (RGB, 8 bit)
  fmt_bmp_rgb.bmp      euvp_09 as 24-bit BMP
  fmt_tif_rgb.tif      euvp_14 as uncompressed TIFF (RGB, 8 bit)
  fmt_tif_rgb16.tif    euvp_20 as 16-bit-per-channel TIFF (tests bit-depth handling)
  fmt_png_gray.png     euvp_23 converted to 8-bit grayscale PNG
  fmt_jpg_crop.jpg     euvp_01 cropped to 200x150 (tests non-square dimensions)

Usage:  python3 tools/make_format_test.py <project_root>
"""
import sys, os
import numpy as np
from PIL import Image

root = sys.argv[1] if len(sys.argv) > 1 else "."
src = os.path.join(root, "data", "underwater_samples")
dst = os.path.join(root, "data", "format_test")
os.makedirs(dst, exist_ok=True)

def load(i):
    return Image.open(os.path.join(src, f"euvp_{i:02d}.jpg")).convert("RGB")

load(5).save(os.path.join(dst, "fmt_png_rgb.png"))
load(9).save(os.path.join(dst, "fmt_bmp_rgb.bmp"))
load(14).save(os.path.join(dst, "fmt_tif_rgb.tif"), compression=None)
a = np.asarray(load(20)).astype(np.uint16) * 257          # exact 8->16 bit expansion
try:
    import imagecodecs
    imagecodecs.imwrite(os.path.join(dst, "fmt_tif_rgb16.tif"), a) if hasattr(imagecodecs, "imwrite") else None
except Exception:
    pass
if not os.path.exists(os.path.join(dst, "fmt_tif_rgb16.tif")):
    import tifffile  # fallback
    tifffile.imwrite(os.path.join(dst, "fmt_tif_rgb16.tif"), a)
load(23).convert("L").save(os.path.join(dst, "fmt_png_gray.png"))
load(1).crop((10, 20, 210, 170)).save(os.path.join(dst, "fmt_jpg_crop.jpg"), quality=95)
print("format test set written to", dst)
