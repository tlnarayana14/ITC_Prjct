function dec = rate_controller(state, rates, thrDb, marginDb)
%RATE_CONTROLLER Rule-based LDPC code-rate selection (Phase 17).
%
%   dec = RATE_CONTROLLER(state, rates, thrDb, marginDb)
%     state.lastSnrEstDb : receiver SNR estimate of the PREVIOUS image,
%                          fed back with the ARQ acknowledgement (so the
%                          controller always acts on one-image-old CSI)
%     rates(i), thrDb(i) : candidate rates (ascending) and the estimated SNR
%                          above which rate i achieved first-attempt PER <= 10%
%                          in Experiment 3 (multipath channel)
%     marginDb           : safety margin added to every threshold
%   Rule: choose the HIGHEST rate whose threshold + margin <= last estimate;
%   if none qualifies, or no estimate exists yet, choose the most robust rate.
dec.rate = rates(1);
s = state.lastSnrEstDb;
if isnan(s)
    return;
end
ok = find(thrDb + marginDb <= s);
if ~isempty(ok)
    dec.rate = rates(max(ok));
end
end
