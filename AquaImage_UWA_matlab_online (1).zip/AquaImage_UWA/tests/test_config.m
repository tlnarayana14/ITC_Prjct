function cfg = test_config()
%TEST_CONFIG Small, fast configuration shared by the tests.
cfg = default_config();
cfg.source.numImages = 1;
cfg.codec.name = 'jpeg';
cfg.codec.jpegQuality = 30;
cfg.chan.model = 'ideal';
cfg.phy.type = 'ofdm';
cfg.out.verbose = 0;
cfg.out.saveImages = false;
cfg.out.makePlots = false;
cfg.out.resultsDir = fullfile(cfg.root, 'results', 'test_runs');
cfg = validate_config(cfg);
end
