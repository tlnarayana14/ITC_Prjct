function bytes = bits_to_bytes(bits)
%BITS_TO_BYTES Inverse of BYTES_TO_BITS (MSB first). numel(bits) must be a multiple of 8.
bits = double(bits(:));
if mod(numel(bits), 8) ~= 0
    error('bits_to_bytes:len', 'Bit vector length (%d) is not a multiple of 8.', numel(bits));
end
B = reshape(bits, 8, []).';
bytes = uint8(B * (2 .^ (7:-1:0)).');
end
