function R = exp13_codes_recovery()
%EXP13_CODES_RECOVERY Experiment 13: added channel codes and erasure recovery.
%
%   Part A (no ARQ, OFDM/QPSK, 2 images euvp_01..02):
%     LDPC R=1/2 | polar SC R=1/2 | polar CA-SCL (L=8, CRC-16) R=1/2 |
%     Reed-Solomon RS(255,223) (rate 0.87, hard decisions) on AWGN and
%     multipath, SNR chosen around each family's threshold.
%   Part B (multipath, LDPC R=1/2, 4 images, camera interval 120 s):
%     selective-repeat ARQ (<= 3 retries) vs packet-level fountain code
%     (burst sized for 10 % or 25 % a-priori packet loss, <= 3 extra rounds)
%     -> delivery, latency, link occupation, symbols sent.
base = experiment_base();
td = fullfile(base.out.resultsDir, 'tables'); fd = fullfile(base.out.resultsDir, 'figures');
% ---------------- Part A
b = base; b.source.numImages = 2;
v = struct('name', {}, 'apply', {});
v(end + 1) = struct('name', 'LDPC R=1/2', 'apply', @(c) setc(c, 'ldpc'));
v(end + 1) = struct('name', 'polar SC R=1/2', 'apply', @(c) setc(c, 'polar'));
v(end + 1) = struct('name', 'polar CA-SCL8 R=1/2', 'apply', @(c) setc(c, 'polar_scl'));
v(end + 1) = struct('name', 'RS(255,223)', 'apply', @(c) setc(c, 'rs'));
TA = struct([]);
for ch = {'awgn', 'multipath'}
    bb = b; bb.chan.model = ch{1};
    if strcmp(ch{1}, 'awgn'), snrs = [1 2 3 4 6 8 10]; else, snrs = [4 5 6 7 8 10 14]; end
    T = link_sweep(bb, v, snrs, ['exp13A_' ch{1}]);
    [T.channel] = deal(ch{1});
    save_sweep(T, fullfile(td, sprintf('exp13A_codes_%s.csv', ch{1})));
    plot_sweep(T, 'PER_initial', 'packet error rate (no ARQ)', sprintf('Exp 13A: codes incl. CA-SCL polar and RS, %s', ch{1}), fullfile(fd, sprintf('exp13A_per_%s.png', ch{1})), true, 1e-4);
    if isempty(TA), TA = T; else, TA = [TA, T]; end %#ok<AGROW>
end
% ---------------- Part B
b = base; b.source.interval_s = 120; b.arq.enabled = true; b.arq.maxRetries = 3;
w = struct('name', {}, 'apply', {});
w(end + 1) = struct('name', 'SR-ARQ', 'apply', @(c) setr(c, 'arq', 0.1));
w(end + 1) = struct('name', 'fountain (10% overhead sizing)', 'apply', @(c) setr(c, 'fountain', 0.10));
w(end + 1) = struct('name', 'fountain (25% overhead sizing)', 'apply', @(c) setr(c, 'fountain', 0.25));
TB = link_sweep(b, w, [4.5 5 5.5 6 8], 'exp13B');
for i = 1:numel(TB)
    TB(i).busyGoodput_bps = TB(i).linkGoodput_bps * TB(i).airtime_s / max(TB(i).airtime_s + TB(i).turnaround_s, eps);
    TB(i).occupationPerImage_s = (TB(i).airtime_s + TB(i).turnaround_s) / TB(i).nImages;
end
save_sweep(TB, fullfile(td, 'exp13B_fountain_vs_arq.csv'));
plot_sweep(TB, 'deliveryRate', 'image delivery rate', 'Exp 13B: fountain vs selective-repeat ARQ (multipath)', fullfile(fd, 'exp13B_delivery.png'), false);
plot_sweep(TB, 'meanDelay_s', 'mean latency of delivered images (s)', 'Exp 13B: latency, fountain vs ARQ', fullfile(fd, 'exp13B_latency.png'), false);
plot_sweep(TB, 'occupationPerImage_s', 'link occupation per image (s)', 'Exp 13B: airtime + turnarounds per image', fullfile(fd, 'exp13B_occupation.png'), false);
R.A = TA; R.B = TB;
end

function c = setc(c, code)
c.fec.code = code; c.fec.rate = 1/2;
end
function c = setr(c, mode, pe)
c.recovery.mode = mode; c.fountain.perEst = pe;
end
