function c = xcorr_fft(r, s)
%XCORR_FFT Sliding correlation c(n+1) = sum_k r(n+k) * conj(s(k)), n = 0..numel(r)-1.
%   FFT-based (zero-padded, no circular wrap for valid lags). Used for
%   preamble/postamble detection (matched filtering) in both PHYs.
r = r(:); s = s(:);
L = 2^nextpow2(numel(r) + numel(s));
c = ifft(fft(r, L) .* conj(fft(s, L)));
c = c(1:numel(r));
end
