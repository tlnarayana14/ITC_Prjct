function ev = image_source_schedule(cfg)
%IMAGE_SOURCE_SCHEDULE Continuous still-image camera model (Phase 1 / 16).
%
%   ev = IMAGE_SOURCE_SCHEDULE(cfg) returns a struct array, one element per
%   generated image, in arrival order (this is the source FIFO queue):
%       ev(k).id     unique image identifier (k-1, fits the 16-bit header field)
%       ev(k).path   file that the camera "captures" at that instant
%       ev(k).tGen   generation timestamp (s) = (k-1) * cfg.source.interval_s
%
%   The camera is modelled as deterministic periodic capture; frames are
%   independent stills drawn in sorted order from cfg.source.datasetPath
%   (cycling when cfg.source.cycle is true). Any folder of JPEG/PNG/BMP/TIFF
%   images can be used, no specific dataset is required.

files = list_image_files(cfg.source.datasetPath, cfg.source.extensions);
N = cfg.source.numImages;
if N > numel(files) && ~cfg.source.cycle
    error('image_source_schedule:few', 'Requested %d images but folder has %d (set cfg.source.cycle=true).', N, numel(files));
end
if N > 65536
    error('image_source_schedule:id', 'Image identifiers are 16-bit; at most 65536 images per run.');
end
ev = struct('id', cell(1, N), 'path', cell(1, N), 'tGen', cell(1, N));
for k = 1:N
    ev(k).id   = k - 1;
    ev(k).path = files{mod(k - 1, numel(files)) + 1};
    ev(k).tGen = (k - 1) * cfg.source.interval_s;
end
end
