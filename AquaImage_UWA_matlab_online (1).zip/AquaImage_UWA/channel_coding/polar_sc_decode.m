function uhat = polar_sc_decode(pc, llr, frozen)
%POLAR_SC_DECODE Successive-cancellation decoding (min-sum f, exact g).
%   uhat = POLAR_SC_DECODE(pc, llr)          llr: N x B, L = log P(0)/P(1)
%   uhat = POLAR_SC_DECODE(pc, llr, frozen)  custom frozen mask (N x 1, true =
%          frozen to 0), used for shortened last blocks (known zero padding).
%   Returns the K x B (or nnz(~frozen) x B) information-bit estimates.
if nargin < 3
    frozen = ~pc.info;
end
[u, ~] = sc(llr, frozen);
uhat = u(~frozen, :);
end

function [u, x] = sc(L, frozen)
N = size(L, 1);
if N == 1
    if frozen
        u = zeros(1, size(L, 2));
    else
        u = double(L < 0);
    end
    x = u;
    return;
end
h = N / 2;
La = L(1:h, :); Lb = L(h + 1:end, :);
% f: LLR of v1 = xa xor xb  (min-sum approximation of the box-plus)
Lf = sign(La) .* sign(Lb) .* min(abs(La), abs(Lb));
[u1, v1] = sc(Lf, frozen(1:h));
% g: LLR of v2 given v1
Lg = Lb + (1 - 2 * v1) .* La;
[u2, v2] = sc(Lg, frozen(h + 1:end));
u = [u1; u2];
x = [mod(v1 + v2, 2); v2];
end
