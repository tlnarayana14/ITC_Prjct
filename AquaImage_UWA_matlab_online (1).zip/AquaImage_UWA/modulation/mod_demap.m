function llr = mod_demap(y, nVar, scheme)
%MOD_DEMAP Max-log soft demapper.
%   llr = MOD_DEMAP(y, nVar, scheme)
%     y    : S x 1 equalised symbols
%     nVar : complex noise variance E|n|^2 per symbol (scalar or S x 1),
%            i.e. N0 for unit-energy symbols; after one-tap equalisation by h
%            the caller passes N0/|h|^2.
%   Output: (S*m) x 1 LLRs, L = log P(b=0|y)/P(b=1|y) (positive -> 0),
%   in the same bit order as MOD_MAP. For BPSK/QPSK with Gray labelling the
%   max-log value equals the exact LLR (e.g. QPSK: L = 2*sqrt(2)*Re(y)/N0).
[pts, labels, m] = mod_constellation(scheme);
y = y(:);
nVar = max(nVar(:), 1e-12);
D = abs(y - pts).^2;                 % S x Mc (implicit expansion)
llr = zeros(numel(y), m);
for k = 1:m
    d1 = min(D(:, labels(:, k) == 1), [], 2);
    d0 = min(D(:, labels(:, k) == 0), [], 2);
    llr(:, k) = (d1 - d0) ./ nVar;
end
llr = reshape(llr.', [], 1);
end
