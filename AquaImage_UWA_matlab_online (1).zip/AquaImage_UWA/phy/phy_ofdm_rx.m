function [llr, d] = phy_ofdm_rx(r, meta, cfg)
%PHY_OFDM_RX Receiver for PHY_OFDM_TX frames.
%
%   [llr, d] = PHY_OFDM_RX(r, meta, cfg)
%     r    : received complex baseband samples (unknown start offset)
%     meta : frame-format description from the transmitter (sizes only;
%            in a real modem these are fixed by the protocol / frame header)
%   Processing chain
%     1. synchronisation   : matched filter to the LFM preamble and postamble
%     2. Doppler scale     : a_hat = D_tx / D_rx - 1 from the chirp distance
%     3. resampling        : z(k) = r(n1 + k/(1+a_hat))  (cubic spline)
%     4. CFO removal       : exp(-j 2 pi a_hat/(1+a_hat) fc t), then residual
%                            CFO by null-subcarrier energy minimisation
%     5. per OFDM symbol   : CP removal, FFT, LS pilot estimate, time-domain
%                            LS channel interpolation, one-tap equalisation
%     6. noise variance    : mean power on in-band null subcarriers
%     7. soft demapping    : max-log LLRs with per-subcarrier N0/|H|^2
%   d (diagnostics): n1, aHat, cfoRes_Hz, noiseVar, snrEstDb (data-subcarrier
%   Es/N0 estimate used for adaptation), syncOk.

p = ofdm_params(cfg);
r = r(:);
fs = p.fs;
d = struct('n1', NaN, 'aHat', 0, 'cfoRes_Hz', 0, 'noiseVar', NaN, 'snrEstDb', NaN, 'syncOk', true);

% ---- 1-2 synchronisation and Doppler scale estimation
c = xcorr_fft(r, p.chirp);
searchHi = round((cfg.phy.startOffsetMax_s + 0.05) * fs);
[n1, ~] = find_peak(c, 1, searchHi);
Dtx = meta.postStart - 1;
win = round(0.01 * Dtx + 0.03 * fs);
if isnan(n1)
    d.syncOk = false;
    llr = zeros(meta.nBits, 1);
    return;
end
% Postamble: match the whole multipath correlation PROFILE (not only its
% strongest peak), so that fading which changes the strongest arrival
% between preamble and postamble does not bias the Doppler-scale estimate.
Drx = profile_lag(abs(c), round(n1), Dtx, win, round(0.005 * fs), round(0.03 * fs));
if isnan(Drx)
    d.syncOk = false;
    llr = zeros(meta.nBits, 1);
    return;
end
aHat = Dtx / Drx - 1;
d.n1 = n1; d.aHat = aHat;
if ~cfg.phy.ofdm.dopplerComp
    aHat = 0;
end

% ---- 3 resampling onto the transmitter's time grid
k = (0:meta.len - 1).';
tq = n1 + k / (1 + aHat);
idx = (1:numel(r)).';
if abs(aHat) > 1e-7 || abs(n1 - round(n1)) > 1e-6
    z = interp1(idx, real(r), tq, 'spline', 0) + 1j * interp1(idx, imag(r), tq, 'spline', 0);
else
    z = zeros(meta.len, 1);
    s0 = round(n1);
    nAvail = min(meta.len, numel(r) - s0 + 1);
    z(1:nAvail) = r(s0:s0 + nAvail - 1);
end

% ---- 4 carrier-frequency offset caused by the Doppler scaling
z = z .* exp(-1j * 2 * pi * (aHat / (1 + aHat)) * p.fc * k / fs);
starts = meta.bodyStart + (0:meta.nOfdm - 1) * p.Nsym + p.Ncp - p.backoff;
W = starts + (0:p.Nfft - 1).';                      % Nfft x nOfdm sample indices
W = min(W, meta.len);
tW = (W - 1) / fs;
nb = p.bin(p.nullIdx);
zW = z(W);
cost = @(e) null_energy(zW, tW, e, nb);
% residual CFO search over +-3 subcarrier spacings (covers a Doppler-scale
% error of ~1e-3 at fc = 24 kHz); the null pattern is aperiodic, so integer
% subcarrier offsets are resolvable
grid1 = p.df * (-3:0.1:3);
J = arrayfun(cost, grid1);
[~, b] = min(J);
grid2 = grid1(b) + p.df * (-0.1:0.005:0.1);
J2 = arrayfun(cost, grid2);
[~, b2] = min(J2);
eps = grid2(b2);
d.cfoRes_Hz = eps;
Zw = fft(z(W) .* exp(-1j * 2 * pi * eps * tW)) / p.scale;   % Nfft x nOfdm

% ---- 5-6 channel estimation, noise estimation, equalisation
Y = Zw(p.bin, :);                                   % K x nOfdm (in-band)
Hp = Y(p.pilotIdx, :) ./ p.pilotSym;
noiseVar = mean(abs(Y(p.nullInband, :)).^2, 1);     % 1 x nOfdm
noiseVar = 0.5 * noiseVar + 0.5 * mean(noiseVar);   % smoothed across the frame
A = max(1, round(p.avgSymbols));
if A > 1                                            % moving average over symbols
    Hp = moving_avg_cols(Hp, A);
end
h = p.pinvFp * Hp;                                  % Lh x nOfdm time-domain LS
if p.tapThreshold > 0
    tapVar = noiseVar / numel(p.pilotIdx) / A;
    h(abs(h).^2 <= p.tapThreshold * tapVar) = 0;   % significant-tap selection
end
H = p.Fall * h;
Hd = H(p.dataIdx, :);
Yd = Y(p.dataIdx, :);
eq = Yd ./ Hd;
nv = noiseVar ./ max(abs(Hd).^2, 1e-12);
nData = numel(Yd) - meta.nFill;
eq = eq(:); nv = nv(:);
if strcmpi(cfg.mod.scheme, 'analog')
    % Deep-JSCC mode: return LMMSE-equalised complex symbols instead of LLRs
    m = (conj(Hd) .* Yd) ./ (abs(Hd).^2 + noiseVar);
    llr = m(:);
    llr = llr(1:meta.nBits);
    d.noiseVar = mean(noiseVar);
    d.snrEstDb = 10 * log10(mean(abs(Hd(:)).^2) / mean(noiseVar));
    return;
end
llr = mod_demap(eq(1:nData), nv(1:nData), cfg.mod.scheme);
llr = llr(1:meta.nBits);
d.noiseVar = mean(noiseVar);
d.snrEstDb = 10 * log10(mean(abs(Hd(:)).^2) / mean(noiseVar));
end

function D = profile_lag(m, n1, Dtx, win, pre, post)
% Lag D (fractional) that best aligns the correlation-magnitude profile
% m(n1-pre : n1+post) with the postamble region around n1 + Dtx (+-win).
pre = min(pre, n1 - 1);                     % frame may start right at sample 1
a = n1 - pre; b = n1 + post;
lo = n1 + Dtx - win - pre; hi = min(n1 + Dtx + win + post, numel(m));
if hi - lo < (b - a)
    D = NaN; return;
end
s1 = m(a:b);
reg = m(lo:hi);
x = real(xcorr_fft(reg, s1));
x = x(1:numel(reg) - numel(s1) + 1);
[~, k] = max(x);
f = 0;
if k > 1 && k < numel(x)
    den = x(k - 1) - 2 * x(k) + x(k + 1);
    if den ~= 0, f = 0.5 * (x(k - 1) - x(k + 1)) / den; end
end
D = (lo + k - 1 + f) - a;
end

function Y = moving_avg_cols(X, A)
% centred moving average over columns (window A, shrinking at the edges)
n = size(X, 2); Y = zeros(size(X)); h = floor(A / 2);
for m = 1:n
    c = max(1, m - h):min(n, m + h);
    Y(:, m) = mean(X(:, c), 2);
end
end

function J = null_energy(zW, tW, e, nb)
% total energy on the null subcarriers after removing a trial CFO e (Hz)
X = fft(zW .* exp(-1j * 2 * pi * e * tW));
J = sum(sum(abs(X(nb, :)).^2));
end
