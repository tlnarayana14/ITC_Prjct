function T = link_sweep(base, variants, snrs, tag)
%LINK_SWEEP Run the full image link for every (variant, SNR) point.
%
%   T = LINK_SWEEP(base, variants, snrs, tag)
%     base     : configuration (number of images, codec, ...)
%     variants : struct array with fields .name and .apply (function handle
%                cfg -> cfg) describing each configuration under test
%     snrs     : SNR values (dB, in-band SNR at the receiver)
%   Every point transmits the SAME base.source.numImages real compressed
%   images (controlled comparison) with seed = base.seed + 1000*v + i.
%   Returns a struct array (one element per point) with summary metrics,
%   raw counts and 95% Wilson intervals for PER and image delivery.
T = struct([]);
for v = 1:numel(variants)
    for i = 1:numel(snrs)
        cfg = variants(v).apply(base);
        cfg.chan.snrDb = snrs(i);
        cfg.out.verbose = 0;
        seed = base.seed + 1000 * v + i;
        set_seed(seed);
        t0 = tic;
        S = run_link_simulation(cfg, struct('tag', tag, 'saveArtifacts', false));
        s = S.summary; P = S.perImage;
        e = struct();
        e.variant = variants(v).name; e.snrDb = snrs(i); e.seed = seed; e.nImages = s.nImages;
        e.packets = s.packets; e.transmissions = s.transmissions;
        e.preErr = sum([P.preErr]); e.preN = sum([P.preN]);
        e.postErr = sum([P.postErr]); e.postN = sum([P.postN]);
        e.BER_pre = s.BER_pre; e.BER_post = s.BER_post;
        e.BER_E2E_total = s.BER_E2E_total; e.BER_E2E_delivered = s.BER_E2E_delivered;
        e.firstFail = sum([P.firstFail]);
        e.PER_initial = s.PER_initial;
        [e.PER_initial_lo, e.PER_initial_hi] = wilson_ci(e.firstFail, s.packets);
        e.PER_attempt = s.PER_attempt; e.PER_final = s.PER_final;
        e.delivered = s.nDelivered; e.deliveryRate = s.deliveryRate;
        [e.delivery_lo, e.delivery_hi] = wilson_ci(s.nDelivered, s.nImages);
        e.undetected = s.undetectedErrPkts;
        e.goodput_bps = s.goodput_bps; e.linkGoodput_bps = s.linkGoodput_bps;
        e.airtime_s = s.airtime_s; e.turnaround_s = s.turnaround_s;
        e.meanDelay_s = s.meanDelay_s;
        e.retxInfoBits = s.overhead.retxInfo; e.feedbackBits = s.overhead.feedback;
        e.payloadBits = s.overhead.payload; e.codedBits = s.overhead.codedTx;
        e.snrEstDb = mean([P.snrEstDb]);
        e.psnr_I_Ir = s.psnr_I_Ir_delivered; e.ssim_I_Ir = s.ssim_I_Ir_delivered;
        e.meanBpp = s.meanBpp;
        e.allIcEqualsIr = s.allDeliveredIcEqualsIr;
        e.runtime_s = toc(t0);
        if isempty(T), T = e; else, T(end + 1) = e; end %#ok<AGROW>
        fprintf('[%s] %-26s SNR %5.1f dB: BERpre %.2e BERpost %.2e PERinit %.3f PERfinal %.3f deliv %d/%d goodput %.0f b/s (%.0f s)\n', ...
            tag, e.variant, e.snrDb, e.BER_pre, e.BER_post, e.PER_initial, e.PER_final, e.delivered, e.nImages, e.linkGoodput_bps, e.runtime_s);
    end
end
end
