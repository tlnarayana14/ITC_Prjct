function [llr, d] = phy_sc_rx(r, meta, cfg)
%PHY_SC_RX Receiver for PHY_SC_TX frames.
%   1. timing synchronisation by matched filtering with the known preamble
%   2. complex gain estimate on the preamble and on every pilot group,
%      linear interpolation of the gain across each data block
%   3. noise variance from the preamble residual (includes any ISI, so the
%      LLRs become correspondingly less confident on multipath channels)
%   4. one-tap equalisation and max-log soft demapping
%   d: n1, noiseVar, snrEstDb, syncOk
sc = cfg.phy.sc;
r = r(:);
pre = det_qpsk_seq(sc.preambleLen, 11);
pil = det_qpsk_seq(sc.blockPilots, 13);
D = sc.blockData; P = sc.blockPilots; Np = sc.preambleLen;
d = struct('n1', NaN, 'noiseVar', NaN, 'snrEstDb', NaN, 'syncOk', true, 'aHat', 0, 'cfoRes_Hz', 0);
c = xcorr_fft(r, pre);
hi = round((cfg.phy.startOffsetMax_s + 0.05) * cfg.phy.B);
[~, n1] = max(abs(c(1:min(hi, numel(c)))));
d.n1 = n1;
need = n1 + meta.len - 1;
if need > numel(r)
    r = [r; zeros(need - numel(r), 1)];
end
z = r(n1:n1 + meta.len - 1);
h0 = (pre' * z(1:Np)) / Np;
nv = mean(abs(z(1:Np) - h0 * pre).^2);
% pilot groups
G = meta.G;
L = P + D;
hp = zeros(G + 1, 1);
pc = zeros(G + 1, 1);               % centre position of each pilot group
for g = 1:G + 1
    a = Np + (g - 1) * L + 1;
    seg = z(a:a + P - 1);
    hp(g) = (pil' * seg) / P;
    pc(g) = a + (P - 1) / 2;
end
pos = zeros(D, G);
for g = 1:G
    pos(:, g) = Np + (g - 1) * L + P + (1:D).';
end
pos = pos(:);
h = interp1(pc, hp, pos, 'linear', 'extrap');
y = z(pos) ./ h;
v = nv ./ max(abs(h).^2, 1e-12);
nData = numel(y) - meta.nFill;
llr = mod_demap(y(1:nData), v(1:nData), cfg.mod.scheme);
llr = llr(1:meta.nBits);
d.noiseVar = nv;
d.snrEstDb = 10 * log10(mean(abs(h).^2) / nv);
end
