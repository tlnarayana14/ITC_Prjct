function code = ldpc_build(rate, Z, seed)
%LDPC_BUILD Deterministic quasi-cyclic LDPC code with 802.11n-style structure.
%
%   code = LDPC_BUILD(rate, Z, seed)
%     rate : 1/2, 2/3, 3/4 or 5/6
%     Z    : circulant (lifting) size; block length N = 24*Z (Z=54 -> N=1296)
%     seed : integer seed of the (RNG-independent) construction
%
%   Base matrix (mb x 24, kb = 24-mb information columns):
%     [ B_info | h_b | dual-diagonal ]
%     B_info : every column has weight wc (3, and 6 for the first kb/4
%              columns at rate 1/2 to make the code irregular); rows
%              degree-balanced; circulant shifts chosen greedily so that
%              the lifted graph has NO 4-cycles (verified after lifting).
%     h_b    : weight-3 column, shift 1 in rows 1 and mb, shift 0 in row
%              floor(mb/2)+1 -> the parity part is invertible.
%     dual-diagonal : identity circulants at (j,j) and (j+1,j).
%   This is the same encoder structure as IEEE 802.11n/ac LDPC codes, which
%   allows linear-time systematic encoding (ldpc_encode.m). The shift values
%   are NOT the standard's tables; the code is generated reproducibly from
%   (rate, Z, seed). Results are cached per argument set.
%
%   Returned struct: N, K, M, rate, Z, kb, mb, base (mb x 24, -1 = zero
%   block), H (sparse), Hi (info part), x (h_b shift), mid (h_b middle row),
%   and decoder edge structures edgeCol, E, CN (M x dcmax, padded with E+1),
%   dcmax, Avar (sparse N x E incidence).

persistent cache
if isempty(cache), cache = struct('key', {}, 'code', {}); end
key = sprintf('%.6f_%d_%d', rate, Z, seed);
for k = 1:numel(cache)
    if strcmp(cache(k).key, key), code = cache(k).code; return; end
end

nb = 24;
mb = round(nb * (1 - rate));
if ~any(abs(rate - [1/2 2/3 3/4 5/6]) < 1e-9)
    error('ldpc_build:rate', 'Unsupported LDPC rate %g (use 1/2, 2/3, 3/4, 5/6).', rate);
end
kb = nb - mb;
M = mb * Z; K = kb * Z; N = nb * Z;
st = mod(seed * 7919 + 12345, 2147483647);

B = -ones(mb, nb);
% ---- parity part (fixed structure)
x = 1; mid = floor(mb / 2) + 1;
B(1, kb + 1) = x; B(mid, kb + 1) = 0; B(mb, kb + 1) = x;
for j = 1:mb - 1
    B(j, kb + 1 + j) = 0;
    B(j + 1, kb + 1 + j) = 0;
end

% ---- information part: column weights and balanced rows
wcol = 3 * ones(1, kb);
if abs(rate - 1/2) < 1e-9
    wcol(1:round(kb / 4)) = 6;       % irregular profile for the low rate
end
rowDeg = sum(B >= 0, 2);
for c = 1:kb
    prio = mod((0:mb - 1).' - (c - 1) * 3, mb) / mb;
    [~, ord] = sort(rowDeg + 0.5 * prio);
    rows = sort(ord(1:wcol(c)));
    B(rows, c) = 0;                  % mark as non-zero, shift assigned below
    rowDeg(rows) = rowDeg(rows) + 1;
end

% ---- circulant shifts for the information columns (greedy 4-cycle avoidance)
assigned = false(1, nb);
assigned(kb + 1:nb) = true;
for c = 1:kb
    rows = find(B(:, c) >= 0).';
    for r = rows
        ok = false;
        for attempt = 1:2000
            st = mod(st * 16807, 2147483647);
            B(r, c) = floor(st / 2147483647 * Z);
            if shift_ok(B, r, c, Z, assigned, rows)
                ok = true; break;
            end
        end
        if ~ok
            error('ldpc_build:girth', 'Could not avoid 4-cycles (Z too small for this profile).');
        end
    end
    assigned(c) = true;
end

% ---- lift: circulant P^s has a one at (i, mod(i+s,Z)) (0-based)
ri = []; ci = [];
t = (0:Z - 1).';
for r = 1:mb
    for c = 1:nb
        s = B(r, c);
        if s < 0, continue; end
        ri = [ri; (r - 1) * Z + t + 1]; %#ok<AGROW>
        ci = [ci; (c - 1) * Z + mod(t + s, Z) + 1]; %#ok<AGROW>
    end
end
H = sparse(ri, ci, 1, M, N);

G = H * H.';
G = G - diag(diag(G));
if full(max(G(:))) > 1
    error('ldpc_build:girth', 'Lifted matrix contains 4-cycles.');
end

[er, ec] = find(H);
[er, ord] = sort(er); ec = ec(ord);
E = numel(er);
dc = accumarray(er, 1, [M 1]);
dcmax = max(dc);
CN = (E + 1) * ones(M, dcmax);
first = [1; cumsum(dc(1:end - 1)) + 1];
for m = 1:M
    CN(m, 1:dc(m)) = first(m):(first(m) + dc(m) - 1);
end
code = struct('N', N, 'K', K, 'M', M, 'rate', K / N, 'Z', Z, 'kb', kb, 'mb', mb, ...
    'base', B, 'x', x, 'mid', mid, 'H', H, 'Hi', H(:, 1:K), 'edgeCol', ec, 'E', E, ...
    'CN', CN, 'dcmax', dcmax, 'Avar', sparse(ec, (1:E).', 1, N, E), 'seed', seed);
cache(end + 1).key = key;
cache(end).code = code;
end

function ok = shift_ok(B, r, c, Z, assigned, rowsC)
% No 4-cycle between base entry (r,c) and any fully assigned column c2,
% nor with an already-assigned entry of the same column (rows before r).
ok = true;
for r2 = rowsC
    if r2 >= r, continue; end      % only rows of column c already assigned
    for c2 = find(assigned)
        if B(r, c2) >= 0 && B(r2, c2) >= 0
            if mod(B(r, c) - B(r2, c) - B(r, c2) + B(r2, c2), Z) == 0
                ok = false; return;
            end
        end
    end
end
end
