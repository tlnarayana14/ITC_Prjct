function test_I_retransmission()
%TEST_I_RETRANSMISSION Injected packet failures trigger selective retransmission
%   of exactly those packets; without ARQ they are reported unrecoverable.
cfg = test_config();
cfg.chan.model = 'ideal';
r = load_image_record(fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_04.jpg'), 0);
enc = source_encode(r.pixels, cfg);
fec = fec_setup(cfg);
bad = [3 10];
% fail packets 3 and 10 in round 1, packet 10 again in round 2
cfg.debug.inject = struct('round', {1, 1, 2}, 'seq', {3, 10, 10}, 'nFlips', {1, 5, 3});
cfg.arq.enabled = true; cfg.arq.maxRetries = 3;
res = transmit_image(enc, 0, cfg, fec, 0);
n = res.nPkts;
check(isequal(find(res.firstAttemptFail) - 1, bad), 'first-attempt failures identified exactly: seq %s', mat2str(find(res.firstAttemptFail) - 1));
check(res.attempts(4) == 2 && res.attempts(11) == 3 && sum(res.attempts) == n + 3, 'only failed packets retransmitted (attempts: seq3=2, seq10=3; total %d = %d + 3)', sum(res.attempts), n);
check(res.success && res.streamIdentical, 'image complete and stream identical after retransmission');
check(res.bits.retxInfo == 3 * 214 * 8, 'retransmitted info bits accounted (%d)', res.bits.retxInfo);
check(nnz(res.segments(:, 1) == 2) == 3, 'three feedback turnarounds (rounds 1-3) in the timeline');
% retry limit
cfg.arq.maxRetries = 1;
res = transmit_image(enc, 0, cfg, fec, 0);
check(~res.delivered(11) && ~res.complete && ~res.success && isempty(res.Ir), 'maxRetries=1: seq 10 unrecoverable, image marked incomplete and not decoded');
check(res.e2e.erased == 8 * 200, 'its %d payload bits are reported as erased (not invented)', res.e2e.erased);
% no ARQ baseline
cfg.arq.enabled = false;
res = transmit_image(enc, 0, cfg, fec, 0);
check(res.PER_final == 2 / n && res.nTransmissions == n && ~res.success, 'no-ARQ baseline: PER_final = 2/%d, no retransmissions, image lost (%s)', n, res.decodeMsg);
end
