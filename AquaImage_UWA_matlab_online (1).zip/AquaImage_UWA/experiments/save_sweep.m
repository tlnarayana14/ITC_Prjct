function save_sweep(T, fname)
%SAVE_SWEEP Write a LINK_SWEEP result struct array to CSV (all scalar fields).
f = fieldnames(T);
keep = {};
for k = 1:numel(f)
    v = T(1).(f{k});
    if ischar(v) || (isnumeric(v) || islogical(v)) && isscalar(v)
        keep{end + 1} = f{k}; %#ok<AGROW>
    end
end
rows = cell(numel(T), numel(keep));
for i = 1:numel(T)
    for k = 1:numel(keep)
        rows{i, k} = T(i).(keep{k});
    end
end
write_csv(fname, keep, rows);
end
