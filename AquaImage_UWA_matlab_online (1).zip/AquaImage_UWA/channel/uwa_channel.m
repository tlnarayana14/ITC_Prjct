function [r, info] = uwa_channel(tx, cfg)
%UWA_CHANNEL Underwater acoustic channel models A-D (complex baseband).
%
%   [r, info] = UWA_CHANNEL(tx, cfg)
%     tx  : PHY_TX output (.x, .fs, .activeMask)
%     cfg.chan.model:
%       'ideal'       no noise, no distortion (used by error-free tests)
%       'awgn'        Model A: additive white Gaussian noise only
%       'multipath'   Model B: + image-method multipath (uwa_multipath_geometry)
%       'doppler'     Model C: + wideband Doppler, r(t) = y((1+a)t) e^{j2pi a fc t},
%                     a = v/c (platform motion, common to all paths)
%       'timevarying' Model D: + independent Rician fading of every path,
%                     Jakes-spectrum (sum-of-sinusoids) scattering component
%                     with maximum Doppler fadingFd_Hz and K-factor ricianK
%       'replay'      Model E: time-varying impulse responses loaded from
%                     cfg.chan.replayFile (format: LOAD_REPLAY_CHANNEL), e.g.
%                     converted measured channel soundings; taps are applied
%                     sample-by-sample with linear interpolation in time and
%                     the record is cycled if shorter than the frame
%   Always: an unknown start offset U(0, startOffsetMax_s) is prepended (the
%   receiver must synchronise) and 0.1 s of silence appended.
%
%   SNR definition (cfg.chan.snrDb): average in-band SNR at the receiver
%       SNR = P_s / (N0 * B),  P_s = mean |x|^2 over the non-silent samples
%   times the (unit) average channel power gain; complex AWGN of variance
%   N0*fs is added over the full simulated bandwidth fs (fs = B for 'sc',
%   2B for 'ofdm'). Propagation loss is NOT applied to the waveform (it is
%   reported in info.TLdB); the SNR is the controlled variable.
%   Fractional path delays are rounded to the nearest sample (1/fs).
%
%   info: model, a, paths (delay_s, gain), noiseVar, offset, TLdB

x = tx.x(:);
fs = tx.fs;
model = lower(cfg.chan.model);
info = struct('model', model, 'a', 0, 'delay_s', 0, 'gain', 1, 'noiseVar', 0, 'offset', 0, 'TLdB', NaN);

off = floor(rand * cfg.phy.startOffsetMax_s * fs);
info.offset = off;
y = [zeros(off, 1); x; zeros(round(0.1 * fs), 1)];
n = numel(y);

if any(strcmp(model, {'multipath', 'doppler', 'timevarying'}))
    pth = uwa_multipath_geometry(cfg);
    info.delay_s = pth.delay_s; info.gain = pth.gain; info.TLdB = pth.TLdB;
    dl = round(pth.delay_s * fs);
    out = zeros(n, 1);
    if strcmp(model, 'timevarying')
        G = fading_gains(numel(dl), n, fs, cfg);      % n x P multiplicative processes
    end
    for q = 1:numel(dl)
        sh = [zeros(dl(q), 1); y(1:n - dl(q))];
        if strcmp(model, 'timevarying')
            out = out + pth.gain(q) * G(:, q) .* sh;
        else
            out = out + pth.gain(q) * sh;
        end
    end
    y = out;
end

if strcmp(model, 'replay')
    rc = load_replay_channel(cfg.chan.replayFile);
    info.TLdB = NaN; info.delay_s = rc.delay_s; info.gain = mean(rc.gains, 2);
    t = (0:n - 1).' / fs;
    tt = mod(t + rand * rc.t_s(end), rc.t_s(end));         % random start in the record
    dl = round(rc.delay_s * fs);
    out = zeros(n, 1);
    for q = 1:numel(dl)
        gq = interp1(rc.t_s(:), rc.gains(q, :).', tt, 'linear', 'extrap');
        sh = [zeros(dl(q), 1); y(1:n - dl(q))];
        out = out + gq .* sh;
    end
    y = out;
end

if any(strcmp(model, {'doppler', 'timevarying'}))
    a = cfg.chan.velocity_mps / cfg.chan.c;
    info.a = a;
    t = (0:n - 1).';
    tq = t * (1 + a);                                   % y((1+a)t)
    yr = interp1(t, real(y), tq, 'spline', 0) + 1j * interp1(t, imag(y), tq, 'spline', 0);
    y = yr .* exp(1j * 2 * pi * a * cfg.phy.fc * t / fs);
end

if ~strcmp(model, 'ideal')
    Ps = mean(abs(x(tx.activeMask)).^2);
    B = cfg.phy.B;
    snr = 10^(cfg.chan.snrDb / 10);
    N0 = Ps / (snr * B);
    nVar = N0 * fs;
    y = y + sqrt(nVar / 2) * (randn(n, 1) + 1j * randn(n, 1));
    info.noiseVar = nVar;
end
r = y;
end

function G = fading_gains(P, n, fs, cfg)
% Rician fading per path: sqrt(K/(K+1)) + sqrt(1/(K+1)) * w(t), with w(t) a
% unit-power sum of 16 sinusoids (Jakes/Clarke model), evaluated on a coarse
% grid (100 Hz) and linearly interpolated to the sample rate.
K = cfg.chan.ricianK; fd = cfg.chan.fadingFd_Hz;
Ns = 16;
tc = (0:0.01:(n / fs + 0.02)).';
G = zeros(n, P);
t = (0:n - 1).' / fs;
for q = 1:P
    th = 2 * pi * rand(1, Ns); ph = 2 * pi * rand(1, Ns); ph2 = 2 * pi * rand(1, Ns);
    w = (sum(cos(2 * pi * fd * tc * cos(th) + ph), 2) + 1j * sum(sin(2 * pi * fd * tc * cos(th) + ph2), 2)) / sqrt(Ns);
    w = interp1(tc, w, t, 'linear');
    G(:, q) = sqrt(K / (K + 1)) + sqrt(1 / (K + 1)) * w;
end
end
