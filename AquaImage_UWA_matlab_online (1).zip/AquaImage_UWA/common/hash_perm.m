function p = hash_perm(n, key)
%HASH_PERM Deterministic pseudo-random permutation of 1..n (RNG-independent).
%   p = HASH_PERM(n, key) uses multiplicative hashing mod 2^32 (Knuth) so the
%   transmitter and receiver derive the same interleaver from a shared key
%   without touching the global random stream. Requires n < 2^21.
k = (1:n).';
h = mod(k * 2654435761 + mod(key, 2^31) * 40503, 2^32);
[~, p] = sort(h);
end
