function T = read_csv_struct(fname)
%READ_CSV_STRUCT Read a CSV written by WRITE_CSV into a struct array.
%   Quoted fields may contain commas; unquoted fields are converted with
%   str2double (non-numeric unquoted text is kept as char).
fid = fopen(fname, 'r');
if fid < 0
    error('read_csv_struct:open', 'Cannot open %s (run the experiment that produces it first).', fname);
end
hdr = strsplit(strtrim(fgetl(fid)), ',');
T = struct([]);
while true
    ln = fgetl(fid);
    if ~ischar(ln), break; end
    if isempty(strtrim(ln)), continue; end
    vals = split_line(ln);
    e = struct();
    for k = 1:numel(hdr)
        v = vals{k};
        if numel(v) >= 2 && v(1) == '"'
            e.(hdr{k}) = strrep(v(2:end - 1), '""', '"');
        else
            d = str2double(v);
            if isnan(d) && ~any(strcmpi(v, {'nan', ''})) && ~strcmpi(v, 'NaN')
                e.(hdr{k}) = v;
            else
                e.(hdr{k}) = d;
            end
        end
    end
    if isempty(T), T = e; else, T(end + 1) = e; end %#ok<AGROW>
end
fclose(fid);
end

function c = split_line(ln)
c = {}; cur = ''; q = false;
for i = 1:numel(ln)
    ch = ln(i);
    if ch == '"'
        q = ~q; cur(end + 1) = ch; %#ok<AGROW>
    elseif ch == ',' && ~q
        c{end + 1} = cur; cur = ''; %#ok<AGROW>
    else
        cur(end + 1) = ch; %#ok<AGROW>
    end
end
c{end + 1} = cur;
end
