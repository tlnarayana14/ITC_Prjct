function pk = packetize(stream, imageId, codecIdVal, cfg)
%PACKETIZE Split a compressed image byte stream into CRC-protected packets.
%
%   pk = PACKETIZE(stream, imageId, codecId, cfg)
%     stream   : uint8 vector, the exact compressed file
%     imageId  : 0..65535
%     codecId  : 1..255 (see codec_id.m)
%     cfg.pkt.payloadBytes : maximum payload per packet (last one may be shorter)
%     cfg.crc.name         : CRC used for every packet
%
%   Packet layout (big-endian, 10-byte header + payload + CRC):
%     byte 1-2   image ID
%     byte 3-4   sequence number (0-based)
%     byte 5-6   total number of packets of this image
%     byte 7-8   payload length L (bytes)
%     byte 9     codec ID
%     byte 10    flags (bit0 = last packet of the image)
%     byte 11..10+L         payload (compressed-stream bytes)
%     final width/8 bytes   CRC over bytes 1..10+L (header AND payload), MSB first
%
%   Returns struct array pk(i) with fields imageId, seq, total, len, codecId,
%   flags, payload (uint8), bytes (full serialized packet, uint8 column),
%   offset (0-based byte offset of the payload in the stream).

stream = uint8(stream(:));
P = cfg.pkt.payloadBytes;
n = numel(stream);
if n == 0
    error('packetize:empty', 'Empty compressed stream.');
end
total = ceil(n / P);
if total > 65535
    error('packetize:toomany', 'Image needs %d packets (>65535); increase payloadBytes.', total);
end
s = crc_spec(cfg.crc.name);
nc = s.width / 8;
pk = struct('imageId', {}, 'seq', {}, 'total', {}, 'len', {}, 'codecId', {}, ...
    'flags', {}, 'payload', {}, 'bytes', {}, 'offset', {});
for q = 0:total - 1
    a = q * P + 1;
    b = min(n, (q + 1) * P);
    pay = stream(a:b);
    L = numel(pay);
    flags = uint8(q == total - 1);
    hdr = [u16(imageId); u16(q); u16(total); u16(L); uint8(codecIdVal); flags];
    body = [hdr; pay];
    c = crc_compute(body, s);
    cb = zeros(nc, 1, 'uint8');
    for k = 1:nc
        cb(k) = uint8(bitand(bitshift(c, -8 * (nc - k)), 255));
    end
    i = q + 1;
    pk(i).imageId = imageId;
    pk(i).seq = q;
    pk(i).total = total;
    pk(i).len = L;
    pk(i).codecId = codecIdVal;
    pk(i).flags = flags;
    pk(i).payload = pay;
    pk(i).bytes = [body; cb];
    pk(i).offset = a - 1;
end
end

function b = u16(v)
v = double(v);
if v < 0 || v > 65535 || v ~= round(v)
    error('packetize:u16', 'Header field %g does not fit in 16 bits.', v);
end
b = uint8([floor(v / 256); mod(v, 256)]);
end
