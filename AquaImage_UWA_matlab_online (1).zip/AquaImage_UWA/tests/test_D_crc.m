function test_D_crc()
%TEST_D_CRC CRC conventions, detection of injected error patterns, overhead.
cfg = test_config();
s32 = crc_spec('CRC-32');
s16 = crc_spec('CRC-16/CCITT-FALSE');
check(crc_compute(uint8('123456789'), s32) == s32.check, 'CRC-32 check value 0xCBF43926');
check(crc_compute(uint8('123456789'), s16) == s16.check, 'CRC-16/CCITT-FALSE check value 0x29B1');

% agreement with an independent implementation (Python zlib.crc32)
msg = uint8(mod((0:199) * 37 + 11, 256));
c = crc_compute(msg, s32);
[st, out] = system(sprintf('python3 -c "import zlib;print(zlib.crc32(bytes([%s])))"', strjoin(arrayfun(@num2str, double(msg), 'UniformOutput', false), ',')));
if st == 0
    check(double(c) == str2double(strtrim(out)), 'CRC-32 equals Python zlib.crc32 (%u)', c);
else
    fprintf('    SKIP: python3 not available for the zlib cross-check\n');
end

% packet level: transmitter and receiver agree on intact packets
r = load_image_record(fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_02.jpg'), 0);
e = source_encode(r.pixels, cfg);
pk = packetize(e.bytes, 1, e.codecId, cfg);
check(all(arrayfun(@(p) parse_packet(p.bytes, cfg).crcOk, pk)), 'all %d intact packets pass CRC at the receiver', numel(pk));
b0 = pk(1).bytes;
nb = 8 * numel(b0);

% every single-bit error (guaranteed detectable by CRC-32)
undet1 = 0;
for k = 1:nb
    bb = flip_bits(b0, k);
    undet1 = undet1 + parse_packet(bb, cfg).crcOk;
end
check(undet1 == 0, 'all %d single-bit errors detected', nb);
% bursts of length <= 32 (guaranteed), all start positions
undetB = 0; nB = 0;
for L = [2 5 17 32]
    for k = 1:8:nb - L
        bb = flip_bits(b0, [k, k + L - 1, k + floor(L / 2)]);
        undetB = undetB + parse_packet(bb, cfg).crcOk; nB = nB + 1;
    end
end
check(undetB == 0, 'all %d tested burst patterns (span <= 32) detected', nB);
% random multi-bit patterns: detection is probabilistic (~2^-32 miss rate)
set_seed(5);
undetR = 0; T = 3000;
for t = 1:T
    w = randi([2 40]);
    bb = flip_bits(b0, randperm(nb, w));
    undetR = undetR + parse_packet(bb, cfg).crcOk;
end
check(undetR == 0, '%d random 2..40-bit error patterns: %d undetected (expected ~%.1e)', T, undetR, T * 2^-32);
% overhead accounting
check(numel(b0) - cfg.pkt.headerBytes - pk(1).len == 4, 'CRC-32 adds exactly 4 bytes per packet');
check(cfg.derived.packetBytes == 214, 'derived full packet size 10+200+4 = 214 bytes');
end

function b = flip_bits(b, pos)
bits = bytes_to_bits(b);
bits(pos) = 1 - bits(pos);
b = bits_to_bytes(bits);
end
