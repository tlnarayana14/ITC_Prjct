% MAIN  AquaImage_UWA - end-to-end underwater still-image transmission simulation.
%
%   Run from the project folder:   >> main
%   (MATLAB R2019b+ or GNU Octave >= 7; no toolboxes required.
%    JPEG XL needs the libjxl tools cjxl/djxl on the system path.)
%
%   Pipeline: camera schedule -> load/preprocess -> real source encoder ->
%   exact compressed bytes -> packetization (header, CRC-32) -> LDPC/polar
%   encoding with shortening -> interleaving -> QPSK -> OFDM (or SC) frame ->
%   underwater acoustic channel -> sync, Doppler/CFO compensation, channel
%   estimation, equalisation -> soft demapping -> deinterleaving -> channel
%   decoding -> CRC verification -> selective-repeat ARQ -> reassembly ->
%   source decoding -> I / I_c / I_r comparison -> BER, PER, PSNR, SSIM,
%   goodput, delay and queue metrics.
%
%   Edit the overrides below (or default_config.m) to change the scenario.

clear; close all;
root = setup_paths();
cfg = default_config();

% ---------------- scenario overrides (documented defaults otherwise) ----
cfg.source.numImages = 3;          % camera frames to simulate
cfg.source.interval_s = 1.0;       % one image per second
cfg.codec.name = 'jpeg';           % 'jpeg' | 'jpegxl' | 'png'
cfg.codec.jpegQuality = 50;
cfg.fec.code = 'ldpc'; cfg.fec.rate = 1/2;
cfg.mod.scheme = 'qpsk';
cfg.phy.type = 'ofdm';
cfg.chan.model = 'multipath';      % 'awgn' | 'multipath' | 'doppler' | 'timevarying'
cfg.chan.snrDb = 8;
cfg.arq.enabled = true; cfg.arq.maxRetries = 3;
% -------------------------------------------------------------------------

cfg = validate_config(cfg);
set_seed(cfg.seed);
fprintf('AquaImage_UWA | %s | codec=%s | FEC=%s R=%.3f | %s | PHY=%s | channel=%s @ %.1f dB\n', ...
    ternary(is_octave(), 'GNU Octave', 'MATLAB'), cfg.codec.name, cfg.fec.code, cfg.fec.rate, ...
    cfg.mod.scheme, cfg.phy.type, cfg.chan.model, cfg.chan.snrDb);

S = run_link_simulation(cfg, struct('tag', 'main'));

% ---------------- save results ------------------------------------------
logDir = fullfile(cfg.out.resultsDir, 'logs');
if exist(logDir, 'dir') ~= 7, mkdir(logDir); end
fid = fopen(fullfile(logDir, 'main_summary.json'), 'w');
fprintf(fid, '%s', jsonencode(S.summary));
fclose(fid);
P = S.perImage;
hdr = {'id', 'file', 'codec', 'compBytes', 'CR', 'bpp', 'nPkts', 'PER_initial', 'PER_final', ...
    'BER_pre', 'BER_post', 'success', 'streamIdentical', 'psnr_I_Ic', 'psnr_I_Ir', 'psnr_Ic_Ir', ...
    'ssim_I_Ic', 'ssim_I_Ir', 'airtime_s', 'delay_s'};
rows = cell(numel(P), numel(hdr));
for k = 1:numel(P)
    [~, fn, fe] = fileparts(P(k).file);
    rows(k, :) = {P(k).id, [fn fe], P(k).codec, P(k).compBytes, P(k).CR, P(k).bpp, P(k).nPkts, ...
        P(k).PER_initial, P(k).PER_final, P(k).preErr / P(k).preN, P(k).postErr / P(k).postN, ...
        P(k).success, P(k).streamIdentical, P(k).psnr_I_Ic, P(k).psnr_I_Ir, P(k).psnr_Ic_Ir, ...
        P(k).ssim_I_Ic, P(k).ssim_I_Ir, P(k).airtime_s, P(k).delay_s};
end
write_csv(fullfile(cfg.out.resultsDir, 'tables', 'main_per_image.csv'), hdr, rows);

if cfg.out.makePlots
    plot_side_by_side(S, fullfile(cfg.out.resultsDir, 'figures', 'main_side_by_side.png'));
end

s = S.summary;
fprintf('\n===== SUMMARY =====\n');
fprintf('images generated %d | delivered & decoded %d (%.0f%%) | dropped %d\n', s.nImages, s.nDelivered, 100 * s.deliveryRate, s.nDropped);
fprintf('BER pre-decoding %.3e | post-decoding %.3e | E2E(delivered) %.3e | erasure %.3e\n', s.BER_pre, s.BER_post, s.BER_E2E_delivered, s.erasureRate);
fprintf('PER initial %.4f | per attempt %.4f | final %.4f | CRC-undetected packets %d\n', s.PER_initial, s.PER_attempt, s.PER_final, s.undetectedErrPkts);
fprintf('mean CR %.2f (%.3f bpp) | PSNR(I,Ic) %.2f dB | PSNR(I,Ir) %.2f dB | Ir==Ic for all delivered: %d\n', s.meanCR, s.meanBpp, s.psnr_I_Ic, s.psnr_I_Ir_delivered, s.allDeliveredIcEqualsIr);
fprintf('airtime %.1f s | goodput %.0f bit/s (link %.0f bit/s) | mean delay %.1f s | max queue %d\n', s.airtime_s, s.goodput_bps, s.linkGoodput_bps, s.meanDelay_s, s.maxQueue);
