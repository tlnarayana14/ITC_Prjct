function fec = fec_setup(cfg)
%FEC_SETUP Build the channel code selected in cfg.fec (common interface).
%   fec.type : 'ldpc' | 'polar' | 'none'
%   fec.K, fec.N : information / coded bits per block (N = K = 1 for 'none')
%   fec.rate     : nominal K/N
%   fec.code     : code-specific struct (ldpc_build / polar_construct output)
%   fec.maxIter, fec.alpha : LDPC decoder settings
fec.type = lower(cfg.fec.code);
fec.maxIter = cfg.fec.maxIter;
fec.alpha = cfg.fec.alpha;
switch fec.type
    case 'ldpc'
        fec.code = ldpc_build(cfg.fec.rate, cfg.fec.ldpcZ, cfg.fec.ldpcSeed);
        fec.K = fec.code.K; fec.N = fec.code.N;
        fec.desc = sprintf('QC-LDPC N=%d K=%d (R=%s), normalised min-sum alpha=%.2f, max %d it', ...
            fec.N, fec.K, rate_str(fec.K / fec.N), fec.alpha, fec.maxIter);
    case 'polar'
        N = cfg.fec.polarN;
        K = round(cfg.fec.rate * N);
        fec.code = polar_construct(N, K, cfg.fec.polarDesignSNRdB);
        fec.K = K; fec.N = N;
        fec.desc = sprintf('Polar N=%d K=%d, SC decoding, design SNR %g dB', N, K, cfg.fec.polarDesignSNRdB);
    case 'polar_scl'
        N = cfg.fec.polarN;
        K = round(cfg.fec.rate * N);
        fec.code = polar_construct(N, K, cfg.fec.polarDesignSNRdB);
        fec.K = K - 16; fec.N = N;              % 16 CRC bits per block are overhead
        fec.L = cfg.fec.polarListL;
        fec.desc = sprintf('Polar N=%d K=%d (incl. CRC-16), CA-SCL list %d', N, K, fec.L);
    case 'rs'
        t = cfg.fec.rsT;
        fec.code = struct('t', t, 'kmax', 255 - 2 * t);
        fec.K = 8 * (255 - 2 * t); fec.N = 8 * 255;
        fec.desc = sprintf('Reed-Solomon RS(255,%d) over GF(256), shortened per packet, hard-decision BM decoding', 255 - 2 * t);
    case 'none'
        fec.code = [];
        fec.K = 1; fec.N = 1;
        fec.desc = 'uncoded';
    otherwise
        error('fec_setup:type', 'Unknown channel code %s', fec.type);
end
fec.rate = fec.K / fec.N;
end
