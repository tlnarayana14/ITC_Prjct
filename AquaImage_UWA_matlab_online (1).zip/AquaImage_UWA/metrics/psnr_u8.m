function p = psnr_u8(A, B)
%PSNR_U8 Peak signal-to-noise ratio (dB) between two uint8 images.
%   p = PSNR_U8(A, B) with MAX = 255 and MSE over ALL samples (all colour
%   channels). Identical images give Inf. Sizes must match exactly (no
%   implicit alignment is performed).
if ~isequal(size(A), size(B))
    error('psnr_u8:size', 'Image sizes differ: %s vs %s', mat2str(size(A)), mat2str(size(B)));
end
mse = mean((double(A(:)) - double(B(:))).^2);
if mse == 0
    p = Inf;
else
    p = 10 * log10(255^2 / mse);
end
end
