function U = jscc_utility(rows, qs, Rs, snrs, deadlines)
%JSCC_UTILITY Deadline utility of every (SNR, deadline, quality, rate) point.
%   rows: per-image cells from Exp 7 {snr, q, R, image, bytes, bpp, success,
%   latency, ssim_I_Ic, psnr_I_Ic, airtime, turnaround, PER, snrEst}.
%   U rows: {snr, deadline, q, R, onTimeRate, meanSsimOnTime, utility,
%   meanLatency (delivered images), mean estimated SNR}.
S = cell2mat(rows(:, [1 2 3 7 8 9 14]));
U = {};
for s = snrs
    for Tb = deadlines
        for q = qs
            for Rc = Rs
                m = S(:, 1) == s & S(:, 2) == q & abs(S(:, 3) - Rc) < 1e-9;
                x = S(m, :);
                onTime = x(:, 4) == 1 & x(:, 5) <= Tb;
                util = mean(onTime .* x(:, 6));
                lat = x(x(:, 4) == 1, 5);
                if isempty(lat), lat = NaN; end
                ss = x(onTime, 6); if isempty(ss), ss = NaN; end
                U(end + 1, :) = {s, Tb, q, Rc, mean(onTime), mean(ss), util, mean(lat), mean(x(:, 7))}; %#ok<AGROW>
            end
        end
    end
end
end
