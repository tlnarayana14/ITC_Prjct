function dec = jscc_controller(state, U, deadline, fallback)
%JSCC_CONTROLLER Joint source/channel operating-point selection (Exp 10).
%
%   dec = JSCC_CONTROLLER(state, U, deadline, fallback)
%     state.lastSnrEstDb : previous image's receiver SNR estimate (feedback)
%     U        : Exp-7 utility table (JSCC_UTILITY rows) measured offline
%     deadline : per-image latency deadline (s); must be a deadline in U
%     fallback : struct(jpegQuality, rate) used before any estimate exists
%   Rule: map the estimate to the highest Exp-7 SNR bucket whose MEAN
%   ESTIMATED SNR does not exceed it (conservative), then pick the (quality,
%   rate) pair with the largest measured utility at that bucket/deadline;
%   ties are broken towards the more robust (lower) code rate.
dec = fallback;
s = state.lastSnrEstDb;
if isnan(s), return; end
M = cell2mat(U(:, [1 2 3 4 7 9]));
M = M(M(:, 2) == deadline, :);
buckets = unique(M(:, 1));
est = arrayfun(@(b) mean(M(M(:, 1) == b, 6)), buckets);
k = find(est <= s, 1, 'last');
if isempty(k), k = 1; end
X = M(M(:, 1) == buckets(k), :);
best = max(X(:, 5));
cand = X(X(:, 5) >= best - 1e-12, :);
[~, i] = min(cand(:, 4));
dec.jpegQuality = cand(i, 3);
dec.rate = cand(i, 4);
end
