function test_C_packetization()
%TEST_C_PACKETIZATION Packetize / reassemble, including adverse arrival patterns.
cfg = test_config();
r = load_image_record(fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_11.jpg'), 0);
e = source_encode(r.pixels, cfg);
s = e.bytes;
pk = packetize(s, 7, e.codecId, cfg);
n = numel(pk);
P = cfg.pkt.payloadBytes;
check(n == ceil(numel(s) / P), '%d packets for %d bytes at %d B payload', n, numel(s), P);
check(pk(end).len == numel(s) - (n - 1) * P && pk(end).len <= P, 'last packet carries the remaining %d bytes', pk(end).len);
check(all(arrayfun(@(p) numel(p.bytes), pk(1:end - 1)) == cfg.pkt.headerBytes + P + 4), 'packet size = 10 B header + payload + 4 B CRC');
rx = arrayfun(@(p) parse_packet(p.bytes, cfg), pk);
check(all([rx.valid]), 'all intact packets parse with valid CRC and length');
[st, rep] = reassemble_packets(rx, 7, cfg);
check(rep.complete && isequal(st, s), 'in-order reassembly reproduces the exact stream');

% shuffled + duplicated + a packet of another image
perm = hash_perm(n, 3);
other = packetize(s(1:300), 8, e.codecId, cfg);
rx2 = [rx(perm), rx([2 5]), parse_packet(other(1).bytes, cfg)];
[st2, rep2] = reassemble_packets(rx2, 7, cfg);
check(rep2.complete && isequal(st2, s), 'out-of-order + duplicates + foreign packet still reassemble exactly');
check(rep2.outOfOrder > 0, 'out-of-order arrivals detected (%d)', rep2.outOfOrder);
check(rep2.duplicates == 2 && rep2.duplicateConflicts == 0, 'two duplicates detected, no conflicts');
check(rep2.otherImage == 1, 'packet of another image ID ignored');

% missing packets
[st3, rep3] = reassemble_packets(rx([1:2, 5:n]), 7, cfg);
check(~rep3.complete && isempty(st3) && isequal(rep3.missing, [2 3]), 'missing packets 2,3 reported, no stream returned (%s)', rep3.reason);

% corrupted payload byte -> CRC failure
b = pk(4).bytes; b(20) = bitxor(b(20), uint8(16));
pc = parse_packet(b, cfg);
check(~pc.crcOk && ~pc.valid, 'single corrupted byte fails CRC');
[~, rep4] = reassemble_packets([rx(1:3), pc, rx(5:end)], 7, cfg);
check(~rep4.complete && rep4.crcFailures == 1 && isequal(rep4.missing, 3), 'corrupted packet counted as CRC failure and reported missing');

% invalid length field with a recomputed (valid) CRC
bad = pk(1).bytes(1:end - 4);
bad(7:8) = uint8([255 255]);
cs = crc_spec(cfg.crc.name); c = crc_compute(bad, cs);
bad = [bad; uint8(bitand(bitshift(c, -[24; 16; 8; 0]), 255))];
pb = parse_packet(bad, cfg);
check(pb.crcOk && ~pb.lenOk && ~pb.valid, 'length field inconsistent with packet size is rejected despite valid CRC');

% incomplete image: nothing valid
[st5, rep5] = reassemble_packets(pc, 7, cfg);
check(~rep5.complete && isempty(st5), 'no valid packet -> incomplete (%s)', rep5.reason);
end
