function test_B_bitstream()
%TEST_B_BITSTREAM Compressed bytes -> bits -> bytes is the identity; MSB-first order.
cfg = test_config();
r = load_image_record(fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_07.jpg'), 0);
e = source_encode(r.pixels, cfg);
b = bytes_to_bits(e.bytes);
check(numel(b) == 8 * numel(e.bytes), 'bit count = 8 x byte count (%d bits)', numel(b));
check(isequal(bits_to_bytes(b), e.bytes), 'actual JPEG stream survives bytes->bits->bytes unchanged');
check(isequal(bytes_to_bits(uint8(128)).', [1 0 0 0 0 0 0 0]), '0x80 serialises MSB first');
check(isequal(bytes_to_bits(uint8([1 255])).', [0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1]), '[0x01 0xFF] serialises correctly');
check(e.bytes(1) == 255 && e.bytes(2) == 216, 'stream starts with the JPEG SOI marker FF D8 (real codec output)');
end
