function bits = bytes_to_bits(bytes)
%BYTES_TO_BITS Convert a uint8 vector to a column of bits (0/1, double), MSB first.
%   Serialization convention used everywhere in the project: byte k occupies
%   bits 8k-7 .. 8k, most-significant bit first.
bytes = double(bytes(:));
n = numel(bytes);
w = 2 .^ (7:-1:0);
bits = mod(floor(bytes * (1 ./ w)), 2);     % n x 8, MSB first
bits = reshape(bits.', 8 * n, 1);
end
