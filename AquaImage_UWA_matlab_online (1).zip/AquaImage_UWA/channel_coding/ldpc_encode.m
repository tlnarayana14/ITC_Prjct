function cw = ldpc_encode(code, u)
%LDPC_ENCODE Systematic linear-time encoding for the dual-diagonal QC structure.
%
%   cw = LDPC_ENCODE(code, u)   u: K x B bits (0/1)  ->  cw: N x B = [u; p0; p1..p_{mb-1}]
%
%   With lambda_i = (H_info * u) restricted to base row i (Z bits):
%     p0      = sum_i lambda_i                  (h_b column; the two P^x terms cancel)
%     p1      = lambda_1 + P^x p0
%     p_j     = lambda_j + p_{j-1} + [j == mid] p0,   j = 2..mb-1
%   where P^s v = circshift(v, -s) for the circulant convention of ldpc_build.
%   The result always satisfies H*cw = 0 (mod 2); tests/test_E_channel_coding.m checks it.
if size(u, 1) ~= code.K
    error('ldpc_encode:size', 'Expected %d information bits per column, got %d.', code.K, size(u, 1));
end
Z = code.Z; mb = code.mb; Bn = size(u, 2);
lam = mod(code.Hi * double(u), 2);
lam = reshape(lam, Z, mb, Bn);
p0 = mod(sum(lam, 2), 2);                       % Z x 1 x B
pxp0 = circshift(p0, -code.x, 1);
P = zeros(Z, mb - 1, Bn);
P(:, 1, :) = mod(lam(:, 1, :) + pxp0, 2);
for j = 2:mb - 1
    v = lam(:, j, :) + P(:, j - 1, :);
    if j == code.mid
        v = v + p0;
    end
    P(:, j, :) = mod(v, 2);
end
cw = [double(u); reshape(p0, Z, Bn); reshape(P, Z * (mb - 1), Bn)];
end
