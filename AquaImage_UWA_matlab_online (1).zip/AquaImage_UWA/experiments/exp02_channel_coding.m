function T = exp02_channel_coding()
%EXP02_CHANNEL_CODING Experiment 2: uncoded vs LDPC vs polar, same packets.
%   OFDM/QPSK, ARQ off, AWGN and image-method multipath, SNR -2..14 dB.
%   Metrics: BER_pre, BER_post, PER (first attempt), image delivery.
base = experiment_base();
snrs = -2:2:14;
v = struct('name', {}, 'apply', {});
v(end + 1) = struct('name', 'uncoded', 'apply', @(c) setf(c, 'none', 1/2));
v(end + 1) = struct('name', 'LDPC R=1/2 (N=1296)', 'apply', @(c) setf(c, 'ldpc', 1/2));
v(end + 1) = struct('name', 'polar R=1/2 (N=1024, SC)', 'apply', @(c) setf(c, 'polar', 1/2));
v(end + 1) = struct('name', 'LDPC R=3/4 (N=1296)', 'apply', @(c) setf(c, 'ldpc', 3/4));
T = struct([]);
for ch = {'awgn', 'multipath'}
    b = base; b.chan.model = ch{1};
    Tc = link_sweep(b, v, snrs, ['exp02_' ch{1}]);
    [Tc.channel] = deal(ch{1});
    if isempty(T), T = Tc; else, T = [T, Tc]; end %#ok<AGROW>
    rd = fullfile(base.out.resultsDir);
    save_sweep(Tc, fullfile(rd, 'tables', sprintf('exp02_coding_%s.csv', ch{1})));
    fd = fullfile(rd, 'figures');
    plot_sweep(Tc, 'BER_pre', 'pre-decoding BER (coded bits)', sprintf('Exp 2: pre-decoding BER, OFDM/QPSK, %s', ch{1}), fullfile(fd, sprintf('exp02_ber_pre_%s.png', ch{1})), true, 1e-7);
    plot_sweep(Tc, 'BER_post', 'post-decoding BER (packet bits)', sprintf('Exp 2: post-decoding BER, %s', ch{1}), fullfile(fd, sprintf('exp02_ber_post_%s.png', ch{1})), true, 1e-7);
    plot_sweep(Tc, 'PER_initial', 'packet error rate (CRC failures)', sprintf('Exp 2: PER, no ARQ, %s', ch{1}), fullfile(fd, sprintf('exp02_per_%s.png', ch{1})), true, 1e-4);
    plot_sweep(Tc, 'deliveryRate', 'image delivery success rate', sprintf('Exp 2: images delivered, no ARQ, %s', ch{1}), fullfile(fd, sprintf('exp02_delivery_%s.png', ch{1})), false);
end
end

function c = setf(c, code, rate)
c.fec.code = code; c.fec.rate = rate;
end
