function tx = phy_sc_tx(bits, cfg)
%PHY_SC_TX Single-carrier baseline frame (one sample per symbol, fs = B).
%
%   Frame: [preamble (Np known QPSK) | {P pilots, D data} x G | P pilots | guard]
%   The pilot groups let the receiver track a slowly varying complex gain.
%   This baseline has NO multipath equaliser: it is intended for the AWGN /
%   flat-channel validation (Model A) and as a reference showing why OFDM
%   (or an adaptive equaliser) is needed on frequency-selective channels.
%   Ideal Nyquist pulse shaping is assumed (symbol-spaced model).
sc = cfg.phy.sc;
[sym, nPad] = mod_map(bits, cfg.mod.scheme);
D = sc.blockData; P = sc.blockPilots;
G = ceil(numel(sym) / D);
nFill = G * D - numel(sym);
fillSym = det_qpsk_seq(max(nFill, 1), 5);
sym = [sym; fillSym(1:nFill)];
pre = det_qpsk_seq(sc.preambleLen, 11);
pil = det_qpsk_seq(P, 13);
S = reshape(sym, D, G);
body = [repmat(pil, 1, G); S];
body = [body(:); pil];
fs = cfg.phy.B;
x = [pre; body; zeros(round(cfg.phy.guard_s * fs), 1)];
tx.x = x;
tx.fs = fs;
tx.duration_s = numel(x) / fs;
tx.nDataSym = numel(sym) - nFill;
tx.meta = struct('type', 'sc', 'nBits', numel(bits), 'nPad', nPad, 'G', G, 'nFill', nFill, ...
    'len', numel(x));
tx.activeMask = abs(x) > 0;
end
