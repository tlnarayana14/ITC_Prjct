function tx = phy_tx(bits, cfg)
%PHY_TX Physical-layer transmitter dispatcher ('sc' or 'ofdm').
%   tx = PHY_TX(bits, cfg) -> struct with .x, .fs, .duration_s, .meta, .nDataSym
switch lower(cfg.phy.type)
    case 'sc',   tx = phy_sc_tx(bits, cfg);
    case 'ofdm', tx = phy_ofdm_tx(bits, cfg);
    otherwise, error('phy_tx:type', 'Unknown PHY %s', cfg.phy.type);
end
end
