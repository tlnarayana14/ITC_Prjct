function [pts, labels, m] = mod_constellation(scheme)
%MOD_CONSTELLATION Gray-labelled constellation with unit average energy.
%   [pts, labels, m] = MOD_CONSTELLATION(scheme)
%     pts    : 1 x Mc complex points, mean(|pts|^2) = 1
%     labels : Mc x m bits; bit order within a symbol is MSB first, i.e.
%              coded bits [b1 b2 ... bm] map to one symbol in that order.
%   'bpsk'  : b -> 1-2b (real)
%   'qpsk'  : [b1 b2] -> ((1-2b1) + j(1-2b2))/sqrt(2)
%   '16qam' : [b1 b2 b3 b4] -> (A(b1,b2) + j A(b3,b4))/sqrt(10),
%             A = (1-2x)(3-2y): 00->+3, 01->+1, 11->-1, 10->-3 (Gray)
switch lower(scheme)
    case 'bpsk'
        m = 1; labels = [0; 1]; pts = [1 -1];
    case 'qpsk'
        m = 2; labels = [0 0; 0 1; 1 0; 1 1];
        pts = ((1 - 2 * labels(:, 1)) + 1j * (1 - 2 * labels(:, 2))).' / sqrt(2);
    case '16qam'
        m = 4;
        labels = zeros(16, 4);
        for k = 0:15
            labels(k + 1, :) = bitand(k, [8 4 2 1]) > 0;
        end
        A = @(x, y) (1 - 2 * x) .* (3 - 2 * y);
        pts = (A(labels(:, 1), labels(:, 2)) + 1j * A(labels(:, 3), labels(:, 4))).' / sqrt(10);
    otherwise
        error('mod_constellation:scheme', 'Unknown modulation %s', scheme);
end
end
