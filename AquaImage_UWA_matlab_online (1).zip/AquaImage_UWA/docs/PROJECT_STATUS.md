# Project status — AquaImage_UWA

Legend: ✅ implemented **and** executed/tested here · 🟡 implemented, executed with a
documented limitation · ⛔ not done / not executed (reason given).
Execution environment: GNU Octave 8.4.0, libjxl 0.7.0, Python 3.13 (cross-checks).

## Stage log

| Stage | Implemented | Tests | Outcome |
|---|---|---|---|
| 1 Baseline | config, source, JPEG/PNG, bitstream, packets+CRC-32, QC-LDPC, QPSK, SC PHY, AWGN, receiver, reassembly, metrics, `main.m` | P1, A–F, K | first end-to-end image delivered bit-exactly |
| 2 Extensions | JPEG XL, CP-OFDM (sync, Doppler, CFO, channel est.), multipath/Doppler/time-varying channels, polar SC, interleaver, SR-ARQ, queue | G–M, X | all pass after 4 fixes (LDPC structure, estimator loss, Doppler outliers, sync edge case) |
| 3 Experiments | Exp 1–10, adaptation controllers, figures, tables | — | all executed; Exp 5 over 5 SNR traces, Exp 10 over 5 |
| 4 Documentation | README, literature review, technical report, this file | — | done |
| 5 Second iteration | stream CRC, channel replay (Model E), RS(255,223), CA-SCL polar, fountain code, ROI + UEP + ROI-only ARQ, AMC (QPSK/16QAM) + v2 controller, Deep JSCC (trained + evaluated through the real receiver), requirements trace | N, O, P, Q (+ E, K additions) | Exp 5b, 11, 12, 13 executed |

## Completion checklist

**Image source**
- ✅ Multiple still images load (23 EUVP + 6 format-test images)
- ✅ JPEG, PNG, BMP, TIFF (8- and 16-bit), grayscale, non-square
- ✅ Continuous source model (configurable interval, FIFO queue)
- ✅ Image IDs and arrival times tracked

**Source coding**
- ✅ Real codecs integrated: JPEG, JPEG XL (libjxl), PNG lossless
- 🟡 Pretrained learned codec (CompressAI) not executed — weights unreachable; ✅ instead a **Deep JSCC** model was trained here and evaluated (Exp 12)
- ✅ Compressed bitstreams preserved byte-exactly
- ✅ Compression metrics (size, CR, bpp, PSNR, SSIM, times, BD-rate)

**Packetization**
- ✅ Packets with image ID, sequence, total, length, codec ID, flags
- ✅ CRC-32 generated and verified (cross-checked with zlib)
- ✅ Missing, duplicate, out-of-order, bad-length, foreign packets handled

**Channel coding**
- ✅ QC-LDPC (rates 1/2, 2/3, 3/4, 5/6), polar (SC), uncoded
- ✅ Encoding/decoding tested; framing with shortening documented
- 🟡 LDPC tables are our own 802.11n-structured family, not the standard's
- ✅ Reed–Solomon RS(255,223) (Exp 13A); ✅ CA-SCL polar; ✅ fountain erasure code (Exp 13B)

**Physical layer**
- ✅ Gray BPSK/QPSK/16QAM mapping + max-log LLRs
- ✅ CP-OFDM with LFM sync, Doppler resampling, CFO search, sparse LS channel estimation
- ✅ Single-carrier baseline (🟡 no multipath equaliser, by design)
- ✅ AWGN validated against theory; multipath, Doppler, time-varying models
- 🟡 Model E: replay interface validated with a synthetic file (no measured data offline)
- ✅ Adaptive modulation QPSK/16QAM (Exp 5b)

**Receiver**
- ✅ Channel decoding, CRC verification, failed-packet identification
- ✅ Selective-repeat ARQ (🟡 error-free feedback channel assumed)
- ✅ Bit-exact stream reassembly

**Reconstruction**
- ✅ Real decoding of received streams; artefacts saved
- ✅ I / I_c / I_r three-way comparison
- ✅ Incomplete images reported, never decoded or filled in

**Metrics**
- ✅ BER_pre, BER_post, BER_E2E (delivered / total with erasures), PER (initial / per attempt / final)
- ✅ PSNR, SSIM (luma; equal to scikit-image to 1e-6), CR
- ✅ Goodput (several denominators, documented) and delay (queue model)

**Experiments**
- ✅ Exp 1 codec comparison (🟡 learned codec missing)
- ✅ Exp 2 channel codes, Exp 3 SNR sweep, Exp 4 channel models
- ✅ Exp 5 fixed vs adaptive LDPC, Exp 6 ARQ, Exp 7 source × channel rate
- ✅ Exp 8 queue stability, Exp 9 23-image end-to-end, Exp 10 JSCC extension
- ✅ Seeds logged; Wilson CIs for proportions

**Deliverables**
- ✅ Source code, `main.m`, config, tests, reconstructed images, figures, tables
- ✅ README with installation, technical report, limitations and future work
- 🟡 MATLAB execution untested (no MATLAB licence in the environment)

## Known open items (next concrete actions)

1. Run `run_all_tests` and `main` in MATLAB and record any incompatibility.
2. Load measured channel soundings into Model E (format in `load_replay_channel.m`).
3. Train Deep JSCC at scale (GPU, thousands of underwater images) and add a
   hybrid Deep-JSCC / digital switching controller.
4. Execute pretrained learned codecs where weights can be downloaded (Exp 1).
5. Adapt fountain redundancy to the measured loss rate.
