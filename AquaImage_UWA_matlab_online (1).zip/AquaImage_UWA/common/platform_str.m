function s = platform_str()
%PLATFORM_STR 'GNU Octave x.y.z' or 'MATLAB <version>' (safe in both:
%   OCTAVE_VERSION is only referenced when running in Octave).
if is_octave()
    s = ['GNU Octave ' feval('OCTAVE_VERSION')];
else
    s = ['MATLAB ' version];
end
end
