function test_N_replay_channel()
%TEST_N_REPLAY_CHANNEL Model E interface: a replay file is loaded, validated,
%   applied, and the OFDM link delivers a real image through it.
cfg = test_config();
f = make_replay_example(cfg, fullfile(cfg.root, 'data', 'channels', 'replay_example_synthetic.mat'), 30);
rc = load_replay_channel(f);
check(abs(mean(sum(abs(rc.gains).^2, 1)) - 1) < 1e-9, 'replay gains normalised to unit average power (%d taps, %d time samples)', numel(rc.delay_s), numel(rc.t_s));
try
    bad = fullfile(cfg.codec.tmpDir, 'bad_replay.mat'); delay_s = [0; 1e-3]; gains = ones(3, 4); t_s = 0:3; %#ok<NASGU>
    save(bad, 'delay_s', 'gains', 't_s', '-v7');
    load_replay_channel(bad);
    check(false, 'malformed replay file must be rejected');
catch err
    check(~isempty(strfind(err.message, 'P x T')), 'malformed replay file rejected: "%s"', err.message);
end
cfg.chan.model = 'replay'; cfg.chan.replayFile = f; cfg.chan.snrDb = 12;
set_seed(19);
S = run_link_simulation(cfg, struct('tag', 'test_N', 'saveArtifacts', false));
e = S.perImage(1);
check(e.success && e.IcEqualsIr, 'image delivered through the replayed channel at 12 dB (BER_pre %.2e -> BER_post %.1e)', e.preErr / e.preN, e.postErr / e.postN);
end
