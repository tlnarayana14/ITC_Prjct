function S = run_link_simulation(cfg, opts)
%RUN_LINK_SIMULATION Complete end-to-end run over the continuous image source.
%
%   S = RUN_LINK_SIMULATION(cfg, opts)
%     opts.tag           results sub-folder name (default 'main')
%     opts.saveArtifacts save per-image artefacts (default cfg.out.saveImages)
%     opts.snrTrace      optional vector: SNR (dB) used for image k
%                        (time-varying link quality; overrides cfg.chan.snrDb)
%     opts.controller    optional function handle @(state) -> struct with
%                        fields rate / jpegQuality / jxlDistance (adaptation)
%   Pipeline per image (in camera order):
%     load -> preprocess -> source_encode (real codec, local decode I_c) ->
%     transmit_image (packetize, CRC, channel code, interleave, PHY, channel,
%     receiver, decode, CRC check, ARQ, reassembly, source decode) ->
%     three-way quality comparison
%   then the queue/timeline simulation and aggregate metrics.
%   Returns S.perImage (struct array), S.summary, S.timeline, S.cfg.

if nargin < 2, opts = struct(); end
if ~isfield(opts, 'tag'), opts.tag = 'main'; end
if ~isfield(opts, 'saveArtifacts'), opts.saveArtifacts = cfg.out.saveImages; end
if ~isfield(opts, 'snrTrace'), opts.snrTrace = []; end
if ~isfield(opts, 'controller'), opts.controller = []; end

cfg = validate_config(cfg);
ev = image_source_schedule(cfg);
nI = numel(ev);
outDir = fullfile(cfg.out.resultsDir, 'reconstructed_images', opts.tag);
if opts.saveArtifacts && exist(outDir, 'dir') ~= 7, mkdir(outDir); end

frameKey = 0;
per = struct([]);
ctrlState = struct('lastSnrEstDb', NaN, 'queueLen', 0, 'k', 0);
for k = 1:nI
    cfgk = cfg;
    if ~isempty(opts.snrTrace)
        cfgk.chan.snrDb = opts.snrTrace(min(k, numel(opts.snrTrace)));
    end
    if ~isempty(opts.controller)
        ctrlState.k = k;
        dec = opts.controller(ctrlState);
        if isfield(dec, 'rate'), cfgk.fec.rate = dec.rate; end
        if isfield(dec, 'jpegQuality'), cfgk.codec.jpegQuality = dec.jpegQuality; end
        if isfield(dec, 'jxlDistance'), cfgk.codec.jxlDistance = dec.jxlDistance; end
        if isfield(dec, 'modScheme'), cfgk.mod.scheme = dec.modScheme; end
    end
    fec = fec_setup(cfgk);
    rec = load_image_record(ev(k).path, ev(k).id);
    [I, prepNote] = preprocess_image(rec.pixels, cfgk);
    enc = source_encode(I, cfgk);
    if isfield(cfgk, 'recovery') && strcmpi(cfgk.recovery.mode, 'fountain')
        [res, frameKey] = transmit_image_fountain(enc, ev(k).id, cfgk, fec, frameKey);
    else
        [res, frameKey] = transmit_image(enc, ev(k).id, cfgk, fec, frameKey);
    end
    q = image_quality_triplet(I, enc.Ic, res.Ir);

    e = struct();
    e.id = ev(k).id; e.file = rec.path; e.format = rec.format; e.tGen = ev(k).tGen;
    e.width = rec.width; e.height = rec.height; e.channels = size(I, 3);
    e.bitDepthIn = rec.bitDepthIn; e.conversion = rec.conversion; e.preprocess = prepNote;
    e.codec = enc.codec; e.codecParams = enc.params; e.origFileBytes = rec.fileBytes;
    e.rawBits = enc.rawBits; e.compBytes = numel(enc.bytes); e.CR = enc.CR; e.bpp = enc.bpp;
    e.encTime_s = enc.encTime_s; e.decTimeLocal_s = enc.decTime_s;
    e.fec = fec.desc; e.rate = fec.rate; e.modScheme = cfgk.mod.scheme; e.snrDb = cfgk.chan.snrDb;
    e.nPkts = res.nPkts; e.nTransmissions = res.nTransmissions;
    e.PER_initial = res.PER_initial; e.PER_attempt = res.PER_attempt; e.PER_final = res.PER_final;
    e.firstFail = sum(res.firstAttemptFail); e.lost = sum(~res.delivered);
    e.undetected = res.undetected;
    e.preErr = res.preErr; e.preN = res.preN; e.postErr = res.postErr; e.postN = res.postN;
    e.e2eErr = res.e2e.errBits; e.e2eErased = res.e2e.erased; e.e2eN = res.e2e.N;
    e.complete = res.complete; e.decodeOk = res.decodeOk; e.success = res.success;
    e.streamIdentical = res.streamIdentical; e.streamCrcOk = res.streamCrcOk; e.decodeMsg = res.decodeMsg; e.decTime_s = res.decTime_s;
    f = fieldnames(q);
    for j = 1:numel(f), e.(f{j}) = q.(f{j}); end
    e.airtime_s = sum(res.segments(res.segments(:, 1) == 1, 2));
    e.turnaround_s = sum(res.segments(res.segments(:, 1) == 2, 2));
    e.segments = res.segments; e.deliveredSeg = res.deliveredSeg;
    e.bits = res.bits;
    snrs = cellfun(@(d) d.snrEstDb, res.phyDiag);
    e.snrEstDb = mean(snrs);
    e.aHat = mean(cellfun(@(d) d.aHat, res.phyDiag));
    e.reassembly = res.reassembly;
    if k == 1, per = e; else, per(k) = e; end %#ok<AGROW>
    ctrlState.lastSnrEstDb = e.snrEstDb;

    log_msg(cfg, 1, 'img %d (%s): %d B, CR %.1f, %d pkts, PERinit %.3f, lost %d, success %d, PSNR(I,Ir) %.2f dB, airtime %.1f s', ...
        e.id, enc.codec, e.compBytes, e.CR, e.nPkts, e.PER_initial, e.lost, e.success, e.psnr_I_Ir, e.airtime_s);

    if opts.saveArtifacts
        save_artifacts(outDir, e, I, enc, res);
    end
end

% ---- continuous-source timeline
Tprop = cfg.chan.range_m / cfg.chan.c;
tl = simulate_queue([per.tGen], [per.encTime_s], [per.decTime_s], {per.segments}, ...
    [per.deliveredSeg], [per.success], Tprop, cfg);
for k = 1:nI
    per(k).tStart = tl.tStart(k); per(k).tDelivered = tl.tDelivered(k);
    per(k).delay_s = tl.delay(k); per(k).wait_s = tl.wait(k); per(k).dropped = tl.dropped(k);
    if tl.dropped(k), per(k).success = false; end
end
S.perImage = per;
S.timeline = tl;
S.summary = summarize_run(per, tl);
S.cfg = cfg;
end

function save_artifacts(d, e, I, enc, res)
ext = struct('jpeg', 'jpg', 'jpegxl', 'jxl', 'png', 'png', 'learned', 'lic');
x = ext.(enc.codec);
b = fullfile(d, sprintf('img%03d', e.id));
imwrite(I, [b '_original.png']);
write_bytes([b '_compressed.' x], enc.bytes);
imwrite(enc.Ic, [b '_Ic_local_decode.png']);
if res.complete
    write_bytes([b '_rx_stream.' x], res.stream);
end
if ~isempty(res.Ir)
    imwrite(res.Ir, [b '_Ir_received.png']);
end
diag = rmfield(e, {'segments', 'bits', 'reassembly'});
diag.reassembly = rmfield(e.reassembly, 'received');
diag.missingSeq = e.reassembly.missing;
fid = fopen([b '_diagnostics.json'], 'w');
fprintf(fid, '%s', jsonencode(diag));
fclose(fid);
end
