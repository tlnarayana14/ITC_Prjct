function T = feedback_duration(nBits, cfg, fec)
%FEEDBACK_DURATION Airtime (s) of an ACK/NACK feedback frame of nBits.
%   The feedback frame uses the same PHY waveform (preamble, OFDM/SC
%   framing) carrying ceil(nBits/R) coded bits. Its duration is obtained by
%   actually building the frame with PHY_TX. The feedback channel itself is
%   assumed error-free (documented limitation: lost ACKs are not modelled).
coded = zeros(ceil(nBits / fec.rate), 1);
tx = phy_tx(coded, cfg);
T = tx.duration_s;
end
