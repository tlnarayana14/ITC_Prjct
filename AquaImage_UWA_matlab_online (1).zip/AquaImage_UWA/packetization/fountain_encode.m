function [pkts, info] = fountain_encode(stream, imageId, codecIdVal, esis, cfg)
%FOUNTAIN_ENCODE Systematic random-linear fountain (erasure) code over GF(2).
%
%   [pkts, info] = FOUNTAIN_ENCODE(stream, imageId, codecId, esis, cfg)
%     stream : uint8 compressed file;  esis : encoding-symbol IDs to produce
%   The stream is cut into K source blocks of P = cfg.pkt.payloadBytes bytes
%   (last block zero-padded). Encoding symbol e:
%     e = 0..K-1 : source block e+1 (systematic part)
%     e >= K     : XOR of the source blocks selected by a pseudo-random
%                  K-bit coefficient vector derived from (e, K) (Bernoulli 1/2)
%   Every encoding symbol is sent as a normal CRC-32 packet whose header is
%     image ID | ESI | K | last-block length | codec ID | flags (bit1 = fountain)
%   so the receiver can rebuild the coefficient vector and the stream length.
%   Any K linearly independent received symbols recover the stream (a random
%   dense GF(2) code needs on average ~1.6 extra symbols beyond K).
%   This replaces per-packet retransmission requests: the transmitter just
%   sends MORE symbols, any of which helps (no "which packet is missing").
P = cfg.pkt.payloadBytes;
stream = uint8(stream(:));
K = ceil(numel(stream) / P);
lastLen = numel(stream) - (K - 1) * P;
src = reshape([stream; zeros(K * P - numel(stream), 1, 'uint8')], P, K);
s = crc_spec(cfg.crc.name); nc = s.width / 8;
pkts = cell(1, numel(esis));
for i = 1:numel(esis)
    e = esis(i);
    a = fountain_coeffs(e, K);
    pay = zeros(P, 1, 'uint8');
    for j = find(a)
        pay = bitxor(pay, src(:, j));
    end
    hdr = [u16(imageId); u16(e); u16(K); u16(lastLen); uint8(codecIdVal); uint8(2)];
    body = [hdr; pay];
    c = crc_compute(body, s);
    pkts{i} = [body; uint8(bitand(bitshift(c, -8 * ((nc - 1):-1:0).'), 255))];
end
info = struct('K', K, 'lastLen', lastLen, 'P', P);
end

function b = u16(v)
b = uint8([floor(v / 256); mod(v, 256)]);
end
