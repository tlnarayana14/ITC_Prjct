function v = ternary(c, a, b)
%TERNARY Return a if c is true, else b.
if c, v = a; else, v = b; end
end
