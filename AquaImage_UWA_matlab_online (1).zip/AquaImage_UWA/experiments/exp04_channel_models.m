function T = exp04_channel_models()
%EXP04_CHANNEL_MODELS Experiment 4: AWGN vs multipath vs Doppler vs time-varying,
%   OFDM and the single-carrier baseline, LDPC R=1/2, ARQ off.
%   Also: OFDM on the Doppler channel with the receiver's Doppler
%   compensation DISABLED (resampling + CFO removal off) to measure its effect.
base = experiment_base();
base.fec.code = 'ldpc'; base.fec.rate = 1/2;
snrs = 0:2:14;
v = struct('name', {}, 'apply', {});
v(end + 1) = struct('name', 'OFDM awgn', 'apply', @(c) setm(c, 'ofdm', 'awgn', true));
v(end + 1) = struct('name', 'OFDM multipath', 'apply', @(c) setm(c, 'ofdm', 'multipath', true));
v(end + 1) = struct('name', 'OFDM doppler', 'apply', @(c) setm(c, 'ofdm', 'doppler', true));
v(end + 1) = struct('name', 'OFDM timevarying', 'apply', @(c) setm(c, 'ofdm', 'timevarying', true));
v(end + 1) = struct('name', 'OFDM doppler, no Doppler comp.', 'apply', @(c) setm(c, 'ofdm', 'doppler', false));
v(end + 1) = struct('name', 'SC awgn', 'apply', @(c) setm(c, 'sc', 'awgn', true));
v(end + 1) = struct('name', 'SC multipath (no equaliser)', 'apply', @(c) setm(c, 'sc', 'multipath', true));
T = link_sweep(base, v, snrs, 'exp04');
rd = base.out.resultsDir; fd = fullfile(rd, 'figures');
save_sweep(T, fullfile(rd, 'tables', 'exp04_channel_models.csv'));
plot_sweep(T, 'BER_pre', 'pre-decoding BER', 'Exp 4: pre-decoding BER by channel model (LDPC 1/2, QPSK)', fullfile(fd, 'exp04_ber_pre.png'), true, 1e-7);
plot_sweep(T, 'PER_initial', 'packet error rate (no ARQ)', 'Exp 4: PER by channel model', fullfile(fd, 'exp04_per.png'), true, 1e-4);
plot_sweep(T, 'deliveryRate', 'image delivery success (no ARQ)', 'Exp 4: image delivery by channel model', fullfile(fd, 'exp04_delivery.png'), false);
end

function c = setm(c, phy, model, comp)
c.phy.type = phy; c.chan.model = model; c.phy.ofdm.dopplerComp = comp;
end
