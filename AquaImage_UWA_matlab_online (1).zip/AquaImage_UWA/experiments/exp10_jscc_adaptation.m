function R = exp10_jscc_adaptation(traceSeeds, doAggregate)
%EXP10_JSCC_ADAPTATION Experiment 10 (research extension): deadline-aware joint
%   source/channel operating-point selection versus fixed and channel-only
%   adaptation, under time-varying SNR traces.
%
%   Resource budget: latency deadline Tb = 12 s per image (service latency,
%   camera interval 120 s => no queueing), SR-ARQ max 3 retries for all.
%   Policies (paired design: same images, same trace, same seed):
%     fixed q40/R1/2, fixed q60/R1/2, fixed q40/R3/4,
%     rate-only adaptive (Exp-5 controller, q40),
%     JSCC adaptive (JSCC_CONTROLLER on the Exp-7 utility table).
%   5 independent SNR traces (traceSeeds) x 16 images = 80 images per policy.
%   NOTE: the Exp-7 table was measured on images euvp_01..04 at 5/8/11 dB,
%   whereas this experiment transmits euvp_01..16 under traces that vary
%   between ~3 and ~14 dB, so the controller is evaluated out-of-sample.
%   Metrics: on-time delivery rate (+ Wilson 95% CI), utility =
%   mean(1[on time] x SSIM(I, I_r)), SSIM of on-time images, latency, and
%   paired per-image win/loss counts of JSCC vs every other policy.
%   exp10_jscc_adaptation(seeds, false) only fills results/cache (to split the
%   work across processes); a later call aggregates from the cache.
if nargin < 1, traceSeeds = 7:11; end
base = experiment_base();
base.arq.enabled = true; base.arq.maxRetries = 3;
base.source.numImages = 16;
base.source.interval_s = 120;
Tb = 12;
td = fullfile(base.out.resultsDir, 'tables');
U = read_utility(fullfile(td, 'exp07_utility.csv'));
T3 = read_csv_struct(fullfile(td, 'exp03_snr_sweep_multipath_arq.csv'));
rates = [1/2 2/3 3/4 5/6];
thr = per_thresholds(T3, rates, 0.10); ok = ~isnan(thr);
fb = struct('jpegQuality', 40, 'rate', 1/2);
pol = struct('name', {'fixed q40 R1/2', 'fixed q60 R1/2', 'fixed q40 R3/4', 'rate-only adaptive q40', 'JSCC adaptive'}, ...
    'ctrl', {@(s) struct('jpegQuality', 40, 'rate', 1/2), @(s) struct('jpegQuality', 60, 'rate', 1/2), ...
    @(s) struct('jpegQuality', 40, 'rate', 3/4), @(s) setfield(rate_controller(s, rates(ok), thr(ok), 1.0), 'jpegQuality', 40), ...
    @(s) jscc_controller(s, U, Tb, fb)});
nP = numel(pol);
acc = repmat(struct('onTime', false(1, 0), 'ssim', [], 'lat', [], 'psnr', [], 'bpp', [], 'rate', [], 'IrIc', true), 1, nP);
prow = {};
cdir = fullfile(base.out.resultsDir, 'cache');
if exist(cdir, 'dir') ~= 7, mkdir(cdir); end
for ts = traceSeeds
    trace = snr_trace(base.source.numImages, ts);
    for p = 1:nP
        % each (trace, policy) run is cached so the experiment can be split
        % across processes and resumed; delete results/cache to recompute
        cf = fullfile(cdir, sprintf('exp10_trace%d_policy%d.mat', ts, p));
        if exist(cf, 'file') == 2
            c = load(cf); c = c.c;
        else
            set_seed(base.seed + 1500 + ts);
            S = run_link_simulation(base, struct('tag', 'exp10', 'saveArtifacts', false, 'snrTrace', trace, 'controller', pol(p).ctrl));
            P = S.perImage;
            c = struct();
            c.onTime = logical([P.success] & [P.delay_s] <= Tb);
            c.ssim = [P.ssim_I_Ic];                       % = SSIM(I, I_r) for delivered images (I_r == I_c checked)
            c.lat = [P([P.success]).delay_s];
            c.psnr = [P(c.onTime).psnr_I_Ir];
            c.bpp = [P.bpp]; c.rate = [P.rate];
            c.IrIc = S.summary.allDeliveredIcEqualsIr;
            c.snrEst = [P.snrEstDb]; c.success = [P.success]; c.delay = [P.delay_s];
            save(cf, 'c', '-v7');
        end
        acc(p).onTime = logical([acc(p).onTime, c.onTime]);
        acc(p).ssim = [acc(p).ssim, c.ssim];
        acc(p).lat = [acc(p).lat, c.lat];
        acc(p).psnr = [acc(p).psnr, c.psnr];
        acc(p).bpp = [acc(p).bpp, c.bpp];
        acc(p).rate = [acc(p).rate, c.rate];
        acc(p).IrIc = acc(p).IrIc && c.IrIc;
        for k = 1:numel(c.onTime)
            prow(end + 1, :) = {pol(p).name, ts, k - 1, trace(k), c.snrEst(k), c.bpp(k), c.rate(k), c.success(k), c.delay(k), c.onTime(k), c.ssim(k)}; %#ok<AGROW>
        end
        fprintf('[exp10] trace %d %-24s on-time %d/%d\n', ts, pol(p).name, nnz(c.onTime), numel(c.onTime));
    end
end
if nargin >= 2 && ~doAggregate
    R = struct(); return;
end
rows = {};
for p = 1:nP
    a = acc(p);
    n = numel(a.onTime); k = nnz(a.onTime);
    [lo, hi] = wilson_ci(k, n);
    rows(end + 1, :) = {pol(p).name, k, n, k / n, lo, hi, mean(a.onTime .* a.ssim), mean(a.ssim(a.onTime)), ...
        mean(a.lat), max(a.lat), mean(a.psnr), mean(a.bpp), mean(a.rate), a.IrIc}; %#ok<AGROW>
    fprintf('[exp10] %-24s on-time %d/%d = %.3f [%.3f, %.3f] utility %.3f SSIM(on-time) %.3f latency %.1f s bpp %.2f rate %.3f\n', ...
        rows{p, 1}, k, n, k / n, lo, hi, rows{p, 7}, rows{p, 8}, rows{p, 9}, rows{p, 12}, rows{p, 13});
end
pw = {};
for p = 1:nP - 1
    d1 = acc(nP).onTime; d0 = acc(p).onTime;
    pw(end + 1, :) = {['JSCC vs ' pol(p).name], nnz(d1 & ~d0), nnz(~d1 & d0), nnz(d1 == d0)}; %#ok<AGROW>
end
write_csv(fullfile(td, 'exp10_jscc.csv'), {'policy', 'onTime', 'images', 'onTimeRate', 'onTime_lo95', 'onTime_hi95', 'utility', ...
    'ssimOnTime', 'meanLatency_s', 'maxLatency_s', 'psnrOnTime', 'meanBpp', 'meanRate', 'IrEqualsIcAllDelivered'}, rows);
write_csv(fullfile(td, 'exp10_paired.csv'), {'comparison', 'onlyJsccOnTime', 'onlyOtherOnTime', 'same'}, pw);
write_csv(fullfile(td, 'exp10_per_image.csv'), {'policy', 'traceSeed', 'image', 'snrTrueDb', 'snrEstDb', 'bpp', 'rate', 'success', 'latency_s', 'onTime', 'ssim'}, prow);
f = prepare_figure(900, 460);
bar([cell2mat(rows(:, 4)), cell2mat(rows(:, 7))]); hold on;
x = 1:nP;
errorbar(x - 0.14, cell2mat(rows(:, 4)), cell2mat(rows(:, 4)) - cell2mat(rows(:, 5)), cell2mat(rows(:, 6)) - cell2mat(rows(:, 4)), 'k.');
set(gca, 'XTickLabel', rows(:, 1)); grid on; ylim([0 1.05]);
legend({'on-time delivery rate (12 s), 95% CI', 'utility = mean(on-time x SSIM)'}, 'Location', 'northwest');
title(sprintf('Exp 10: deadline-aware JSCC selection, %d traces x 16 images', numel(traceSeeds)));
save_figure(f, fullfile(base.out.resultsDir, 'figures', 'exp10_jscc.png'));
R.rows = rows; R.paired = pw;
end

function U = read_utility(fname)
T = read_csv_struct(fname);
U = [num2cell([T.snrDb]'), num2cell([T.deadline_s]'), num2cell([T.jpegQuality]'), num2cell([T.rate]'), ...
    num2cell([T.onTimeRate]'), num2cell([T.meanSsimOnTime]'), num2cell([T.utility]'), num2cell([T.meanLatency_s]'), num2cell([T.snrEstDb]')];
end
