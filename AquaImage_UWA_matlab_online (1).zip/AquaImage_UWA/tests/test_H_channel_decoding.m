function test_H_channel_decoding()
%TEST_H_CHANNEL_DECODING LDPC through the OFDM/AWGN chain: corrects errors inside
%   its operating region; outside it, failures are flagged by CRC (not hidden).
cfg = test_config();
cfg.chan.model = 'awgn';
set_seed(14);
fec = fec_setup(cfg);
pk = cell(1, 8);
for i = 1:8
    pk{i} = uint8(randi([0 255], 214, 1));
    c = crc_compute(pk{i}(1:210), crc_spec('CRC-32'));
    pk{i}(211:214) = uint8(bitand(bitshift(c, -[24; 16; 8; 0]), 255));
end
cfg.chan.snrDb = 4;
fr = transmit_frame(pk, cfg, fec, 1);
check(fr.preErr > 0 && fr.postErr == 0, 'SNR 4 dB: %d raw coded-bit errors (BER_pre %.3e) all corrected (BER_post 0)', fr.preErr, fr.preErr / fr.preN);
cfg.chan.snrDb = -3;
fr = transmit_frame(pk, cfg, fec, 2);
okCrc = cellfun(@(b) crc_compute(b(1:210), crc_spec('CRC-32')) == ...
    bitor(bitor(bitshift(uint32(b(211)), 24), bitshift(uint32(b(212)), 16)), bitor(bitshift(uint32(b(213)), 8), uint32(b(214)))), fr.rxBytes);
wrong = fr.pktPostErr > 0;
check(any(wrong), 'SNR -3 dB (outside the code''s region): %d/8 packets still erroneous after decoding (BER_post %.3e)', nnz(wrong), fr.postErr / fr.postN);
check(all(~okCrc(wrong)), 'every packet with residual errors fails CRC (none silently accepted)');
end
