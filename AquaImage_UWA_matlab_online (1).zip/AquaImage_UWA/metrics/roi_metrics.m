function [p, s] = roi_metrics(A, B, bb)
%ROI_METRICS PSNR and SSIM restricted to the region of interest bb = [r0 c0 h w].
r = bb(1):bb(1) + bb(3) - 1; c = bb(2):bb(2) + bb(4) - 1;
p = psnr_u8(A(r, c, :), B(r, c, :));
s = ssim_luma(A(r, c, :), B(r, c, :));
end
