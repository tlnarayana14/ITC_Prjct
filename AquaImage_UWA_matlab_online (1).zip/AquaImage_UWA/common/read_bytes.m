function b = read_bytes(fname)
%READ_BYTES Read a whole file as a uint8 column vector (exact bytes).
fid = fopen(fname, 'rb');
if fid < 0
    error('read_bytes:open', 'Cannot open file %s', fname);
end
b = fread(fid, Inf, '*uint8');
fclose(fid);
b = b(:);
end
