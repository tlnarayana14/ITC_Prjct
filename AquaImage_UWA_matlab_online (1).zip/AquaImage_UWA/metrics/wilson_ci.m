function [lo, hi] = wilson_ci(k, n, z)
%WILSON_CI Wilson score interval for a binomial proportion k/n (default 95%).
if nargin < 3, z = 1.96; end
lo = NaN(size(k)); hi = NaN(size(k));
ok = n > 0;
p = k(ok) ./ n(ok);
nn = n(ok);
den = 1 + z.^2 ./ nn;
c = (p + z.^2 ./ (2 * nn)) ./ den;
h = z .* sqrt(p .* (1 - p) ./ nn + z.^2 ./ (4 * nn.^2)) ./ den;
lo(ok) = max(0, c - h);
hi(ok) = min(1, c + h);
end
