function ok = codec_available(name, cfg)
%CODEC_AVAILABLE True if the named source codec can actually run here.
%   'jpeg','png' : built into imwrite/imread (MATLAB and Octave).
%   'jpegxl'     : requires the libjxl reference tools cjxl and djxl on the path.
%   'learned'    : requires python with torch + compressai (tools/learned_codec.py)
%                  AND downloadable/cached pretrained weights.
persistent cache
if isempty(cache), cache = struct(); end
key = lower(name);
if isfield(cache, key), ok = cache.(key); return; end
switch key
    case {'jpeg', 'png'}
        ok = true;
    case 'jpegxl'
        [s1, ~] = system(sprintf('%s --version', cfg.codec.cjxl));
        [s2, ~] = system(sprintf('%s --version', cfg.codec.djxl));
        ok = (s1 == 0) && (s2 == 0);
    case 'learned'
        [s, ~] = system(sprintf('%s -c "import torch, compressai"', cfg.codec.python));
        ok = (s == 0);
    otherwise
        ok = false;
end
cache.(key) = ok;
end
