function set_seed(seed)
%SET_SEED Seed the global random generators (MATLAB and Octave).
%   Note: MATLAB and Octave use different generator implementations, so a
%   given seed reproduces results exactly only on the same platform.
rng(seed);
end
