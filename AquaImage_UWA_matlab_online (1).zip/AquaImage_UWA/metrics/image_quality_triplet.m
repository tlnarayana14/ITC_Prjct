function q = image_quality_triplet(I, Ic, Ir)
%IMAGE_QUALITY_TRIPLET Mandatory three-way comparison (Phase 15).
%   q = IMAGE_QUALITY_TRIPLET(I, Ic, Ir)
%     I  : original (preprocessed) image fed to the encoder
%     Ic : locally decoded compressed image (transmitter side)
%     Ir : receiver-decoded image ([] when the image was not delivered)
%   Fields (NaN when Ir is unavailable):
%     psnr_I_Ic, ssim_I_Ic   source-coding distortion
%     psnr_I_Ir, ssim_I_Ir   overall end-to-end distortion
%     psnr_Ic_Ir, ssim_Ic_Ir additional distortion from transmission/recovery
%     IcEqualsIr             true when the receiver output equals I_c exactly
%   All images must have identical size/channels; Ic may have fewer channels
%   than I only if the codec stores grayscale (then I is compared as luma).
q.psnr_I_Ic = psnr_u8(I, Ic);
q.ssim_I_Ic = ssim_luma(I, Ic);
q.psnr_I_Ir = NaN; q.ssim_I_Ir = NaN; q.psnr_Ic_Ir = NaN; q.ssim_Ic_Ir = NaN;
q.IcEqualsIr = false;
if ~isempty(Ir)
    q.psnr_I_Ir = psnr_u8(I, Ir);
    q.ssim_I_Ir = ssim_luma(I, Ir);
    q.psnr_Ic_Ir = psnr_u8(Ic, Ir);
    q.ssim_Ic_Ir = ssim_luma(Ic, Ir);
    q.IcEqualsIr = isequal(Ic, Ir);
end
end
