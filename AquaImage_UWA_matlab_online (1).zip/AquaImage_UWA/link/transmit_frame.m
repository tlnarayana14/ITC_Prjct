function fr = transmit_frame(pktBytes, cfg, fec, frameKey, flips)
%TRANSMIT_FRAME Send one PHY frame (a burst of packets) through the full chain.
%
%   fr = TRANSMIT_FRAME(pktBytes, cfg, fec, frameKey)
%     pktBytes : cell array of serialized packets (uint8, header+payload+CRC)
%     fec      : FEC_SETUP output
%     frameKey : frame counter, keys the interleaver permutation
%
%   Chain: bytes->bits -> channel encoding (+shortening/padding) ->
%   interleaving -> PHY Tx (mapping, framing, OFDM/SC) -> UWA channel ->
%   PHY Rx (sync, Doppler/CFO, channel est., equalisation, soft demap) ->
%   deinterleaving -> channel decoding -> bits->bytes.
%   CRC verification is NOT done here (receiver side: parse_packet).
%
%   fr fields
%     rxBytes      cell, channel-decoder output per packet (uint8)
%     txBits       cell, channel-encoder input per packet (ground truth)
%     preErr, preN coded-bit errors/bits BEFORE decoding: hard decisions
%                  sign(LLR) after deinterleaving vs. transmitted coded bits
%                  (shortened bits are never transmitted and not counted)
%     postErr, postN  info-bit errors/bits AFTER decoding: decoder output vs.
%                  encoder input (header+payload+CRC of every packet; the
%                  known padding bits are excluded)
%     pktPostErr   per-packet post-decoding bit errors
%     codedBits, infoBits, padBits, airtime_s, phy (diagnostics), chan (info)
%   flips (optional, test hook): flips(i) decoded bits of packet i are
%     inverted after channel decoding at evenly spread positions, emulating
%     residual decoder errors with a KNOWN count.

np = numel(pktBytes);
if nargin < 5 || isempty(flips), flips = zeros(1, np); end
msgs = cell(1, np);
for i = 1:np
    msgs{i} = bytes_to_bits(pktBytes{i});
end
[coded, layout] = fec_encode(fec, msgs);
if cfg.fec.interleave
    txb = interleave_bits(coded, frameKey);
else
    txb = coded;
end
tx = phy_tx(txb, cfg);
[r, ch] = uwa_channel(tx, cfg);
[llr, d] = phy_rx(r, tx.meta, cfg);
if cfg.fec.interleave
    llr = interleave_bits(llr, frameKey, true);
end
hard = double(llr < 0);
[dec, st] = fec_decode(fec, llr, layout);

fr.txBits = msgs;
fr.rxBytes = cell(1, np);
fr.pktPostErr = zeros(1, np);
for i = 1:np
    if flips(i) > 0
        pos = unique(round(linspace(1, numel(dec{i}), flips(i))));
        dec{i}(pos) = 1 - dec{i}(pos);
    end
    fr.rxBytes{i} = bits_to_bytes(dec{i});
    fr.pktPostErr(i) = sum(dec{i} ~= msgs{i});
end
fr.preErr = sum(hard ~= coded);
fr.preN = numel(coded);
fr.postErr = sum(fr.pktPostErr);
fr.postN = sum([layout.L]);
fr.codedBits = numel(coded);
fr.infoBits = fr.postN;
fr.padBits = sum([layout.pad]);
fr.airtime_s = tx.duration_s;
fr.nDataSym = tx.nDataSym;
fr.phy = d;
fr.chan = ch;
fr.fecStats = st;
end
