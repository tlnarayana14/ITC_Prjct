function f = prepare_figure(w, h)
%PREPARE_FIGURE Create an off-screen figure of w x h pixels (MATLAB and Octave).
%   Octave without a display: selects the gnuplot toolkit.
%   MATLAB (incl. MATLAB Online): the size is stored in the figure's
%   UserData and re-applied by SAVE_FIGURE, because MATLAB Online can report
%   a zero-size invisible figure at print time.
if nargin < 1, w = 800; end
if nargin < 2, h = 500; end
if is_octave()
    tk = available_graphics_toolkits();
    if isempty(getenv('DISPLAY')) && any(strcmp(tk, 'gnuplot'))
        ws = warning('off', 'all');
        graphics_toolkit('gnuplot');
        warning(ws);
    end
end
f = figure('Visible', 'off', 'Units', 'pixels', 'Position', [100 100 w h], 'Color', 'w');
set(f, 'UserData', struct('w', w, 'h', h));
end
