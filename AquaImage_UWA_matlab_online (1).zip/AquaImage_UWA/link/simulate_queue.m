function tl = simulate_queue(tGen, encTime, decTime, segs, delSeg, success, Tprop, cfg)
%SIMULATE_QUEUE Event timeline of the continuous source over a half-duplex link.
%
%   tl = SIMULATE_QUEUE(tGen, encTime, decTime, segs, delSeg, success, Tprop, cfg)
%     tGen(k)    generation time of image k (camera schedule)
%     encTime(k) source-encoding time (measured; 0 if useMeasuredProcTime=false)
%     decTime(k) receiver source-decoding time (measured)
%     segs{k}    [type duration] rows from TRANSMIT_IMAGE (data frames and
%                ARQ turnarounds = 2*Tprop + feedback airtime)
%     delSeg(k)  index of the data frame that completed the image (NaN if never)
%     success(k) image decoded at the receiver
%   Model: one transmitter, one acoustic link (half duplex), FIFO service.
%   Image k enters the queue when encoded (tGen + encTime). It starts when
%   the link is free. Policy 'deadline' drops an image whose waiting time
%   (start - tGen) would exceed cfg.queue.deadline_s (it is never sent).
%   Delivery = end of the completing frame + Tprop (+ decode time).
%   Outputs per image: tReady, tStart, tEnd (link released), tDelivered
%   (NaN if not delivered), delay = tDelivered - tGen, wait = tStart - tReady,
%   dropped; and queue-length samples (tQ, Q = images waiting, not in service).
n = numel(tGen);
if ~cfg.queue.useMeasuredProcTime
    encTime = zeros(size(encTime)); decTime = zeros(size(decTime));
end
tReady = tGen(:).' + encTime(:).';
tStart = NaN(1, n); tEnd = NaN(1, n); tDel = NaN(1, n); dropped = false(1, n);
free = 0;
for k = 1:n
    s = max(tReady(k), free);
    if strcmpi(cfg.queue.policy, 'deadline') && (s - tGen(k)) > cfg.queue.deadline_s
        dropped(k) = true;
        continue;
    end
    tStart(k) = s;
    t = s;
    sg = segs{k};
    for j = 1:size(sg, 1)
        t = t + sg(j, 2);
        if j == delSeg(k) && success(k)
            tDel(k) = t + Tprop + decTime(k);
        end
    end
    tEnd(k) = t;
    free = t;
end
tl.tReady = tReady; tl.tStart = tStart; tl.tEnd = tEnd; tl.tDelivered = tDel;
tl.delay = tDel - tGen(:).';
tl.wait = tStart - tReady;
tl.dropped = dropped;
% queue length (waiting, excluding the image in service) at every event time
ev = unique([tReady, tStart(~isnan(tStart)), tEnd(~isnan(tEnd))]);
Q = zeros(size(ev));
for i = 1:numel(ev)
    t = ev(i);
    waiting = (tReady <= t) & ((tStart > t) | (isnan(tStart) & ~dropped));
    Q(i) = nnz(waiting);
end
tl.tQ = ev; tl.Q = Q;
tl.horizon = max([tEnd(~isnan(tEnd)), tDel(~isnan(tDel)), 0]);
end
