function root = setup_paths()
%SETUP_PATHS Add all AquaImage_UWA module folders to the MATLAB/Octave path.
%   root = SETUP_PATHS() returns the absolute project root folder.
%   Works in MATLAB (R2019b+) and GNU Octave (>= 7). No toolboxes required.
root = fileparts(mfilename('fullpath'));
mods = {'config','common','source','source_coding','packetization', ...
        'channel_coding','modulation','phy','channel','receiver','link', ...
        'adaptation','metrics','experiments','tests','tools'};
for k = 1:numel(mods)
    p = fullfile(root, mods{k});
    if exist(p, 'dir') == 7
        addpath(p);
    end
end
end
