"""Deep joint source-channel coding (Deep JSCC) for the AquaImage_UWA OFDM link.

Architecture (fully convolutional, SNR-adaptive, ~1.4 M parameters):
  encoder: 4 x [5x5 conv, stride 2, PReLU] (64-96-96-96 ch), FiLM conditioning on
           the channel SNR, 3x3 conv to C=128 real channels -> latent of
           H/16 x W/16 x 128 reals = (H*W/512) complex channel symbols
           (bandwidth ratio k/n = 1/12 complex symbols per real pixel value).
  power  : per-image normalisation to unit average symbol power.
  decoder: mirror with transposed convolutions, FiLM on SNR, sigmoid output.
Channel used in training (`UWAOFDMChannel`): symbols are mapped in order onto
the 672 data subcarriers of consecutive OFDM symbols (as phy_ofdm_tx.m does),
after a fixed pseudo-random interleaver; each subcarrier sees
H_k = sum_p g_p (sqrt(K/(K+1)) + sqrt(1/(K+1)) w_p) exp(-j2 pi f_k tau_p)
built from the SAME image-method paths as the Octave simulator, with w_p a
slowly varying complex Gaussian process (AR(1) across OFDM symbols), plus AWGN
at in-band SNR (per-subcarrier Es/N0 = SNR * K/N_used). The receiver applies
LMMSE equalisation with the channel known in training; at evaluation time the
real Octave receiver (pilot-based estimates) supplies the equalised symbols.
Based on the Deep JSCC idea of Bourtsoulatze, Kurka & Gunduz (IEEE TCCN 2019)
with SNR-adaptive (attention/FiLM) conditioning in the spirit of later work.
"""
import json, math
import numpy as np
import torch
import torch.nn as nn

C_LATENT = 128


class FiLM(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.mlp = nn.Sequential(nn.Linear(1, 32), nn.ReLU(), nn.Linear(32, 2 * ch))

    def forward(self, x, snr_db):
        g, b = self.mlp(snr_db.view(-1, 1) / 10.0).chunk(2, dim=1)
        return x * (1 + g[..., None, None]) + b[..., None, None]


class Encoder(nn.Module):
    def __init__(self):
        super().__init__()
        ch = [3, 64, 96, 96, 96]
        self.convs = nn.ModuleList([nn.Sequential(nn.Conv2d(ch[i], ch[i + 1], 5, 2, 2), nn.PReLU(ch[i + 1])) for i in range(4)])
        self.film = FiLM(96)
        self.out = nn.Conv2d(96, C_LATENT, 3, 1, 1)

    def forward(self, x, snr):
        for c in self.convs:
            x = c(x)
        return self.out(self.film(x, snr))


class Decoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.inp = nn.Sequential(nn.Conv2d(C_LATENT, 96, 3, 1, 1), nn.PReLU(96))
        self.film = FiLM(96)
        ch = [96, 96, 96, 64, 32]
        self.ups = nn.ModuleList([nn.Sequential(nn.ConvTranspose2d(ch[i], ch[i + 1], 5, 2, 2, output_padding=1), nn.PReLU(ch[i + 1])) for i in range(4)])
        self.out = nn.Conv2d(32, 3, 3, 1, 1)

    def forward(self, z, snr):
        x = self.film(self.inp(z), snr)
        for u in self.ups:
            x = u(x)
        return torch.sigmoid(self.out(x))


def latent_to_symbols(z):
    """B x C x h x w reals -> B x n complex, unit average power per image."""
    B = z.shape[0]
    v = z.reshape(B, -1)
    s = torch.complex(v[:, 0::2], v[:, 1::2])
    p = (s.abs() ** 2).mean(dim=1, keepdim=True)
    return s / torch.sqrt(p + 1e-12)


def symbols_to_latent(s, shape):
    B = s.shape[0]
    v = torch.stack([s.real, s.imag], dim=2).reshape(B, -1)
    return v.reshape(B, *shape)


def interleaver(n):
    return np.random.RandomState(2026).permutation(n)


class UWAOFDMChannel:
    def __init__(self, json_path):
        s = json.load(open(json_path))
        self.tau = torch.tensor(s['delay_s'], dtype=torch.float64)
        self.g = torch.tensor(s['gain_re'], dtype=torch.float64) + 1j * torch.tensor(s['gain_im'], dtype=torch.float64)
        self.f = torch.tensor(s['freq_hz'], dtype=torch.float64)
        self.nd = s['nData']
        self.K = s['ricianK']
        self.ratio = s['K_over_Nused']
        self.E = torch.exp(-2j * math.pi * self.f[:, None] * self.tau[None, :])   # nd x P

    def response(self, B, nsym, rho=0.98):
        P = self.g.numel()
        w = (torch.randn(B, P, dtype=torch.float64) + 1j * torch.randn(B, P, dtype=torch.float64)) / math.sqrt(2)
        Hs = []
        for m in range(nsym):
            if m > 0:
                e = (torch.randn(B, P, dtype=torch.float64) + 1j * torch.randn(B, P, dtype=torch.float64)) / math.sqrt(2)
                w = rho * w + math.sqrt(1 - rho ** 2) * e
            gp = self.g[None, :] * (math.sqrt(self.K / (self.K + 1)) + math.sqrt(1 / (self.K + 1)) * w)
            Hs.append(gp @ self.E.T)                      # B x nd
        return torch.cat(Hs, dim=1).to(torch.complex64)   # B x (nsym*nd)

    def __call__(self, s, snr_db):
        """s: B x n complex (already interleaved). Returns LMMSE-equalised symbols."""
        B, n = s.shape
        nsym = math.ceil(n / self.nd)
        H = self.response(B, nsym)[:, :n]
        es_n0 = 10 ** (snr_db.view(-1, 1) / 10) * self.ratio
        nv = (1.0 / es_n0).to(torch.float32)
        noise = torch.sqrt(nv / 2) * (torch.randn(B, n) + 1j * torch.randn(B, n))
        y = H * s + noise
        return torch.conj(H) * y / (H.abs() ** 2 + nv)


def load_model(path):
    ck = torch.load(path, map_location='cpu')
    enc, dec = Encoder(), Decoder()
    enc.load_state_dict(ck['enc']); dec.load_state_dict(ck['dec'])
    enc.eval(); dec.eval()
    return enc, dec, ck
