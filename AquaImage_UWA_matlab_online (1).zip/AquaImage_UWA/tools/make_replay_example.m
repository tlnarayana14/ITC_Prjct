function fname = make_replay_example(cfg, fname, duration_s)
%MAKE_REPLAY_EXAMPLE Write a Model-E replay file (template + interface test).
%
%   This file is SYNTHETIC: it samples the image-method geometry with
%   per-path Rician fading (the Model D statistics) every 10 ms for
%   duration_s seconds. It exists to validate the replay interface and to
%   document the file format; it is NOT measured data. To use measured
%   soundings, store delay_s / gains / t_s / source in the same layout.
if nargin < 1, cfg = default_config(); end
if nargin < 2, fname = cfg.chan.replayFile; end
if nargin < 3, duration_s = 60; end
pth = uwa_multipath_geometry(cfg);
t_s = 0:0.01:duration_s;
P = numel(pth.gain);
K = cfg.chan.ricianK; fd = cfg.chan.fadingFd_Hz; Ns = 16;
st = 12345;
gains = zeros(P, numel(t_s));
for q = 1:P
    u = zeros(1, 3 * Ns);
    for i = 1:numel(u), st = mod(st * 16807, 2147483647); u(i) = st / 2147483647; end
    th = 2 * pi * u(1:Ns); ph = 2 * pi * u(Ns + 1:2 * Ns); ph2 = 2 * pi * u(2 * Ns + 1:end);
    w = (sum(cos(2 * pi * fd * t_s(:) * cos(th) + ph), 2) + 1j * sum(sin(2 * pi * fd * t_s(:) * cos(th) + ph2), 2)) / sqrt(Ns);
    gains(q, :) = pth.gain(q) * (sqrt(K / (K + 1)) + sqrt(1 / (K + 1)) * w.');
end
delay_s = pth.delay_s(:);
source = 'synthetic: image-method geometry + Rician/Jakes fading (NOT measured data)';
d = fileparts(fname);
if exist(d, 'dir') ~= 7, mkdir(d); end
save(fname, 'delay_s', 'gains', 't_s', 'source', '-v7');
end
