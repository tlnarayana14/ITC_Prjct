function cfg = experiment_base()
%EXPERIMENT_BASE Common settings of the link experiments (documented defaults).
%   4 real EUVP images (euvp_01..04), JPEG quality 30 (~0.68 bpp, ~5.5 kB),
%   200-byte payloads, CRC-32, LDPC R=1/2, QPSK, CP-OFDM in 8 kHz at 24 kHz,
%   image-method multipath (30 m depth, 1 km range), ARQ off unless stated.
cfg = default_config();
cfg.source.numImages = 4;
cfg.codec.name = 'jpeg';
cfg.codec.jpegQuality = 30;
cfg.chan.model = 'multipath';
cfg.arq.enabled = false;
cfg.out.saveImages = false;
cfg.out.verbose = 0;
end
