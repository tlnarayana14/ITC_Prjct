function a = fountain_coeffs(e, K)
%FOUNTAIN_COEFFS GF(2) coefficient row (logical 1 x K) of encoding symbol e.
%   Systematic: e < K -> unit vector e+1. Repair symbols: Bernoulli(1/2)
%   bits from a 32-bit xorshift generator whose state is a multiplicative
%   hash of (e, K), warmed up for 8 steps. Deterministic, identical at TX and
%   RX, and identical in MATLAB and Octave. An all-zero row is replaced by a
%   single-block row.
%   (Version 2: the first version used a Park-Miller LCG seeded linearly in e,
%   which produced strongly correlated rows for some K -- found when MATLAB's
%   JPEG encoder produced K = 22 and Test O failed. tests/test_O_fountain.m
%   now checks erasure recovery for many K.)
a = false(1, K);
if e < K
    a(e + 1) = true; return;
end
x = uint32(mod(e * 2654435761 + K * 40503 + 2463534242, 2^32));
if x == 0, x = uint32(1); end
for w = 1:8
    x = xs32(x);
end
for j = 1:K
    x = xs32(x);
    a(j) = x >= uint32(2147483648);
end
if ~any(a), a(mod(e, K) + 1) = true; end
end

function x = xs32(x)
x = bitxor(x, bitshift(x, 13));
x = bitxor(x, bitshift(x, -17));
x = bitxor(x, bitshift(x, 5));
end
