function test_K_error_free()
%TEST_K_ERROR_FREE Controlled error-free channel: every link metric is zero and
%   the recovered stream/image equal the transmitted ones (lossy and lossless).
cfg = test_config();
cfg.chan.model = 'ideal';
set_seed(16);
for codec = {'jpeg', 'png'}
    c = cfg; c.codec.name = codec{1};
    S = run_link_simulation(c, struct('tag', 'test_K', 'saveArtifacts', false));
    e = S.perImage(1); s = S.summary;
    check(s.BER_pre == 0 && s.BER_post == 0 && s.BER_E2E_total == 0 && s.PER_initial == 0, ...
        '%s: BER_pre = BER_post = BER_E2E = PER = 0', codec{1});
    check(e.streamIdentical && e.IcEqualsIr, '%s: recovered stream identical, I_r == I_c', codec{1});
    check(e.streamCrcOk, '%s: whole-stream CRC-32 of the reassembled file matches the transmitter record', codec{1});
    if strcmp(codec{1}, 'png')
        check(isinf(e.psnr_I_Ir), 'png (lossless): I_r == I (PSNR = Inf)');
    else
        check(isfinite(e.psnr_I_Ir) && e.psnr_I_Ir == e.psnr_I_Ic, 'jpeg (lossy): zero BER but I_r ~= I; PSNR(I,I_r) = PSNR(I,I_c) = %.2f dB', e.psnr_I_Ir);
    end
end
end
