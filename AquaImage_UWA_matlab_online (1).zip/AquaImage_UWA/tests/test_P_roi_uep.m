function test_P_roi_uep()
%TEST_P_ROI_UEP ROI detection constraints and two-layer ROI/UEP composition.
cfg = test_config();
r = load_image_record(fullfile(cfg.root, 'data', 'underwater_samples', 'euvp_04.jpg'), 0);
I = r.pixels;
bb = roi_detect(I, cfg);
check(all(bb >= 1) && bb(1) + bb(3) - 1 <= size(I, 1) && bb(2) + bb(4) - 1 <= size(I, 2), 'ROI box %s lies inside the image', mat2str(bb));
check(mod(bb(3), 16) == 0 && mod(bb(4), 16) == 0 && mod(bb(1) - 1, 16) == 0 && mod(bb(2) - 1, 16) == 0, 'ROI aligned to the 16-pixel grid');
check(bb(3) * bb(4) <= 0.5 * numel(I(:, :, 1)), 'ROI limited to 40%% of the image before 16-px alignment (<= 50%% after; here %.0f%%)', 100 * bb(3) * bb(4) / numel(I(:, :, 1)));
o = struct('qBase', 15, 'qRoi', 70, 'rBase', 3/4, 'rRoi', 1/2, 'arqBase', 0, 'arqRoi', 0);
cfg.chan.model = 'ideal';
[out, ~] = transmit_roi_uep(I, bb, 1, cfg, o, 0);
check(out.baseOk && out.roiOk && isequal(out.Iout, out.Ic), 'ideal channel: both layers delivered, displayed image = error-free two-layer reference');
[pr, ~] = roi_metrics(I, out.Iout, bb);
pb = psnr_u8(I, out.Iout);
check(pr > pb, 'ROI PSNR (%.2f dB) exceeds whole-image PSNR (%.2f dB): quality concentrated in the ROI', pr, pb);
end
