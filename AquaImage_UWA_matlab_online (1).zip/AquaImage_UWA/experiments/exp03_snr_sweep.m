function T = exp03_snr_sweep()
%EXP03_SNR_SWEEP Experiment 3: LDPC rates 1/2..5/6 over SNR on the multipath
%   channel WITH selective-repeat ARQ (max 3 retries).
%   SNR range 0..16 dB: below ~2 dB even R=1/2 fails on this frequency-
%   selective channel, above ~14 dB R=5/6 succeeds (chosen from Exp 2).
%   Metrics: BER_pre/post, first-attempt and final PER, image delivery,
%   goodput (link: useful payload bits / data airtime) and delay.
%   The first-attempt PER curves versus the RECEIVER-ESTIMATED SNR define the
%   adaptation thresholds of Exp 5.
base = experiment_base();
base.arq.enabled = true; base.arq.maxRetries = 3;
snrs = 0:2:16;
v = struct('name', {}, 'apply', {});
for R = [1/2 2/3 3/4 5/6]
    v(end + 1) = struct('name', sprintf('LDPC R=%s', rate_str(R)), 'apply', @(c) setr(c, R)); %#ok<AGROW>
end
T = link_sweep(base, v, snrs, 'exp03');
rd = base.out.resultsDir; fd = fullfile(rd, 'figures');
save_sweep(T, fullfile(rd, 'tables', 'exp03_snr_sweep_multipath_arq.csv'));
plot_sweep(T, 'BER_pre', 'pre-decoding BER', 'Exp 3: pre-decoding BER vs SNR (multipath, OFDM/QPSK)', fullfile(fd, 'exp03_ber_pre.png'), true, 1e-7);
plot_sweep(T, 'BER_post', 'post-decoding BER (all transmissions)', 'Exp 3: post-decoding BER vs SNR', fullfile(fd, 'exp03_ber_post.png'), true, 1e-7);
plot_sweep(T, 'PER_initial', 'first-attempt PER', 'Exp 3: packet error rate vs SNR (first attempt)', fullfile(fd, 'exp03_per_initial.png'), true, 1e-4);
plot_sweep(T, 'PER_final', 'final PER after 3 retries', 'Exp 3: unrecovered packets vs SNR (ARQ, 3 retries)', fullfile(fd, 'exp03_per_final.png'), true, 1e-4);
plot_sweep(T, 'deliveryRate', 'image delivery success rate', 'Exp 3: image delivery vs SNR (ARQ, 3 retries)', fullfile(fd, 'exp03_delivery.png'), false);
plot_sweep(T, 'linkGoodput_bps', 'goodput (bit/s of decoded-image payload per data airtime)', 'Exp 3: goodput vs SNR', fullfile(fd, 'exp03_goodput.png'), false);
plot_sweep(T, 'meanDelay_s', 'mean image delay (s), FIFO, 1 image/s', 'Exp 3: delivery delay vs SNR', fullfile(fd, 'exp03_delay.png'), false);
end

function c = setr(c, R)
c.fec.code = 'ldpc'; c.fec.rate = R;
end
