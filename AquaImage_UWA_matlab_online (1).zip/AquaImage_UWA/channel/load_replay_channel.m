function rc = load_replay_channel(fname)
%LOAD_REPLAY_CHANNEL Load a time-varying channel impulse-response record (Model E).
%
%   rc = LOAD_REPLAY_CHANNEL(fname) reads a .mat file containing the variables
%     delay_s : P x 1  path/tap delays (s), relative, >= 0
%     gains   : P x T  complex baseband tap gains (at the modem carrier) over time
%     t_s     : 1 x T  sample times of the gains (s), increasing, t_s(1) = 0
%     source  : char   provenance (e.g. 'measured: <experiment>' or 'synthetic')
%   Measured soundings (e.g. converted from a channel-sounding archive) can be
%   stored in this format with tools/make_replay_example.m as a template.
%   The gains are normalised to unit average total power so that the SNR
%   definition of UWA_CHANNEL is unchanged.
S = load(fname);
need = {'delay_s', 'gains', 't_s'};
for k = 1:numel(need)
    if ~isfield(S, need{k})
        error('load_replay_channel:format', 'Replay file %s lacks variable "%s".', fname, need{k});
    end
end
rc.delay_s = S.delay_s(:);
rc.gains = S.gains;
rc.t_s = S.t_s(:).';
if size(rc.gains, 1) ~= numel(rc.delay_s) || size(rc.gains, 2) ~= numel(rc.t_s)
    error('load_replay_channel:size', 'gains must be P x T with P = numel(delay_s), T = numel(t_s).');
end
if any(rc.delay_s < 0) || any(diff(rc.t_s) <= 0)
    error('load_replay_channel:values', 'delays must be >= 0 and t_s strictly increasing.');
end
p = mean(sum(abs(rc.gains).^2, 1));
rc.gains = rc.gains / sqrt(p);
rc.source = 'unspecified';
if isfield(S, 'source'), rc.source = S.source; end
end
