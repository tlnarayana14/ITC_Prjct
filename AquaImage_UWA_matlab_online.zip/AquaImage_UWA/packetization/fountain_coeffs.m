function a = fountain_coeffs(e, K)
%FOUNTAIN_COEFFS GF(2) coefficient row (logical 1 x K) of encoding symbol e.
%   Systematic: e < K -> unit vector e+1. Repair symbols: Bernoulli(1/2)
%   bits from a Park-Miller LCG seeded by (e, K); an all-zero row is replaced
%   by a single-block row. Deterministic and identical at TX and RX.
a = false(1, K);
if e < K
    a(e + 1) = true; return;
end
st = mod(e * 104729 + K * 7919 + 1, 2147483647);
for j = 1:K
    st = mod(st * 16807, 2147483647);
    a(j) = st > 1073741823;
end
if ~any(a), a(mod(e, K) + 1) = true; end
end
