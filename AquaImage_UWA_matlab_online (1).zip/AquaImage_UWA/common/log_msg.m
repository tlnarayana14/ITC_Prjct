function log_msg(cfg, level, fmt, varargin)
%LOG_MSG Print a progress message when cfg.out.verbose >= level.
if isfield(cfg, 'out') && isfield(cfg.out, 'verbose') && cfg.out.verbose >= level
    fprintf(['[%s] ' fmt '\n'], datestr(now, 'HH:MM:SS'), varargin{:});
end
end
